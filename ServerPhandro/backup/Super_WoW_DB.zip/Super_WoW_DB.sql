CREATE DATABASE IF NOT EXISTS `super_wow` DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
USE `super_wow`;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `Table_User` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UUID` text NOT NULL,
  `_NAME` text CHARACTER SET utf8 NOT NULL,
  `_PHONE` text NOT NULL,
  `_EMAIL_ADDRESS` text NOT NULL,
  `_SEX` bit(1) NOT NULL,
  `_AGE` text NOT NULL,
  `_PASSWORD` text NOT NULL,
  `_STATUS` int(11) NOT NULL,
  `_DIR_PATH` text NOT NULL,
  `_IS_FAMOUS` bit(1) NOT NULL,
  `_IS_VIP` bit(1) NOT NULL,
  PRIMARY KEY (`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_User_Gift` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UID` int(11) NOT NULL,
  `_FROM_UUID` text NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Contact_List` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UID` int(11) NOT NULL,
  `_NAME` text CHARACTER SET utf8 NOT NULL,
  `_PHONE_1` text NOT NULL,
  `_PHONE_2` text NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Country` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_NAME` text NOT NULL,
  `_PATH_FLAG` text NOT NULL,
  `_CODE` text NOT NULL,
  `_MEMBERS` int(11) NOT NULL,
  `_NUMBER_OF_NETWORK` int(11) NULL DEFAULT NULL,
  `_CORRENSE` text NOT NULL,
  `_PRICE` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Giftes` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_TYPE` int(11) NOT NULL,
  `_CATEGORY` text NOT NULL,
  `_GIFT_PATH` text NOT NULL,
  `_PRICE` text NOT NULL,
  `_LIMITED` mediumint(9) NOT NULL,
  `_TO_USER` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_TO_USER`) REFERENCES Table_User_Gift(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Mobile_Network` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_NETWORK_NAME` text NOT NULL,
  `_CODE` text NOT NULL,
  `_COUNTRY_NAME` text NOT NULL,
  PRIMARY KEY (`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Bad_Word` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_WORD` text CHARACTER SET utf8 NOT NULL,
  `_REPLACEMENT` text CHARACTER SET utf8 NOT NULL,
  `_HOW_TIME` int(11) NOT NULL
  PRIMARY KEY (`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Worrning_Word` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_WORD` text CHARACTER SET utf8 NOT NULL,
  `_HOW_TIME` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Hashtag` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_WORD` text CHARACTER SET utf8 NOT NULL,
  `_HOW_TIME` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Worrning_Word_Extintion` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_WW` int(11) NOT NULL,
  `_WHO_SAY_THIS` int(11) NOT NULL,
  `_DATE` text NOT NULL,
  `_TIME` text NOT NULL,
  `_IP` text NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_WW`) REFERENCES Table_Worrning_Word(`ID`),
  FOREIGN KEY (`_WHO_SAY_THIS`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Phone` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UID` int(11) NOT NULL,
  `_IMEI` text NOT NULL,
  `_SIM_SERIAL` text NOT NULL,
  `_SUBSCRIBERID` text NULL,
  `_NETWORK` int(11) NOT NULL,
  `_COUNTRY` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`),
  FOREIGN KEY (`_NETWORK`) REFERENCES Table_Mobile_Network(`ID`),
  FOREIGN KEY (`_COUNTRY`) REFERENCES Table_Country(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_User_Country_Zone`(
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UID` int(11) NOT NULL,
  `_COUNTRY` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`),
  FOREIGN KEY (`_COUNTRY`) REFERENCES Table_Country(`ID`)
);

CREATE TABLE IF NOT EXISTS `System_Block_IP` (
  `ID` int(11) NOT NULL,
  `_IP_ADDRESS` text NOT NULL,
  `_COUNTRY` text NOT NULL,
  `_BROWSER` text NOT NULL,
  `_DATETIME` text NOT NULL,
  `_REQU` varchar(9000) NOT NULL,
  `_BLOCK_IP` bit(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ;

CREATE TABLE IF NOT EXISTS `Table_System` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_ACTIV` bit(1) NOT NULL DEFAULT 1,
  `_VERSION` text NOT NULL,
  `_APPLICATION_NAME` text NOT NULL,
  `_SERVER_CURRENT_PATH` text NOT NULL,
  `_SERVER_NEW_PATH` text NOT NULL,
  `_POWER_BY` text NOT NULL,
  `_INCRIMENT_PRICE_AFTER` INT(11) NOT NULL,
  `_INCRIMENT_PRICE` INT(11) NOT NULL,
  `_LOG_SYSTEM` bit(1) NOT NULL DEFAULT 1,
  `_CAN_GET_DATA_FROM_BROWSER` bit(1) NOT NULL DEFAULT 1,
  `_IS_UPDATE` bit(1) NOT NULL DEFAULT 0,
  `_IS_ONLINE_SERVER` bit(1) NOT NULL DEFAULT 0,
  `_SYSTEM_USER_ID` int(11) NOT NULL DEFAULT 0,
  `_ENCRIPTION_BUFFER` bit(1) NOT NULL DEFAULT 0,
  `_POINT_PRICE` float NOT NULL DEFAULT 0.14,
  `_LIKE_TO_POINT` int(11) NOT NULL DEFAULT 50,
  `_NORMAL_SCORE` int(11) NOT NULL DEFAULT 0,
  `_VIP_SCORE` int(11) NOT NULL DEFAULT 50,
  `_MINIMAM_SEND_TO_STOCK` int(11) NOT NULL DEFAULT 1,
  `_MAXIMAM_SEND_TO_STOCK` int(11) NOT NULL DEFAULT 1000000,
  `_SHOW_UNLIKE` bit(1) NOT NULL DEFAULT 1,
  `_SHOW_LIKE` bit(1) NOT NULL DEFAULT 1,
  `_SHOW_TOP_IN_GLOBEL` bit(1) NOT NULL DEFAULT 0,
  `_SHOW_TOP_IN_ZONE` bit(1) NOT NULL DEFAULT 1,
  `_SHOW_STOCK_IN_USERS_LIST` bit(1) NOT NULL DEFAULT 0,
  `_SHOW_POINTS_IN_USER_LIST` bit(1) NOT NULL DEFAULT 0,
  `_LIMITED_FOR_NETWORK` TEXT NOT NULL,
  `_ICON_FOR_VIP` text NOT NULL,
  `_ICON_FOR_FAMUS` text NOT NULL,
  `_ICON_FOR_LEVEL_1` text NOT NULL,
  `_ICON_FOR_LEVEL_2` text NOT NULL,
  `_ICON_FOR_LEVEL_3` text NOT NULL,
  `_ICON_FOR_LEVEL_4` text NOT NULL,
  `_ICON_FOR_LEVEL_5` text NOT NULL,
  `_ICON_FOR_LEVEL_6` text NOT NULL,
  PRIMARY KEY (`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_System_Log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_DATE` text NOT NULL,
  `_ACTION` text NOT NULL,
  `_REQUEST` varchar(9000) NOT NULL,
  `_INFO` varchar(9000) NOT NULL,
  `_IP_CLIENT` text NOT NULL,
  `_COUNTRY_ID` int(11) NULL,
  `_LEVEL` text NOT NULL,
  PRIMARY KEY (`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Top_Users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_COUNTRY_ID` int(11) NOT NULL,
  `_TOP_BOY_NAME` text CHARACTER SET utf8 NOT NULL,
  `_TOP_GIRL_NAME` text CHARACTER SET utf8 NOT NULL,
  `_TOP_BOY_VALUE` int(11) NOT NULL,
  `_TOP_GIRL_VALUE` int(11) NOT NULL,
  `_DATE` text NOT NULL,
  PRIMARY KEY (`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Users_Online` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UID` int(11) NOT NULL,
  `_STATUS` bit(1) NOT NULL,
  `_WHAT_IS_IN_YOUR_MIND` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Users_IP_Address` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UID` int(11) NOT NULL,
  `_IP_ADDR` text NOT NULL,
  `_LOCATION` text NOT NULL,
  `_TIME_DATE` text NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_User_Log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UID` int(11) NOT NULL,
  `_DATE` text NOT NULL,
  `_ACTION` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_User_Stock` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UID` int(11) NOT NULL,
  `_MONEY_STOCK` text NOT NULL,
  `_DATE_CHARGE_MONEY_STOK` text NOT NULL,
  `_VALUE_WAS_CHARGE_MONEY_STOCK` text NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_User_Point` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UID` int(11) NOT NULL,
  `_FROM` text NULL,
  `_POINT_STOCK` text NOT NULL,
  `_TOTAL_LIKE` INT NOT NULL,
  `_TOTAL_UNLIKE` INT NOT NULL,
  `_DATE_CHARGE_POINT` text NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_User_Photo` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UID` int(11) NOT NULL,
  `_PHOTO_PATH` text NOT NULL,
  `_COMMENT` varchar(500) CHARACTER SET utf8 NOT NULL,
  `_IS_PROFILE` bit(1) NOT NULL,
  `_TIME_OF_LIKE` int(11) NOT NULL,
  `_TIME_OF_UNLIKE` int(11) NOT NULL,
  `_PRIVACY` smallint(6) NOT NULL,
  `_INATTACH` bit(1) NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_User_Video` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UID` int(11) NOT NULL,
  `_VIDEO_PATH` text NOT NULL,
  `_COMMENT` varchar(500) CHARACTER SET utf8 NOT NULL,
  `_TIME_OF_LIKE` int(11) NOT NULL,
  `_TIME_OF_UNLIKE` int(11) NOT NULL,
  `_PRIVACY` smallint(6) NOT NULL,
  `_INATTACH` bit(1) NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_User_Audio` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_UID` int(11) NOT NULL,
  `_AUDIO_PATH` text NOT NULL,
  `_COMMENT` varchar(500) CHARACTER SET utf8 NOT NULL,
  `_TIME_OF_LIKE` int(11) NOT NULL,
  `_TIME_OF_UNLIKE` int(11) NOT NULL,
  `_PRIVACY` bit(1) NOT NULL,
  `_INATTACH` bit(1) NOT NULL,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_User_Photo_comment` (
 `ID` int(11) NOT NULL AUTO_INCREMENT,
 `_UPID` int(11) NOT NULL , 
 `_FROM` int(11) NOT NULL,
 `_COMMENT` varchar(500) CHARACTER SET utf8 NOT NULL,
 `_DATE` TEXT NOT NULL ,
 `_LIKE` int(11) NOT NULL,
 `_UNLIKE` int(11) NOT NULL,
PRIMARY KEY (`ID`),
FOREIGN KEY (`_UPID`) REFERENCES Table_User_Photo(`ID`),
FOREIGN KEY (`_FROM`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_User_Video_comment` (
 `ID` int(11) NOT NULL AUTO_INCREMENT,
 `_UVID` int(11) NOT NULL , 
 `_FROM` int(11) NOT NULL,
 `_COMMENT` varchar(500) CHARACTER SET utf8 NOT NULL,
 `_DATE` TEXT NOT NULL ,
 `_LIKE` int(11) NOT NULL,
 `_UNLIKE` int(11) NOT NULL,
PRIMARY KEY (`ID`),
FOREIGN KEY (`_UVID`) REFERENCES Table_User_Video(`ID`),
FOREIGN KEY (`_FROM`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_User_Audio_comment` (
 `ID` int(11) NOT NULL AUTO_INCREMENT,
 `_UAID` int(11) NOT NULL , 
 `_FROM` int(11) NOT NULL,
 `_COMMENT` varchar(500) CHARACTER SET utf8 NOT NULL,
 `_DATE` TEXT NOT NULL ,
 `_LIKE` int(11) NOT NULL,
 `_UNLIKE` int(11) NOT NULL,
PRIMARY KEY (`ID`),
FOREIGN KEY (`_UAID`) REFERENCES Table_User_Audio(`ID`),
FOREIGN KEY (`_FROM`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Messages` (
  `ID` int(11) NOT NULL,
  `_UID` int(11) DEFAULT NULL,
  `_TO` text,
  `_FROM` text,
  `_MESSAGE` varchar(9000) CHARACTER SET utf8 DEFAULT NULL,
  `_DATE` text NOT NULL,
  `_TIME` text NOT NULL,
  `_NEW` bit(1) NOT NULL,
  `_HIDE` bit(1) DEFAULT NULL
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`)
  FOREIGN KEY (`_TO`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_Notifications` (
    `ID` int(11) NOT NULL AUTO_INCREMENT,
    `_FROM` int(11) NOT NULL,
    `_TO`   int(11) NOT NULL,
    `_LABEL` text CHARACTER SET utf8 NOT NULL,
    `_DATE` text NOT NULL,
    `_ACTION` int(11) NOT NULL,
    `_SERIAL` text NOT NULL,
    `_ISNEW` bit(1) NOT NULL,
 PRIMARY KEY (`ID`),
 FOREIGN KEY (`_FROM`) REFERENCES Table_User(`ID`),
 FOREIGN KEY (`_TO`) REFERENCES Table_User(`ID`)
);

CREATE TABLE IF NOT EXISTS `Table_User_Friends` (
 `ID` int(11) NOT NULL AUTO_INCREMENT,
 `_UID` int(11) NOT NULL , 
 `_FRIEND` int(11) NOT NULL ,
 `_DATE` TEXT NOT NULL ,
 `_FAVORIT` bit(1) NOT NULL,
 `_ACCEPT` tinyint(4) NOT NULL,
PRIMARY KEY (`ID`),
FOREIGN KEY (`_UID`) REFERENCES Table_User(`ID`),
FOREIGN KEY (`_FRIEND`) REFERENCES Table_User(`ID`)
);


CREATE TABLE IF NOT EXISTS `country` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `_ISO` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `_NICENAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `_ISO3` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `_NUMCODE` smallint(6) DEFAULT NULL,
  `_PHONECODE` int(5) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=254 ;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`ID`, `_ISO`, `_NAME`, `_NICENAME`, `_ISO3`, `_NUMCODE`, `_PHONECODE`) VALUES
(1, 'AF', 'AFGHANISTAN', 'Afghanistan', 'AFG', 4, 93),
(2, 'AL', 'ALBANIA', 'Albania', 'ALB', 8, 355),
(3, 'DZ', 'ALGERIA', 'Algeria', 'DZA', 12, 213),
(4, 'AS', 'AMERICAN SAMOA', 'American Samoa', 'ASM', 16, 1684),
(5, 'AD', 'ANDORRA', 'Andorra', 'AND', 20, 376),
(6, 'AO', 'ANGOLA', 'Angola', 'AGO', 24, 244),
(7, 'AI', 'ANGUILLA', 'Anguilla', 'AIA', 660, 1264),
(8, 'AQ', 'ANTARCTICA', 'Antarctica', NULL, NULL, 0),
(9, 'AG', 'ANTIGUA AND BARBUDA', 'Antigua and Barbuda', 'ATG', 28, 1268),
(10, 'AR', 'ARGENTINA', 'Argentina', 'ARG', 32, 54),
(11, 'AM', 'ARMENIA', 'Armenia', 'ARM', 51, 374),
(12, 'AW', 'ARUBA', 'Aruba', 'ABW', 533, 297),
(13, 'AU', 'AUSTRALIA', 'Australia', 'AUS', 36, 61),
(14, 'AT', 'AUSTRIA', 'Austria', 'AUT', 40, 43),
(15, 'AZ', 'AZERBAIJAN', 'Azerbaijan', 'AZE', 31, 994),
(16, 'BS', 'BAHAMAS', 'Bahamas', 'BHS', 44, 1242),
(17, 'BH', 'BAHRAIN', 'Bahrain', 'BHR', 48, 973),
(18, 'BD', 'BANGLADESH', 'Bangladesh', 'BGD', 50, 880),
(19, 'BB', 'BARBADOS', 'Barbados', 'BRB', 52, 1246),
(20, 'BY', 'BELARUS', 'Belarus', 'BLR', 112, 375),
(21, 'BE', 'BELGIUM', 'Belgium', 'BEL', 56, 32),
(22, 'BZ', 'BELIZE', 'Belize', 'BLZ', 84, 501),
(23, 'BJ', 'BENIN', 'Benin', 'BEN', 204, 229),
(24, 'BM', 'BERMUDA', 'Bermuda', 'BMU', 60, 1441),
(25, 'BT', 'BHUTAN', 'Bhutan', 'BTN', 64, 975),
(26, 'BO', 'BOLIVIA', 'Bolivia', 'BOL', 68, 591),
(27, 'BA', 'BOSNIA AND HERZEGOVINA', 'Bosnia and Herzegovina', 'BIH', 70, 387),
(28, 'BW', 'BOTSWANA', 'Botswana', 'BWA', 72, 267),
(29, 'BV', 'BOUVET ISLAND', 'Bouvet Island', NULL, NULL, 0),
(30, 'BR', 'BRAZIL', 'Brazil', 'BRA', 76, 55),
(31, 'IO', 'BRITISH INDIAN OCEAN TERRITORY', 'British Indian Ocean Territory', NULL, NULL, 246),
(32, 'BN', 'BRUNEI DARUSSALAM', 'Brunei Darussalam', 'BRN', 96, 673),
(33, 'BG', 'BULGARIA', 'Bulgaria', 'BGR', 100, 359),
(34, 'BF', 'BURKINA FASO', 'Burkina Faso', 'BFA', 854, 226),
(35, 'BI', 'BURUNDI', 'Burundi', 'BDI', 108, 257),
(36, 'KH', 'CAMBODIA', 'Cambodia', 'KHM', 116, 855),
(37, 'CM', 'CAMEROON', 'Cameroon', 'CMR', 120, 237),
(38, 'CA', 'CANADA', 'Canada', 'CAN', 124, 1),
(39, 'CV', 'CAPE VERDE', 'Cape Verde', 'CPV', 132, 238),
(40, 'KY', 'CAYMAN ISLANDS', 'Cayman Islands', 'CYM', 136, 1345),
(41, 'CF', 'CENTRAL AFRICAN REPUBLIC', 'Central African Republic', 'CAF', 140, 236),
(42, 'TD', 'CHAD', 'Chad', 'TCD', 148, 235),
(43, 'CL', 'CHILE', 'Chile', 'CHL', 152, 56),
(44, 'CN', 'CHINA', 'China', 'CHN', 156, 86),
(45, 'CX', 'CHRISTMAS ISLAND', 'Christmas Island', NULL, NULL, 61),
(46, 'CC', 'COCOS (KEELING) ISLANDS', 'Cocos (Keeling) Islands', NULL, NULL, 672),
(47, 'CO', 'COLOMBIA', 'Colombia', 'COL', 170, 57),
(48, 'KM', 'COMOROS', 'Comoros', 'COM', 174, 269),
(49, 'CG', 'CONGO', 'Congo', 'COG', 178, 242),
(50, 'CD', 'CONGO, THE DEMOCRATIC REPUBLIC OF THE', 'Congo, the Democratic Republic of the', 'COD', 180, 242),
(51, 'CK', 'COOK ISLANDS', 'Cook Islands', 'COK', 184, 682),
(52, 'CR', 'COSTA RICA', 'Costa Rica', 'CRI', 188, 506),
(53, 'CI', 'COTE D''IVOIRE', 'Cote D''Ivoire', 'CIV', 384, 225),
(54, 'HR', 'CROATIA', 'Croatia', 'HRV', 191, 385),
(55, 'CU', 'CUBA', 'Cuba', 'CUB', 192, 53),
(56, 'CY', 'CYPRUS', 'Cyprus', 'CYP', 196, 357),
(57, 'CZ', 'CZECH REPUBLIC', 'Czech Republic', 'CZE', 203, 420),
(58, 'DK', 'DENMARK', 'Denmark', 'DNK', 208, 45),
(59, 'DJ', 'DJIBOUTI', 'Djibouti', 'DJI', 262, 253),
(60, 'DM', 'DOMINICA', 'Dominica', 'DMA', 212, 1767),
(61, 'DO', 'DOMINICAN REPUBLIC', 'Dominican Republic', 'DOM', 214, 1809),
(62, 'EC', 'ECUADOR', 'Ecuador', 'ECU', 218, 593),
(63, 'EG', 'EGYPT', 'Egypt', 'EGY', 818, 20),
(64, 'SV', 'EL SALVADOR', 'El Salvador', 'SLV', 222, 503),
(65, 'GQ', 'EQUATORIAL GUINEA', 'Equatorial Guinea', 'GNQ', 226, 240),
(66, 'ER', 'ERITREA', 'Eritrea', 'ERI', 232, 291),
(67, 'EE', 'ESTONIA', 'Estonia', 'EST', 233, 372),
(68, 'ET', 'ETHIOPIA', 'Ethiopia', 'ETH', 231, 251),
(69, 'FK', 'FALKLAND ISLANDS (MALVINAS)', 'Falkland Islands (Malvinas)', 'FLK', 238, 500),
(70, 'FO', 'FAROE ISLANDS', 'Faroe Islands', 'FRO', 234, 298),
(71, 'FJ', 'FIJI', 'Fiji', 'FJI', 242, 679),
(72, 'FI', 'FINLAND', 'Finland', 'FIN', 246, 358),
(73, 'FR', 'FRANCE', 'France', 'FRA', 250, 33),
(74, 'GF', 'FRENCH GUIANA', 'French Guiana', 'GUF', 254, 594),
(75, 'PF', 'FRENCH POLYNESIA', 'French Polynesia', 'PYF', 258, 689),
(76, 'TF', 'FRENCH SOUTHERN TERRITORIES', 'French Southern Territories', NULL, NULL, 0),
(77, 'GA', 'GABON', 'Gabon', 'GAB', 266, 241),
(78, 'GM', 'GAMBIA', 'Gambia', 'GMB', 270, 220),
(79, 'GE', 'GEORGIA', 'Georgia', 'GEO', 268, 995),
(80, 'DE', 'GERMANY', 'Germany', 'DEU', 276, 49),
(81, 'GH', 'GHANA', 'Ghana', 'GHA', 288, 233),
(82, 'GI', 'GIBRALTAR', 'Gibraltar', 'GIB', 292, 350),
(83, 'GR', 'GREECE', 'Greece', 'GRC', 300, 30),
(84, 'GL', 'GREENLAND', 'Greenland', 'GRL', 304, 299),
(85, 'GD', 'GRENADA', 'Grenada', 'GRD', 308, 1473),
(86, 'GP', 'GUADELOUPE', 'Guadeloupe', 'GLP', 312, 590),
(87, 'GU', 'GUAM', 'Guam', 'GUM', 316, 1671),
(88, 'GT', 'GUATEMALA', 'Guatemala', 'GTM', 320, 502),
(89, 'GN', 'GUINEA', 'Guinea', 'GIN', 324, 224),
(90, 'GW', 'GUINEA-BISSAU', 'Guinea-Bissau', 'GNB', 624, 245),
(91, 'GY', 'GUYANA', 'Guyana', 'GUY', 328, 592),
(92, 'HT', 'HAITI', 'Haiti', 'HTI', 332, 509),
(93, 'HM', 'HEARD ISLAND AND MCDONALD ISLANDS', 'Heard Island and Mcdonald Islands', NULL, NULL, 0),
(94, 'VA', 'HOLY SEE (VATICAN CITY STATE)', 'Holy See (Vatican City State)', 'VAT', 336, 39),
(95, 'HN', 'HONDURAS', 'Honduras', 'HND', 340, 504),
(96, 'HK', 'HONG KONG', 'Hong Kong', 'HKG', 344, 852),
(97, 'HU', 'HUNGARY', 'Hungary', 'HUN', 348, 36),
(98, 'IS', 'ICELAND', 'Iceland', 'ISL', 352, 354),
(99, 'IN', 'INDIA', 'India', 'IND', 356, 91),
(100, 'ID', 'INDONESIA', 'Indonesia', 'IDN', 360, 62),
(101, 'IR', 'IRAN, ISLAMIC REPUBLIC OF', 'Iran, Islamic Republic of', 'IRN', 364, 98),
(102, 'IQ', 'IRAQ', 'Iraq', 'IRQ', 368, 964),
(103, 'IE', 'IRELAND', 'Ireland', 'IRL', 372, 353),
(104, 'IL', 'ISRAEL', 'Israel', 'ISR', 376, 972),
(105, 'IT', 'ITALY', 'Italy', 'ITA', 380, 39),
(106, 'JM', 'JAMAICA', 'Jamaica', 'JAM', 388, 1876),
(107, 'JP', 'JAPAN', 'Japan', 'JPN', 392, 81),
(108, 'JO', 'JORDAN', 'Jordan', 'JOR', 400, 962),
(109, 'KZ', 'KAZAKHSTAN', 'Kazakhstan', 'KAZ', 398, 7),
(110, 'KE', 'KENYA', 'Kenya', 'KEN', 404, 254),
(111, 'KI', 'KIRIBATI', 'Kiribati', 'KIR', 296, 686),
(112, 'KP', 'KOREA, DEMOCRATIC PEOPLE''S REPUBLIC OF', 'Korea, Democratic People''s Republic of', 'PRK', 408, 850),
(113, 'KR', 'KOREA, REPUBLIC OF', 'Korea, Republic of', 'KOR', 410, 82),
(114, 'KW', 'KUWAIT', 'Kuwait', 'KWT', 414, 965),
(115, 'KG', 'KYRGYZSTAN', 'Kyrgyzstan', 'KGZ', 417, 996),
(116, 'LA', 'LAO PEOPLE''S DEMOCRATIC REPUBLIC', 'Lao People''s Democratic Republic', 'LAO', 418, 856),
(117, 'LV', 'LATVIA', 'Latvia', 'LVA', 428, 371),
(118, 'LB', 'LEBANON', 'Lebanon', 'LBN', 422, 961),
(119, 'LS', 'LESOTHO', 'Lesotho', 'LSO', 426, 266),
(120, 'LR', 'LIBERIA', 'Liberia', 'LBR', 430, 231),
(121, 'LY', 'LIBYAN ARAB JAMAHIRIYA', 'Libyan Arab Jamahiriya', 'LBY', 434, 218),
(122, 'LI', 'LIECHTENSTEIN', 'Liechtenstein', 'LIE', 438, 423),
(123, 'LT', 'LITHUANIA', 'Lithuania', 'LTU', 440, 370),
(124, 'LU', 'LUXEMBOURG', 'Luxembourg', 'LUX', 442, 352),
(125, 'MO', 'MACAO', 'Macao', 'MAC', 446, 853),
(126, 'MK', 'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF', 'Macedonia, the Former Yugoslav Republic of', 'MKD', 807, 389),
(127, 'MG', 'MADAGASCAR', 'Madagascar', 'MDG', 450, 261),
(128, 'MW', 'MALAWI', 'Malawi', 'MWI', 454, 265),
(129, 'MY', 'MALAYSIA', 'Malaysia', 'MYS', 458, 60),
(130, 'MV', 'MALDIVES', 'Maldives', 'MDV', 462, 960),
(131, 'ML', 'MALI', 'Mali', 'MLI', 466, 223),
(132, 'MT', 'MALTA', 'Malta', 'MLT', 470, 356),
(133, 'MH', 'MARSHALL ISLANDS', 'Marshall Islands', 'MHL', 584, 692),
(134, 'MQ', 'MARTINIQUE', 'Martinique', 'MTQ', 474, 596),
(135, 'MR', 'MAURITANIA', 'Mauritania', 'MRT', 478, 222),
(136, 'MU', 'MAURITIUS', 'Mauritius', 'MUS', 480, 230),
(137, 'YT', 'MAYOTTE', 'Mayotte', NULL, NULL, 269),
(138, 'MX', 'MEXICO', 'Mexico', 'MEX', 484, 52),
(139, 'FM', 'MICRONESIA, FEDERATED STATES OF', 'Micronesia, Federated States of', 'FSM', 583, 691),
(140, 'MD', 'MOLDOVA, REPUBLIC OF', 'Moldova, Republic of', 'MDA', 498, 373),
(141, 'MC', 'MONACO', 'Monaco', 'MCO', 492, 377),
(142, 'MN', 'MONGOLIA', 'Mongolia', 'MNG', 496, 976),
(143, 'MS', 'MONTSERRAT', 'Montserrat', 'MSR', 500, 1664),
(144, 'MA', 'MOROCCO', 'Morocco', 'MAR', 504, 212),
(145, 'MZ', 'MOZAMBIQUE', 'Mozambique', 'MOZ', 508, 258),
(146, 'MM', 'MYANMAR', 'Myanmar', 'MMR', 104, 95),
(147, 'NA', 'NAMIBIA', 'Namibia', 'NAM', 516, 264),
(148, 'NR', 'NAURU', 'Nauru', 'NRU', 520, 674),
(149, 'NP', 'NEPAL', 'Nepal', 'NPL', 524, 977),
(150, 'NL', 'NETHERLANDS', 'Netherlands', 'NLD', 528, 31),
(151, 'AN', 'NETHERLANDS ANTILLES', 'Netherlands Antilles', 'ANT', 530, 599),
(152, 'NC', 'NEW CALEDONIA', 'New Caledonia', 'NCL', 540, 687),
(153, 'NZ', 'NEW ZEALAND', 'New Zealand', 'NZL', 554, 64),
(154, 'NI', 'NICARAGUA', 'Nicaragua', 'NIC', 558, 505),
(155, 'NE', 'NIGER', 'Niger', 'NER', 562, 227),
(156, 'NG', 'NIGERIA', 'Nigeria', 'NGA', 566, 234),
(157, 'NU', 'NIUE', 'Niue', 'NIU', 570, 683),
(158, 'NF', 'NORFOLK ISLAND', 'Norfolk Island', 'NFK', 574, 672),
(159, 'MP', 'NORTHERN MARIANA ISLANDS', 'Northern Mariana Islands', 'MNP', 580, 1670),
(160, 'NO', 'NORWAY', 'Norway', 'NOR', 578, 47),
(161, 'OM', 'OMAN', 'Oman', 'OMN', 512, 968),
(162, 'PK', 'PAKISTAN', 'Pakistan', 'PAK', 586, 92),
(163, 'PW', 'PALAU', 'Palau', 'PLW', 585, 680),
(164, 'PS', 'PALESTINIAN TERRITORY, OCCUPIED', 'Palestinian Territory, Occupied', NULL, NULL, 970),
(165, 'PA', 'PANAMA', 'Panama', 'PAN', 591, 507),
(166, 'PG', 'PAPUA NEW GUINEA', 'Papua New Guinea', 'PNG', 598, 675),
(167, 'PY', 'PARAGUAY', 'Paraguay', 'PRY', 600, 595),
(168, 'PE', 'PERU', 'Peru', 'PER', 604, 51),
(169, 'PH', 'PHILIPPINES', 'Philippines', 'PHL', 608, 63),
(170, 'PN', 'PITCAIRN', 'Pitcairn', 'PCN', 612, 0),
(171, 'PL', 'POLAND', 'Poland', 'POL', 616, 48),
(172, 'PT', 'PORTUGAL', 'Portugal', 'PRT', 620, 351),
(173, 'PR', 'PUERTO RICO', 'Puerto Rico', 'PRI', 630, 1787),
(174, 'QA', 'QATAR', 'Qatar', 'QAT', 634, 974),
(175, 'RE', 'REUNION', 'Reunion', 'REU', 638, 262),
(176, 'RO', 'ROMANIA', 'Romania', 'ROM', 642, 40),
(177, 'RU', 'RUSSIAN FEDERATION', 'Russian Federation', 'RUS', 643, 70),
(178, 'RW', 'RWANDA', 'Rwanda', 'RWA', 646, 250),
(179, 'SH', 'SAINT HELENA', 'Saint Helena', 'SHN', 654, 290),
(180, 'KN', 'SAINT KITTS AND NEVIS', 'Saint Kitts and Nevis', 'KNA', 659, 1869),
(181, 'LC', 'SAINT LUCIA', 'Saint Lucia', 'LCA', 662, 1758),
(182, 'PM', 'SAINT PIERRE AND MIQUELON', 'Saint Pierre and Miquelon', 'SPM', 666, 508),
(183, 'VC', 'SAINT VINCENT AND THE GRENADINES', 'Saint Vincent and the Grenadines', 'VCT', 670, 1784),
(184, 'WS', 'SAMOA', 'Samoa', 'WSM', 882, 684),
(185, 'SM', 'SAN MARINO', 'San Marino', 'SMR', 674, 378),
(186, 'ST', 'SAO TOME AND PRINCIPE', 'Sao Tome and Principe', 'STP', 678, 239),
(187, 'SA', 'SAUDI ARABIA', 'Saudi Arabia', 'SAU', 682, 966),
(188, 'SN', 'SENEGAL', 'Senegal', 'SEN', 686, 221),
(189, 'CS', 'SERBIA AND MONTENEGRO', 'Serbia and Montenegro', NULL, NULL, 381),
(190, 'SC', 'SEYCHELLES', 'Seychelles', 'SYC', 690, 248),
(191, 'SL', 'SIERRA LEONE', 'Sierra Leone', 'SLE', 694, 232),
(192, 'SG', 'SINGAPORE', 'Singapore', 'SGP', 702, 65),
(193, 'SK', 'SLOVAKIA', 'Slovakia', 'SVK', 703, 421),
(194, 'SI', 'SLOVENIA', 'Slovenia', 'SVN', 705, 386),
(195, 'SB', 'SOLOMON ISLANDS', 'Solomon Islands', 'SLB', 90, 677),
(196, 'SO', 'SOMALIA', 'Somalia', 'SOM', 706, 252),
(197, 'ZA', 'SOUTH AFRICA', 'South Africa', 'ZAF', 710, 27),
(198, 'GS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS', 'South Georgia and the South Sandwich Islands', NULL, NULL, 0),
(199, 'ES', 'SPAIN', 'Spain', 'ESP', 724, 34),
(200, 'LK', 'SRI LANKA', 'Sri Lanka', 'LKA', 144, 94),
(201, 'SD', 'SUDAN', 'Sudan', 'SDN', 736, 249),
(202, 'SR', 'SURINAME', 'Suriname', 'SUR', 740, 597),
(203, 'SJ', 'SVALBARD AND JAN MAYEN', 'Svalbard and Jan Mayen', 'SJM', 744, 47),
(204, 'SZ', 'SWAZILAND', 'Swaziland', 'SWZ', 748, 268),
(205, 'SE', 'SWEDEN', 'Sweden', 'SWE', 752, 46),
(206, 'CH', 'SWITZERLAND', 'Switzerland', 'CHE', 756, 41),
(207, 'SY', 'SYRIAN ARAB REPUBLIC', 'Syrian Arab Republic', 'SYR', 760, 963),
(208, 'TW', 'TAIWAN, PROVINCE OF CHINA', 'Taiwan, Province of China', 'TWN', 158, 886),
(209, 'TJ', 'TAJIKISTAN', 'Tajikistan', 'TJK', 762, 992),
(210, 'TZ', 'TANZANIA, UNITED REPUBLIC OF', 'Tanzania, United Republic of', 'TZA', 834, 255),
(211, 'TH', 'THAILAND', 'Thailand', 'THA', 764, 66),
(212, 'TL', 'TIMOR-LESTE', 'Timor-Leste', NULL, NULL, 670),
(213, 'TG', 'TOGO', 'Togo', 'TGO', 768, 228),
(214, 'TK', 'TOKELAU', 'Tokelau', 'TKL', 772, 690),
(215, 'TO', 'TONGA', 'Tonga', 'TON', 776, 676),
(216, 'TT', 'TRINIDAD AND TOBAGO', 'Trinidad and Tobago', 'TTO', 780, 1868),
(217, 'TN', 'TUNISIA', 'Tunisia', 'TUN', 788, 216),
(218, 'TR', 'TURKEY', 'Turkey', 'TUR', 792, 90),
(219, 'TM', 'TURKMENISTAN', 'Turkmenistan', 'TKM', 795, 7370),
(220, 'TC', 'TURKS AND CAICOS ISLANDS', 'Turks and Caicos Islands', 'TCA', 796, 1649),
(221, 'TV', 'TUVALU', 'Tuvalu', 'TUV', 798, 688),
(222, 'UG', 'UGANDA', 'Uganda', 'UGA', 800, 256),
(223, 'UA', 'UKRAINE', 'Ukraine', 'UKR', 804, 380),
(224, 'AE', 'UNITED ARAB EMIRATES', 'United Arab Emirates', 'ARE', 784, 971),
(225, 'GB', 'UNITED KINGDOM', 'United Kingdom', 'GBR', 826, 44),
(226, 'US', 'UNITED STATES', 'United States', 'USA', 840, 1),
(227, 'UM', 'UNITED STATES MINOR OUTLYING ISLANDS', 'United States Minor Outlying Islands', NULL, NULL, 1),
(228, 'UY', 'URUGUAY', 'Uruguay', 'URY', 858, 598),
(229, 'UZ', 'UZBEKISTAN', 'Uzbekistan', 'UZB', 860, 998),
(230, 'VU', 'VANUATU', 'Vanuatu', 'VUT', 548, 678),
(231, 'VE', 'VENEZUELA', 'Venezuela', 'VEN', 862, 58),
(232, 'VN', 'VIET NAM', 'Viet Nam', 'VNM', 704, 84),
(233, 'VG', 'VIRGIN ISLANDS, BRITISH', 'Virgin Islands, British', 'VGB', 92, 1284),
(234, 'VI', 'VIRGIN ISLANDS, U.S.', 'Virgin Islands, U.s.', 'VIR', 850, 1340),
(235, 'WF', 'WALLIS AND FUTUNA', 'Wallis and Futuna', 'WLF', 876, 681),
(236, 'EH', 'WESTERN SAHARA', 'Western Sahara', 'ESH', 732, 212),
(237, 'YE', 'YEMEN', 'Yemen', 'YEM', 887, 967),
(238, 'ZM', 'ZAMBIA', 'Zambia', 'ZMB', 894, 260),
(239, 'ZW', 'ZIMBABWE', 'Zimbabwe', 'ZWE', 716, 263),
(240, 'RS', 'SERBIA', 'Serbia', 'SRB', 688, 381),
(241, 'AP', 'ASIA PACIFIC REGION', 'Asia / Pacific Region', '0', 0, 0),
(242, 'ME', 'MONTENEGRO', 'Montenegro', 'MNE', 499, 382),
(243, 'AX', 'ALAND ISLANDS', 'Aland Islands', 'ALA', 248, 358),
(244, 'BQ', 'BONAIRE, SINT EUSTATIUS AND SABA', 'Bonaire, Sint Eustatius and Saba', 'BES', 535, 599),
(245, 'CW', 'CURACAO', 'Curacao', 'CUW', 531, 599),
(246, 'GG', 'GUERNSEY', 'Guernsey', 'GGY', 831, 44),
(247, 'IM', 'ISLE OF MAN', 'Isle of Man', 'IMN', 833, 44),
(248, 'JE', 'JERSEY', 'Jersey', 'JEY', 832, 44),
(249, 'XK', 'KOSOVO', 'Kosovo', '---', 0, 381),
(250, 'BL', 'SAINT BARTHELEMY', 'Saint Barthelemy', 'BLM', 652, 590),
(251, 'MF', 'SAINT MARTIN', 'Saint Martin', 'MAF', 663, 590),
(252, 'SX', 'SINT MAARTEN', 'Sint Maarten', 'SXM', 534, 1),
(253, 'SS', 'SOUTH SUDAN', 'South Sudan', 'SSD', 728, 211);


INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AWCC' , '41201' , 'Afghanistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Areeba' , '41240' , 'Afghanistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Etisalat' , '41250' , 'Afghanistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Roshan' , '41220' , 'Afghanistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AMC' , '27601' , 'Albania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Eagle Mobile' , '27603' , 'Albania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Plus Communication' , '27604' , 'Albania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '27602' , 'Albania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Djezzy' , '60302' , 'Algeria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobilis' , '60301' , 'Algeria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nedjma' , '60303' , 'Algeria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Bluesky' , '54411' , 'American Samoa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobiland' , '21303' , 'Andorra'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MOVICEL' , '63104' , 'Angola'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('UNITEL' , '63102' , 'Angola'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless' , '365840' , 'Anguilla (United Kingdom)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Weblinks Limited' , '365010' , 'Anguilla (United Kingdom)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('APUA' , '344030' , 'Antigua and Barbuda'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('bmobile' , '344920' , 'Antigua and Barbuda'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '344930' , 'Antigua and Barbuda'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '722310' , 'Argentina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '722320' , 'Argentina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '722330' , 'Argentina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hutchinson (PORT HABLE)' , '722350' , 'Argentina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Movistar' , '722010' , 'Argentina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Movistar' , '722070' , 'Argentina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nextel' , '722020' , 'Argentina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Personal' , '72234' , 'Argentina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecom Personal SA' , '722341' , 'Argentina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecom Personal SA' , '72236' , 'Argentina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Beeline' , '28301' , 'Armenia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '28310' , 'Armenia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('VivaCell-MTS' , '28305' , 'Armenia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '36302' , 'Aruba (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicell' , '36320' , 'Aruba (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SETAR' , '36301' , 'Aruba (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3' , '50506' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3' , '50512' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3GIS' , '50515' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AAPT' , '50514' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Advanced Communications Technologies' , '50524' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airnet' , '50509' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Crazy Johns' , '50538' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Department of Defence' , '50504' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Localstar' , '50588' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Norfolk Telecom' , '50510' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('One. Tel' , '50508' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('One. Tel' , '50599' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('OPTUS / Virgin Mobile' , '50502' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ozitel' , '50505' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Railcorp' , '50513' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SOUL' , '50521' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telstra' , '50501' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telstra' , '50511' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telstra' , '50571' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telstra' , '50572' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Victorian Rail Track' , '50516' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '50503' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '50507' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('YES OPTUS' , '50590' , 'Australia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3' , '23210' , 'Austria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3' , '23214' , 'Austria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('A1' , '23201' , 'Austria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('A1' , '23209' , 'Austria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Barablu' , '23215' , 'Austria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('bob' , '23211' , 'Austria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('GSM-R A' , '23291' , 'Austria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '23205' , 'Austria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '23203' , 'Austria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '23207' , 'Austria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('yesss' , '23212' , 'Austria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Azercell' , '40001' , 'Azerbaijan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Bakcell' , '40002' , 'Azerbaijan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('FONEX' , '40003' , 'Azerbaijan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nar Mobile' , '40004' , 'Azerbaijan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BaTelCo' , '364390' , 'Bahamas'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Batelco' , '42601' , 'Bahrain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTC-VFBH' , '42602' , 'Bahrain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('VIVA' , '42604' , 'Bahrain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Aktel' , '47002' , 'Bangladesh'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Banglalink' , '47003' , 'Bangladesh'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Citycell' , '47005' , 'Bangladesh'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Citycell' , '47006' , 'Bangladesh'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Grameenphone' , '47001' , 'Bangladesh'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TeleTalk' , '47004' , 'Bangladesh'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Warid' , '47007' , 'Bangladesh'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('bmobile' , '342600' , 'Barbados'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '342750' , 'Barbados'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sunbeach Communications' , '342820' , 'Barbados'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BelCel JV' , '257501' , 'Belarus'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DIALLOG' , '25703' , 'Belarus'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('life:)' , '25704' , 'Belarus'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTS' , '25702' , 'Belarus'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Velcom' , '25701' , 'Belarus'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BASE' , '20620' , 'Belgium'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobistar' , '20610' , 'Belgium'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Proximus' , '20601' , 'Belgium'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telenet' , '20605' , 'Belgium'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Belize Telemedia' , '70267' , 'Belize'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('International Telecommunications Ltd.' , '70268' , 'Belize'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Smart' , '70299' , 'Belize'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Areeba' , '61603' , 'Benin'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BBCOM' , '61600' , 'Benin'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BBCOM' , '61604' , 'Benin'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Glo' , '61605' , 'Benin'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Libercom' , '61601' , 'Benin'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecel' , '61602' , 'Benin'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '31038' , 'Bermudas'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel Bermuda' , '35001' , 'Bermudas'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobility' , '35002' , 'Bermudas'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('B-Mobile' , '40211' , 'Bhutan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TashiCell' , '40277' , 'Bhutan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Entel' , '73602' , 'Bolivia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nuevatel' , '73601' , 'Bolivia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tigo' , '73603' , 'Bolivia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BH Mobile' , '21890' , 'Bosnia and Herzegovina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ERONET' , '21803' , 'Bosnia and Herzegovina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('m:tel' , '21805' , 'Bosnia and Herzegovina'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BTC Mobile' , '65204' , 'Botswana'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mascom' , '65201' , 'Botswana'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '65202' , 'Botswana'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('aiou' , '72437' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Amazonia Celular' , '72424' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Brasil Telecom' , '72416' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '72405' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CTBC Cellular' , '72432' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CTBC Cellular' , '72433' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CTBC Cellular' , '72434' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CTBC Celular' , '72407' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nextel' , '72400' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nextel' , '72439' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sercomtel' , '72415' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TIM' , '72402' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TIM' , '72403' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TIM' , '72404' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TIM' , '72408' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TNL PCS' , '72431' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vivo' , '72406' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vivo' , '72410' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vivo' , '72411' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vivo' , '72423' , 'Brazil'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless' , '348170' , 'British Virgin Islands (United Kingdom)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Caribbean Cellular Telephone' , '348570' , 'British Virgin Islands (United Kingdom)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '348770' , 'British Virgin Islands (United Kingdom)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('B-Mobile' , '52802' , 'Brunei'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DTSCom' , '52811' , 'Brunei'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Jabatan Telekom' , '52801' , 'Brunei'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('GLOBUL' , '28405' , 'Bulgaria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('M-Tel' , '28401' , 'Bulgaria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Undisclosed' , '28404' , 'Bulgaria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vivatel' , '28403' , 'Bulgaria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Onatel' , '61301' , 'Burkina Faso'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecel Faso' , '61303' , 'Burkina Faso'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '61302' , 'Burkina Faso'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Africell' , '64202' , 'Burundi'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('HiTs Telecom' , '64208' , 'Burundi'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Smart Mobile' , '64207' , 'Burundi'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Spacetel' , '64201' , 'Burundi'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecel' , '64203' , 'Burundi'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('U-COM Burundi' , '64282' , 'Burundi'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Beeline' , '45609' , 'Cambodia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Camshin / Shinawatra' , '45618' , 'Cambodia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Excell' , '45611' , 'Cambodia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('hello' , '45602' , 'Cambodia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Metfone' , '45608' , 'Cambodia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobitel' , '45601' , 'Cambodia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('qb' , '45604' , 'Cambodia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('S Telecom' , '45603' , 'Cambodia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Smart Mobile' , '45606' , 'Cambodia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Star-Cell' , '45605' , 'Cambodia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN Cameroon' , '62401' , 'Cameroon'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '62402' , 'Cameroon'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel Wireless' , '302290' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BC Tel Mobility' , '302652' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Bell' , '302610' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Bell' , '302640' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Bell / Telus / SaskTel' , '302880' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Bell Mobility' , '302651' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DMTS' , '302380' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Fido' , '302370' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('FIRST' , '302350' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Globalstar' , '302710' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ICE Wireless' , '302620' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MB Tel Mobility' , '302701' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobilicity' , '302320' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MT&T Mobility' , '302702' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTS' , '302660' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTS Mobility' , '302655' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('New Tel Mobility' , '302703' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Rogers Wireless' , '302720' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sask Tel Mobility' , '302654' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SaskTel' , '302680' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SaskTel' , '302780' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tbay Mobility' , '302656' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telus' , '302220' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telus' , '302221' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telus (Quebec) Mobility' , '302657' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telus Mobility' , '302360' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telus Mobility' , '302361' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telus Mobility' , '302653' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Videotron' , '302500' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Videotron' , '302510' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('WIND Mobile' , '302490' , 'Canada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CVMOVEL' , '62501' , 'Cape Verde'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T+' , '62502' , 'Cape Verde'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless' , '346140' , 'Cayman Islands (United Kingdom)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '346050' , 'Cayman Islands (United Kingdom)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CTP' , '62301' , 'Central African Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nationlink' , '62304' , 'Central African Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '62303' , 'Central African Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TC' , '62302' , 'Central African Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '73003' , 'Chile'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Entel' , '73001' , 'Chile'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Entel' , '73010' , 'Chile'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '73002' , 'Chile'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nextel' , '73004' , 'Chile'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('VTR MÃ³vil' , '73008' , 'Chile'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Will' , '73099' , 'Chile'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('(unknown)' , '46006' , 'China'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('China Mobile' , '46000' , 'China'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('China Mobile' , '46002' , 'China'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('China Mobile' , '46007' , 'China'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('China Telecom' , '46003' , 'China'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('China Telecom' , '46005' , 'China'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('China Tietong' , '46020' , 'China'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('China Unicom' , '46001' , 'China'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Colombia Telecomunicaciones S.A. - Telecom' , '732001' , 'Colombia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Comcel' , '732101' , 'Colombia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Edatel' , '732002' , 'Colombia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '732102' , 'Colombia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '732123' , 'Colombia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tigo' , '732103' , 'Colombia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tigo' , '732111' , 'Colombia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('HURI - SNPT' , '65401' , 'Comoros'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecom Cook' , '54801' , 'Cook Islands'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ICE' , '71201' , 'Costa Rica'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ICE' , '71202' , 'Costa Rica'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ICE' , '71203' , 'Costa Rica'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '71204' , 'Costa Rica'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cora de Comstar' , '61201' , 'Cote d"Ivoire'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KoZ' , '61204' , 'Cote d"Ivoire'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Moov' , '61202' , 'Cote d"Ivoire'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN' , '61205' , 'Cote d"Ivoire'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '61203' , 'Cote d"Ivoire'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ORICEL' , '61206' , 'Cote d"Ivoire'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '21901' , 'Croatia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tele2' , '21902' , 'Croatia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('VIPnet' , '21910' , 'Croatia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ETECSA' , '36801' , 'Cuba'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cytamobile-Vodafone' , '28001' , 'Cyprus'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN' , '28010' , 'Cyprus'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Salam' , '62204' , 'Czad'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TAWALI' , '62202' , 'Czad'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TIGO - Millicom' , '62203' , 'Czad'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '62201' , 'Czad'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('EUROTEL PRAHA' , '23002' , 'Czech Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('OSKAR' , '23003' , 'Czech Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('OSNO TELECOMUNICATION, s.r.o.' , '23006' , 'Czech Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SprÃ¡va Å¾elezniÄnÃ­ dopravnÃ­ cesty, s.o' , '23098' , 'Czech Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '23001' , 'Czech Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TRAVEL TELEKOMMUNIKATION, s.r.o.' , '23005' , 'Czech Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('U:fon' , '23004' , 'Czech Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone Czech Republic a.s., R&D Centre at FEE, CTU' , '23099' , 'Czech Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CCT' , '63086' , 'Democratic Republic of Congo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cellco' , '63004' , 'Democratic Republic of Congo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Libertis Telecom' , '63010' , 'Democratic Republic of Congo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SAIT Telecom' , '63089' , 'Democratic Republic of Congo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Supercell' , '63005' , 'Democratic Republic of Congo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodacom' , '63001' , 'Democratic Republic of Congo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '63002' , 'Democratic Republic of Congo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3' , '23806' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ApS KBUS' , '23805' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Barablu Mobile Ltd.' , '23807' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Dansk Beredskabskommunikation A/S' , '23809' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Dansk Beredskabskommunikation A/S' , '23811' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ericsson Danmark A/S' , '23840' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Lycamobile Denmark Ltd' , '23812' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MIGway A/S' , '23803' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sonofon' , '23877' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TDC' , '23801' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TDC' , '23810' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telenor' , '23802' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telia' , '23820' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telia' , '23830' , 'Denmark'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Evatis' , '63801' , 'Djibouti'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless' , '366110' , 'Dominica'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '366020' , 'Dominica'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '37002' , 'Dominican Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '37001' , 'Dominican Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tricom S.A.' , '37003' , 'Dominican Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ViVa' , '37004' , 'Dominican Republic'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Timor Telecom' , '51402' , 'East Timor'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Alegro' , '74002' , 'Ecuador'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Movistar' , '74000' , 'Ecuador'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Porta' , '74001' , 'Ecuador'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Etisalat' , '60203' , 'Egypt'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobinil' , '60201' , 'Egypt'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '60202' , 'Egypt'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '70610' , 'El Salvador'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '70611' , 'El Salvador'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CTE Telecom Personal' , '70601' , 'El Salvador'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('digicel' , '70602' , 'El Salvador'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '70604' , 'El Salvador'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telemovil EL Salvador' , '70603' , 'El Salvador'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hits GQ' , '62703' , 'Equatorial Guinea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange GQ' , '62701' , 'Equatorial Guinea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Eritel' , '65701' , 'Eritrea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AS Bravocom Mobiil' , '24805' , 'Estonia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Elisa' , '24802' , 'Estonia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('EMT' , '24801' , 'Estonia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('OY Top Connect' , '24804' , 'Estonia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('OY ViaTel' , '24806' , 'Estonia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tele 2' , '24803' , 'Estonia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ETMTN' , '63601' , 'Ethiopia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Faroese Telecom' , '28801' , 'Faroe Islands (Denmark)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '28802' , 'Faroe Islands (Denmark)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '54202' , 'Fiji'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '54201' , 'Fiji'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AMT' , '24414' , 'Finland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DNA' , '24403' , 'Finland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DNA' , '24412' , 'Finland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Elisa' , '24405' , 'Finland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nokia' , '24407' , 'Finland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SAMK' , '24415' , 'Finland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Saunalahti' , '24421' , 'Finland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Scnl Truphone' , '24429' , 'Finland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sonera' , '24491' , 'Finland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TDC Oy' , '24410' , 'Finland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Unknown' , '24408' , 'Finland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('VIRVE' , '24411' , 'Finland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Bouygues' , '20820' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Bouygues' , '20821' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Bouygues' , '20888' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('France Telecom Mobile' , '20801' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Free Mobile' , '20814' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Free Mobile' , '20815' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Globalstar Europe' , '20805' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Globalstar Europe' , '20806' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Globalstar Europe' , '20807' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '20800' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '20802' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SFR' , '20810' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SFR' , '20811' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SFR' , '20813' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Transatel Mobile' , '20822' , 'France'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('VINI' , '54720' , 'French Polynesia (France)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Azur' , '62804' , 'Gabon'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Libertis' , '62801' , 'Gabon'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Moov (Telecel) Gabon S.A.' , '62802' , 'Gabon'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '62803' , 'Gabon'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Africel' , '60702' , 'Gambia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Comium' , '60703' , 'Gambia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Gamcel' , '60701' , 'Gambia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('QCell' , '60704' , 'Gambia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('A-Mobile' , '28988' , 'Abkhazia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Aquafon' , '28967' , 'Abkhazia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Beeline' , '28204' , 'Georgia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Geocell' , '28201' , 'Georgia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Iberiatel' , '28203' , 'Georgia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Magti' , '28202' , 'Georgia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Silknet' , '28205' , 'Georgia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('27C3' , '26242' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airdata' , '26215' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Deutsche Bahn AG' , '26210' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DB Telematik' , '26260' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Debitel' , '262901' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Dolphin Telecom' , '26212' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('E-Plus' , '26203' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('E-Plus' , '26205' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('E-Plus' , '26277' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Group 3G UMTS' , '26214' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('LYCA' , '26243' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobilcom Multimedia' , '26213' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nash Technologies' , '26292' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('O2' , '26207' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('O2' , '26208' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('O2' , '26211' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Siemens AG' , '26276' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '26201' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '26206' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('vistream' , '26216' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '26202' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '26204' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '26209' , 'Germany'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '62006' , 'Ghana'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ghana Telecom Mobile' , '62002' , 'Ghana'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Kasapa / Hutchison Telecom' , '62004' , 'Ghana'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN' , '62001' , 'Ghana'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('tiGO' , '62003' , 'Ghana'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CTS Mobile' , '26606' , 'Gibraltar (United Kingdom)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('GibTel' , '26601' , 'Gibraltar (United Kingdom)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cosmote' , '20201' , 'Greece'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '20205' , 'Greece'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Wind' , '20209' , 'Greece'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Wind' , '20210' , 'Greece'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TELE Greenland A/S' , '29001' , 'Greenland (Denmark)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless' , '352110' , 'Grenada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '352030' , 'Grenada'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '34020' , 'Guadeloupe (France)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MIO GSM' , '34008' , 'Guadeloupe (France)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '34001' , 'Guadeloupe (France)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Outremer' , '34002' , 'Guadeloupe (France)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telcell' , '34003' , 'Guadeloupe (France)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Guam Telephone Authority' , '310033' , 'Guam (United States)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Guamcell' , '310370' , 'Guam (United States)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Guamcell' , '310470' , 'Guam (United States)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('i CAN_GSM' , '311250' , 'Guam (United States)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IT&E Wireless' , '310032' , 'Guam (United States)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('mPulse' , '310140' , 'Guam (United States)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '70401' , 'Guatemala'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Comcel / Tigo' , '70402' , 'Guatemala'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '70403' , 'Guatemala'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '73801' , 'Guiana'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('GT&T Cellink Plus' , '73802' , 'Guiana'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cellcom' , '61105' , 'Guinea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Lagui' , '61102' , 'Guinea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN' , '61104' , 'Guinea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Spacetel' , '61101' , 'Guinea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecel Guinee' , '61103' , 'Guinea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Areeba' , '63202' , 'Guinea-Bissau'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '63203' , 'Guinea-Bissau'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Comcel / Voila' , '372010' , 'Haiti'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '37202' , 'Haiti'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('NATCOM' , '37203' , 'Haiti'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('6Gmobile' , '20414' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ASPIDER Solutions Nederland B.V.' , '20423' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Breezz Nederland B.V.' , '20427' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CapX B.V.' , '20425' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('eleena (MVNE)' , '20407' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Elephant Talk Communications Premium Rate Services' , '20405' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Intercity Mobile Communications B.V.' , '20417' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KPN' , '20408' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KPN' , '20410' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KPN Mobile The Netherlands B.V.' , '20469' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Lycamobile' , '20409' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ministerie van Defensie' , '20422' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mixe Communication Solutions B.V.' , '20419' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mundio Mobile (Netherlands) Ltd' , '20406' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('NS Railinfrabeheer B.V.' , '20421' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange Nederland' , '20420' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Private Mobility Nederland B.V.' , '20424' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('RadioAccess B.V.' , '20467' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SpeakUp B.V.' , '20426' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile / Ben' , '20416' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tele2 Netherlands' , '20402' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telfort / O2' , '20412' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Unica Installatietechniek B.V' , '20413' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Unify Group Holding B.V.' , '20468' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('UPC Nederland B.V.' , '20418' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('VastMobiel B.V.' , '20401' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '20404' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Voiceworks B.V.' , '20403' , 'Holland (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Celtel / Tigo' , '70802' , 'Honduras'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '70801' , 'Honduras'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DIGICEL' , '70840' , 'Honduras'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hondutel' , '70830' , 'Honduras'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3 (3G)' , '45403' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3 CDMA' , '45405' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3 Dual (2G)' , '45404' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('C Peoples' , '45412' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('China Motion Telecom' , '45409' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('China Unicom' , '45407' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('China-Hongkong Telecom' , '45411' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CITIC Telecom 1616' , '45401' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CSL' , '45400' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CSL 3G' , '45402' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hong Kong CSL Limited' , '45418' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hutchison Telecom' , '45414' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('New World' , '45410' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('PCCW' , '45416' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('PCCW' , '45419' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('PCCW' , '45429' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SmarTone Mobile Comms' , '45415' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SmarTone Mobile Comms' , '45417' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Smartone-Vodafone' , '45406' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Trident' , '45408' , 'Hong Kong (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Pannon' , '21601' , 'Hungary'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '21630' , 'Hungary'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '21670' , 'Hungary'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IceCell' , '27407' , 'Iceland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nova' , '27411' , 'Iceland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('NÃºll nÃ­u ehf' , '27406' , 'Iceland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('On-waves' , '27408' , 'Iceland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Siminn' , '27401' , 'Iceland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tal' , '27412' , 'Iceland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Viking' , '27404' , 'Iceland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '27402' , 'Iceland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '27403' , 'Iceland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '40417' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '40425' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '40428' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '40429' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '40437' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '40491' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405082' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405800' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405801' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405802' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405803' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405804' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405805' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405806' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405807' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405808' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405809' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405810' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405811' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405812' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AIRCEL' , '405813' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Aircell Digilink' , '40460' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Aircell Digilink Essar Cellph.' , '40415' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40406' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40410' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40431' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40440' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40445' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40449' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40470' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40494' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40495' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40497' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40498' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40551' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '40552' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AirTel' , '40553' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AirTel' , '40554' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AirTel' , '40555' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AirTel' , '40556' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AirTel' , '40570' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel - Haryana' , '40496' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel - Punjab' , '40402' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel / Bharti Telenet' , '40403' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel Gujrat' , '40493' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel Maharashtra & Goa' , '40490' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel Mumbai' , '40492' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BPL Mobile Cellular' , '40443' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BPL Mobile Mumbai' , '40421' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BPL USWest Cellular / Cellular Comms' , '40427' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40434' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40438' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40451' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40453' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40454' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40455' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40457' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40458' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40459' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40464' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40471' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40473' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40474' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40475' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40476' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40477' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40480' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL' , '40481' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL J&K' , '40462' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL Kerala' , '40472' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BSNL Maharashtra & Goa' , '40466' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BTA Cellcom' , '40478' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Dishnet Wireless' , '40448' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Escorts' , '40482' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Escorts Telecom' , '40487' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Escorts Telecom' , '40488' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Escorts Telecom' , '40489' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Essar / Sterling Cellular' , '40411' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Etisalat DB(cheers)' , '405912' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Etisalat DB(cheers)' , '405913' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Etisalat DB(cheers)' , '405914' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Etisalat DB(cheers)' , '405917' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hutch' , '40566' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hutchinson Essar South' , '40486' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hutchison Essar South' , '40413' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hutchison Essar South' , '40484' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IDEA' , '40419' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IDEA' , '405799' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IDEA' , '405845' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IDEA' , '405848' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IDEA' , '405850' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IDEA' , '40586' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Idea (Escotel) Haryana' , '40412' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Idea (Escotel) UP West' , '40456' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IDEA CELLULAR - Delhi' , '40404' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IDEA Cellular - Gujarat' , '40424' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IDEA Cellular - Maharashtra' , '40422' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Loop Mobile' , '405855' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Loop Mobile' , '405864' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Loop Mobile' , '405865' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTNL - Delhi' , '40468' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTNL - Mumbai' , '40469' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance' , '40450' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance' , '40452' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance' , '40467' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance' , '40483' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance' , '40485' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance' , '40501' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance' , '40503' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance' , '40504' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance' , '40509' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance' , '40510' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance' , '40513' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance Telecom Private' , '40409' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Reliance Telecom Private' , '40436' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('RPG MAA' , '40441' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('S Tel' , '405881' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Spice Telecom - Karnataka' , '40444' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Spice Telecom - Punjab' , '40414' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Srinivas Cellcom / Aircel' , '40442' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Cellular / Idea Cellular' , '40407' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405025' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405026' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405027' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405029' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405030' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405031' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405032' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405033' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405034' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405035' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405036' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405037' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405038' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405039' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405040' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405041' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405042' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405043' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405044' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405045' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405046' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TATA Teleservice' , '405047' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uninor' , '405818' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uninor' , '405819' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uninor' , '405820' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uninor' , '405821' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uninor' , '405822' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uninor' , '405844' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uninor' , '405875' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uninor' , '405880' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uninor' , '405927' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uninor' , '405929' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Videocon Datacom' , '405824' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Videocon Datacom' , '405827' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Videocon Datacom' , '405834' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '40420' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '40446' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone - Gujarat' , '40405' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone - Haryana' , '40401' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone - Kolkata' , '40430' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone IN' , '405750' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone IN' , '405751' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone IN' , '405752' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone IN' , '405753' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone IN' , '405754' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone IN' , '405755' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone IN' , '405756' , 'India'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3' , '51089' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AXIS' , '51008' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ceria' , '510?' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ceria' , '51027' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Esia' , '51099' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Fren/Hepi' , '51028' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IM3' , '51021' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('INDOSAT' , '51001' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('PSN' , '51000' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SMART' , '51009' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('StarOne' , '51003' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TelkomFlexi' , '51007' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TELKOMMobile' , '51020' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telkomsel' , '51010' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('XL' , '51011' , 'Indonesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Irancell' , '43235' , 'Iran'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Iraphone' , '43293' , 'Iran'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MCI' , '43211' , 'Iran'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTCE' , '43219' , 'Iran'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Taliya' , '43232' , 'Iran'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TCI' , '43270' , 'Iran'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TKC' , '43214' , 'Iran'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Asia Cell' , '41805' , 'Iraq'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Asia Cell' , '41850' , 'Iraq'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Korek' , '41840' , 'Iraq'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobitel' , '41845' , 'Iraq'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Omnnea' , '41892' , 'Iraq'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SanaTel' , '41808' , 'Iraq'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain IQ' , '41820' , 'Iraq'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain IQ' , '41830' , 'Iraq'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3' , '27205' , 'Ireland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Access Telecom' , '27204' , 'Ireland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Clever Communications' , '27209' , 'Ireland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('E-Mobile' , '27200' , 'Ireland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Eircom' , '27207' , 'Ireland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Liffey Telecom' , '27211' , 'Ireland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Meteor' , '27203' , 'Ireland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('O2' , '27202' , 'Ireland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tesco Mobile' , '272020' , 'Ireland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '27201' , 'Ireland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cellcom' , '42502' , 'Israel'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mirs' , '42577' , 'Israel'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '42501' , 'Israel'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Partner' , '-' , 'Israel'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Pelephone' , '42503' , 'Israel'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3 Italia' , '22299' , 'Italy'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Blu' , '22298' , 'Italy'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Elsacom' , '22202' , 'Italy'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IPSE 2000' , '22277' , 'Italy'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Noverca' , '22207' , 'Italy'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('RFI' , '22230' , 'Italy'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TIM' , '22201' , 'Italy'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '22210' , 'Italy'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Wind' , '22288' , 'Italy'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless' , '338020' , 'Jamaica'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless' , '338180' , 'Jamaica'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '338070' , 'Jamaica'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '338050' , 'Jamaica'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44001' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44002' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44003' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44009' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44010' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44011' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44012' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44013' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44014' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44015' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44016' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44017' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44018' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44019' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44021' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44022' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44023' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44024' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44025' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44026' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44027' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44028' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44029' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44030' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44031' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44032' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44033' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44034' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44035' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44036' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44037' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44038' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44039' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44049' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44058' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44060' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44061' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44062' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44063' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44064' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44065' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44066' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44067' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44068' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44069' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44087' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DoCoMo' , '44099' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('eMobile' , '44000' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44007' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44008' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44050' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44051' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44052' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44053' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44054' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44055' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44056' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44070' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44071' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44072' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44073' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44074' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44075' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44076' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44077' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44079' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44088' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KDDI' , '44089' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Okinawa Cellular Telephone' , '44078' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SoftBank' , '44020' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TU-KA' , '44080' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TU-KA' , '44081' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TU-KA' , '44082' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TU-KA' , '44083' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TU-KA' , '44084' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TU-KA' , '44085' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TU-KA' , '44086' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44004' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44006' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44040' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44041' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44042' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44043' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44044' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44045' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44046' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44047' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44048' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44090' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44092' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44093' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44094' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44095' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44096' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44097' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '44098' , 'Japan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '41677' , 'Jordan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Umniah' , '41603' , 'Jordan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('XPress Telecom' , '41602' , 'Jordan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '41601' , 'Jordan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Beeline' , '40101' , 'Kazakhstan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Dalacom' , '40107' , 'Kazakhstan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('K\'Cell' , '40102' , 'Kazakhstan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Kazakhtelecom' , '40108' , 'Kazakhstan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobile Telecom Service' , '40177' , 'Kazakhstan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange Kenya' , '63907' , 'Kenya'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Safaricom' , '63902' , 'Kenya'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('yu' , '63905' , 'Kenya'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '63903' , 'Kenya'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Kiribati Frigate' , '54509' , 'Kiribati'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Viva' , '41904' , 'Kuwait'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Wataniya' , '41903' , 'Kuwait'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '41902' , 'Kuwait'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Bitel' , '43701' , 'Kyrgyzstan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Fonex' , '43703' , 'Kyrgyzstan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MegaCom' , '43705' , 'Kyrgyzstan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('O!' , '43709' , 'Kyrgyzstan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ETL' , '45702' , 'Laos'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('LaoTel' , '45701' , 'Laos'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('LAT' , '45703' , 'Laos'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tigo' , '45708' , 'Laos'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Bite' , '24705' , 'Latvia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Camel Mobile' , '24709' , 'Latvia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IZZI' , '24708' , 'Latvia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('LMT' , '24701' , 'Latvia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTS' , '24707' , 'Latvia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Rigatta' , '24706' , 'Latvia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tele2' , '24702' , 'Latvia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TRIATEL' , '24703' , 'Latvia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Alfa' , '41501' , 'Lebanon'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTC-Touch' , '41503' , 'Lebanon'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ogero Mobile' , '41505' , 'Lebanon'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Econet Ezin-cel' , '65102' , 'Lesotho'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodacom' , '65101' , 'Lesotho'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Al-Jeel Phone' , '60602' , 'Libya'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hatef Libya' , '60606' , 'Libya'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Libya Phone' , '60603' , 'Libya'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Libyana' , '60600' , 'Libya'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Madar' , '60601' , 'Libya'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cubic Telecom' , '29504' , 'Liechtenstein'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('FL1' , '29505' , 'Liechtenstein'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '29502' , 'Liechtenstein'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Swisscom' , '29501' , 'Liechtenstein'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tele 2' , '29577' , 'Liechtenstein'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BITE' , '24602' , 'Lithuania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('LitRail' , '24605' , 'Lithuania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mediafon' , '24606' , 'Lithuania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Omnitel' , '24601' , 'Lithuania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tele 2' , '24603' , 'Lithuania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cellcom' , '61807' , 'Livery'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Comium Liberi' , '61804' , 'Livery'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Libercell' , '61802' , 'Livery'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('LIBTELCO' , '61820' , 'Livery'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Lonestar Cell' , '61801' , 'Livery'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('LuxGSM' , '27001' , 'Luksemburg'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tango' , '27077' , 'Luksemburg'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Voxmobile' , '27099' , 'Luksemburg'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3' , '45503' , 'Macao (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3' , '45505' , 'Macao (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('China Telecom' , '45502' , 'Macao (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CTM' , '45501' , 'Macao (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CTM' , '45504' , 'Macao (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SmarTone' , '45500' , 'Macao (People\'s Republic of China)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '64602' , 'Madagascar'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sacel' , '64603' , 'Madagascar'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telma' , '64604' , 'Madagascar'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '64601' , 'Madagascar'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TNM' , '65001' , 'Malawi'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '65010' , 'Malawi'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ATUR 450' , '50201' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Baraka Telecom Sdn Bhd (MVNE)' , '502151' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Celcom' , '50213' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Celcom' , '50219' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DiGi' , '50216' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DiGi Telecommunications' , '50210' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Electcoms Wireless Sdn Bhd' , '50220' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Maxis' , '50212' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Maxis' , '50217' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telekom Malaysia Berhad for PSTN SMS' , '50214' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TM Homeline' , '50211' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tune Talk Sdn Bhd' , '502150' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('U Mobile' , '50218' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Yes' , '502152' , 'Malaysia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Dhiraagu' , '47201' , 'Maldives'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Wataniya' , '47202' , 'Maldives'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Malitel' , '61001' , 'Mali'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '61002' , 'Mali'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('GO' , '27821' , 'Malta'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Melita' , '27877' , 'Malta'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '27801' , 'Malta'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Chinguitel' , '60902' , 'Mauretania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mattel' , '60901' , 'Mauretania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mauritel' , '60910' , 'Mauretania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Emtel' , '61710' , 'Mauritius'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mahanagar Telephone (Mauritius) Ltd.' , '61702' , 'Mauritius'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '61701' , 'Mauritius'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Iusacell' , '334050' , 'Mexico'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '33403' , 'Mexico'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '334030' , 'Mexico'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nextel' , '33401' , 'Mexico'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nextel' , '334010' , 'Mexico'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telcel' , '33402' , 'Mexico'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telcel' , '334020' , 'Mexico'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('FSM Telecom' , '55001' , 'Micronesia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Eventis' , '25904' , 'Moldova'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IDC' , '25903' , 'Moldova'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Moldcell' , '25902' , 'Moldova'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '25901' , 'Moldova'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('UnitÃ©' , '25905' , 'Moldova'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('UnitÃ©' , '25999' , 'Moldova'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Office des Telephones' , '21201' , 'Monaco'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('G.Mobile' , '42898' , 'Mongolia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MobiCom' , '42899' , 'Mongolia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Skytel' , '42891' , 'Mongolia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Unitel' , '42888' , 'Mongolia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('m:tel CG' , '29703' , 'Montenegro'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '22004' , 'Montenegro'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '29702' , 'Montenegro'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '29704' , 'Montenegro'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telenor Montenegro' , '29701' , 'Montenegro'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IAM' , '60401' , 'Morocco'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('INWI' , '60405' , 'Morocco'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MÃ©ditel' , '60400' , 'Morocco'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('mCel' , '64301' , 'Mozambique'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodacom' , '64304' , 'Mozambique'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MPT' , '41401' , 'Myanmar'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cell One' , '64903' , 'Namibia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTC' , '64901' , 'Namibia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('switch' , '64902' , 'Namibia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '53602' , 'Nauru'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mero Mobile' , '42902' , 'Nepal'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nepal Telecom' , '42901' , 'Nepal'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SmartCell' , '42904' , 'Nepal'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('United Telecom Limited' , '42903' , 'Nepal'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BayÃ²s' , '36294' , 'Netherlands Antilles (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '36269' , 'Netherlands Antilles (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MIO' , '36295' , 'Netherlands Antilles (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telcell' , '36251' , 'Netherlands Antilles (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('UTS' , '36291' , 'Netherlands Antilles (Netherlands)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobilis' , '54601' , 'New Caledonia (France)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('NZ Comms' , '53024' , 'New Zealand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecom' , '53000' , 'New Zealand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecom' , '53002' , 'New Zealand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecom' , '53005' , 'New Zealand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TelstraClear' , '53004' , 'New Zealand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '53001' , 'New Zealand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Woosh' , '53003' , 'New Zealand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Two Degrees Mobile' , '53024' , 'New Zealand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '71021' , 'Nicaragua'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '71030' , 'Nicaragua'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SERCOM' , '71073' , 'Nicaragua'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '61404' , 'Niger'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SahelCom' , '61401' , 'Niger'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecel' , '61403' , 'Niger'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '61402' , 'Niger'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Etisalat' , '62160' , 'Nigeria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Glo' , '62150' , 'Nigeria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('M-Tel' , '62140' , 'Nigeria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN' , '62130' , 'Nigeria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Visafone' , '62125' , 'Nigeria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '62120' , 'Nigeria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecom Niue' , '55501' , 'Niue'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Koryolink' , '467192' , 'North Korea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SUN NET' , '467193' , 'North Korea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Barablu Mobile Norway Ltd' , '24209' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ice' , '24206' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Jernbaneverket AS' , '24220' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Lyca' , '24223' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTU' , '24203' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('NetCom' , '24202' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Network Norway' , '24205' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SystemNet' , '24211' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TDC Mobil AS' , '24208' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tele2' , '24204' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telenor' , '24201' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telia' , '--' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ventelo' , '24207' , 'Norway'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nawras' , '42203' , 'Oman'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Oman Mobile' , '42202' , 'Oman'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Megafon' , '25030' , 'Osetia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Instaphone' , '41008' , 'Pakistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobilink' , '41001' , 'Pakistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telenor' , '41006' , 'Pakistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ufone' , '41003' , 'Pakistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Warid' , '41007' , 'Pakistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zong' , '41004' , 'Pakistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Palau Mobile' , '55280' , 'Palau'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('PNCC' , '55201' , 'Palau'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('JAWWAL' , '42505' , 'Palestine'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Wataniya' , '42506' , 'Palestine'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless' , '71401' , 'Panama'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '71404' , 'Panama'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('laro' , '71403' , 'Panama'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '71402' , 'Panama'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('B-Mobile' , '53701' , 'Papua New Guinea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '53703' , 'Papua New Guinea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '74402' , 'Paraguay'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Copaco' , '74406' , 'Paraguay'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Personal' , '74405' , 'Paraguay'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tigo' , '74404' , 'Paraguay'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('VOX' , '74401' , 'Paraguay'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '71610' , 'Peru'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '71606' , 'Peru'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('NEXTEL' , '71607' , 'Peru'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ACeS Philippines' , '51511' , 'Philippines'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digitel' , '51505' , 'Philippines'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Globe' , '51502' , 'Philippines'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Islacom' , '51501' , 'Philippines'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nextel' , '51588' , 'Philippines'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Red Mobile' , '51518' , 'Philippines'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Smart Gold' , '51503' , 'Philippines'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Aero2' , '26017' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CenterNet' , '26015' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cyfrowy Polsat' , '26012' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('E-Telko' , '26008' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobyland' , '26016' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nordisk Polska' , '26011' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '26003' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Play' , '26006' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Plus' , '26001' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Polska Telefonia KomÃ³rkowa Centertel Sp. z o.o.' , '26005' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Premium Internet' , '26007' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sferia' , '26013' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-mobile' , '26002' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tele2' , '26004' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telefony Opalenickie' , '26010' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telekomunikacja Kolejowa' , '26009' , 'Poland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Optimus' , '26803' , 'Portugal'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TMN' , '26806' , 'Portugal'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '26801' , 'Portugal'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zapp' , '26821' , 'Portugal'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '33011' , 'Puerto Rico'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '330110' , 'Puerto Rico'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Open Mobile' , '33000' , 'Puerto Rico'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ministry of Interior' , '42705' , 'Qatar'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Qatarnet' , '42701' , 'Qatar'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '42702' , 'Qatar'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Libertis Telecom' , '62910' , 'Republic of Congo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Warid Telecom' , '62907' , 'Republic of Congo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '62901' , 'Republic of Congo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cosmofon' , '29402' , 'Republic of Macedonia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '29401' , 'Republic of Macedonia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('VIP' , '29403' , 'Republic of Macedonia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '64700' , 'Reunion (France)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Outremer' , '64702' , 'Reunion (France)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SFR Reunion' , '64710' , 'Reunion (France)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cosmote' , '22603' , 'Romania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DIGI.mobil' , '22605' , 'Romania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Enigma-System' , '22611' , 'Romania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '22610' , 'Romania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Romtelecom' , '22602' , 'Romania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '22601' , 'Romania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zapp' , '22604' , 'Romania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zapp' , '22606' , 'Romania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Baykalwestcom' , '25012' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Beeline' , '25028' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Beeline' , '25099' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DTC' , '25010' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ETK' , '25005' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('INDIGO' , '25019' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KUGSM' , '25013' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MegaFon' , '25002' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobicom - Novosibirsk' , '25023' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MOTIV' , '25035' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTS' , '25001' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('NCC' , '25003' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('NTC' , '25016' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orensot' , '25011' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Primtelefon' , '25092' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sibchallenge' , '25004' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Skylink' , '25006' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Skylink' , '25009' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SMARTS' , '25007' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SMARTS' , '25014' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SMARTS' , '25015' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Stavtelesot / North Caucasian GSM' , '25044' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tambov GSM' , '25038' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tele2' , '25020' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecom XXI' , '25093' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Utel' , '25017' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Utel' , '25039' , 'Russian Federation'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN' , '63510' , 'Rwanda'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Rwandatel' , '63512' , 'Rwanda'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tigo' , '63513' , 'Rwanda'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless' , '356110' , 'Saint Kitts and Nevis'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Chippie' , '356070' , 'Saint Kitts and Nevis'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '356050' , 'Saint Kitts and Nevis'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless' , '358110' , 'Saint Lucia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '358050' , 'Saint Lucia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless' , '360110' , 'Saint Vincent and the Grenadines'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cingular Wireless' , '360100' , 'Saint Vincent and the Grenadines'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '360050' , 'Saint Vincent and the Grenadines'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '360070' , 'Saint Vincent and the Grenadines'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ameris' , '30801' , 'Saint-Pierre and Miquelon (France)'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '54901' , 'Samoa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SamoaTel' , '54927' , 'Samoa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('PRIMA' , '29201' , 'San Marino'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CSTmovel' , '62601' , 'Sao Tome and Principe'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('EAE' , '42007' , 'Saudi Arabia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobily' , '42003' , 'Saudi Arabia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('STC' , '42001' , 'Saudi Arabia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain SA' , '42004' , 'Saudi Arabia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Expresso' , '60803' , 'Senegal'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sentel GSM' , '60802' , 'Senegal'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sonatel ALIZE' , '60801' , 'Senegal'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telekom Srbija' , '22003' , 'Serbia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telenor' , '22001' , 'Serbia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('VIP Mobile' , '22005' , 'Serbia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless (Seychelles) Ltd.' , '63301' , 'Seychelles'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mediatech International' , '63302' , 'Seychelles'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecom Airtel' , '63310' , 'Seychelles'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Africell' , '61905' , 'Sierra Leone'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Comium' , '61904' , 'Sierra Leone'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Datatel' , '61903' , 'Sierra Leone'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('LeoneCel' , '619?' , 'Sierra Leone'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Millicom' , '61902' , 'Sierra Leone'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobitel' , '61925' , 'Sierra Leone'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '61901' , 'Sierra Leone'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digital Trunked Radio Network' , '52512' , 'Singapore'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('M1' , '52503' , 'Singapore'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SingTel' , '52501' , 'Singapore'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SingTel-G18' , '52502' , 'Singapore'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('StarHub' , '52505' , 'Singapore'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobile Entertainment Company' , '23105' , 'Slovakia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('O2' , '23106' , 'Slovakia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '23101' , 'Slovakia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '23102' , 'Slovakia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '23104' , 'Slovakia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Unient Communications' , '23103' , 'Slovakia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Å½SR' , '23199' , 'Slovakia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobitel' , '29341' , 'Slovenia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SI.mobil - Vodafone' , '29340' , 'Slovenia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-2' , '29364' , 'Slovenia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tusmobil' , '29370' , 'Slovenia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BREEZE' , '54001' , 'Solomon Islands'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BREEZE' , '5401' , 'Solomon Islands'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Golis' , '63730' , 'Somalia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hormuud' , '63725' , 'Somalia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nationlink' , '63710' , 'Somalia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nationlink Telecom' , '63760' , 'Somalia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Somafone' , '63704' , 'Somalia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telcom Mobile' , '638' , 'Somalia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telesom' , '63701' , 'Somalia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telesom' , '63782' , 'Somalia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Bokamoso Consortium' , '65530' , 'South Africa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cape Town Metropolitan Council' , '65521' , 'South Africa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cell C' , '65507' , 'South Africa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ilizwi Telecommunications' , '65532' , 'South Africa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Karabo Telecoms (Pty) Ltd.' , '65531' , 'South Africa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN' , '65510' , 'South Africa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Neotel' , '65513' , 'South Africa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SAPS Gauteng' , '65511' , 'South Africa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sentech' , '65506' , 'South Africa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telkom Mobile / 8.ta' , '65502' , 'South Africa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Thinta Thinta Telecommunications' , '65533' , 'South Africa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodacom' , '65501' , 'South Africa'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KT' , '45004' , 'South Korea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KTF' , '45008' , 'South Korea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KTF CDMA' , '45002' , 'South Korea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('LGU+' , '45006' , 'South Korea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Power 017' , '45003' , 'South Korea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SK Telecom' , '45005' , 'South Korea'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BARABLU MÃ“VIL ESPANA' , '21423' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BT' , '21415' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DigiMobil' , '21422' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Eroski' , '21424' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Euskaltel' , '21408' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Fonyou' , '21420' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('LycaMobile' , '21425' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '21407' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MÃ³bil R' , '21417' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ONO' , '21418' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '21403' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '21409' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Simyo' , '21419' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TeleCable' , '21416' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TME' , '21405' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '21401' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '21406' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Yoigo' , '21404' , 'Spain'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '41305' , 'Sri Lanka'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Dialog' , '41302' , 'Sri Lanka'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hutch Sri Lanka' , '41308' , 'Sri Lanka'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobitel' , '41301' , 'Sri Lanka'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tigo' , '41303' , 'Sri Lanka'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobitel / Mobile Telephone Company' , '63401' , 'Sudan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN' , '63402' , 'Sudan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sudani One' , '63407' , 'Sudan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vivacell' , '63405' , 'Sudan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '74603' , 'Suriname'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telesu' , '74602' , 'Suriname'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uniqa' , '74604' , 'Suriname'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Swazi MTN' , '65310' , 'Swaziland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3 HUTCHISON' , '24002' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3G Infrastructure Services' , '24004' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('42IT' , '24016' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Banverket' , '24021' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Barablu Mobile Scandinavia' , '24012' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Beepsend' , '24026' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DigiTelMobile' , '24025' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Gotanet' , '24017' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Halebop' , '24000' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Lindholmen Science Park' , '24011' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobile Arts AB' , '24033' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nordisk Mobiltelefon' , '24003' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SpringMobil' , '24010' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sweden 2G' , '24024' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sweden 2G' , '24024' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sweden 3G' , '24005' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TDC Mobil' , '24014' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tele2Comviq' , '24007' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telenor' , '24006' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telenor' , '24008' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telenor Mobile Sverige' , '24009' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TeliaSonera Mobile Networks' , '24001' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ventelo Sverige' , '24013' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Wireless Maingate' , '24020' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Wireless Maingate Nordic' , '24015' , 'Sweden'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3G Mobile AG' , '22850' , 'Switzerland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BebbiCell AG' , '22851' , 'Switzerland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IN&Phone' , '22807' , 'Switzerland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '22803' , 'Switzerland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SBB AG' , '22806' , 'Switzerland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sunrise' , '22802' , 'Switzerland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Swisscom' , '22801' , 'Switzerland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tele2' , '22808' , 'Switzerland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Togewanet AG (Comfone)' , '22805' , 'Switzerland'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN Syria' , '41702' , 'Syria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SyriaTel' , '41701' , 'Syria'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('APTG' , '46602' , 'Taiwan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('APTG' , '46605' , 'Taiwan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Chunghwa LDM' , '46611' , 'Taiwan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Chungwa' , '46692' , 'Taiwan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('FarEasTone' , '46601' , 'Taiwan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('KG Telecom' , '46688' , 'Taiwan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MobiTai' , '46693' , 'Taiwan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Taiwan Mobile' , '46697' , 'Taiwan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TransAsia' , '46699' , 'Taiwan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tuntex' , '46606' , 'Taiwan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('VIBO' , '46689' , 'Taiwan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Babilon-M' , '43604' , 'Tajikistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CTJTHSC Tajik-tel' , '43605' , 'Tajikistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Indigo' , '43602' , 'Tajikistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MLT' , '43603' , 'Tajikistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Somoncom' , '43601' , 'Tajikistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tcell' , '43612' , 'Tajikistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Hits' , '64009' , 'Tanzania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mobitel' , '64002' , 'Tanzania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sasatel' , '64006' , 'Tanzania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SmileCom' , '64011' , 'Tanzania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tritel' , '64001' , 'Tanzania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TTCL Mobile' , '64007' , 'Tanzania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TTCL Mobile' , '64008' , 'Tanzania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodacom' , '64004' , 'Tanzania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '64005' , 'Tanzania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zantel' , '64003' , 'Tanzania'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ACT Mobile' , '52015' , 'Thailand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Advanced Info Service' , '52001' , 'Thailand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Advanced Info Service' , '52023' , 'Thailand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CAT CDMA' , '52000' , 'Thailand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CAT CDMA' , '52002' , 'Thailand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('DTAC' , '52018' , 'Thailand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('True Move' , '52099' , 'Thailand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('WCS IQ' , '52010' , 'Thailand'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Moov' , '61503' , 'Togo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecel' , '61505' , 'Togo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Togo Cell' , '61501' , 'Togo'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '53988' , 'Tonga'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Shoreline Communication' , '53943' , 'Tonga'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tonga Communications Corporation' , '53901' , 'Tonga'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('bmobile' , '37412' , 'Trinidad and Tobago'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '37413' , 'Trinidad and Tobago'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '374130' , 'Trinidad and Tobago'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '60501' , 'Tunisia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tunicell' , '60502' , 'Tunisia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tunisiana' , '60503' , 'Tunisia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Avea' , '28603' , 'Turkey'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Aycell' , '28604' , 'Turkey'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Turkcell' , '28601' , 'Turkey'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '28602' , 'Turkey'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTS' , '43801' , 'Turkmenistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TM-Cell' , '43802' , 'Turkmenistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('TTC' , '55301' , 'Tuvalu'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN' , '64110' , 'Uganda'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '64114' , 'Uganda'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uganda Telecom Ltd.' , '64111' , 'Uganda'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Warid Telecom' , '64122' , 'Uganda'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '64101' , 'Uganda'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Beeline' , '25502' , 'Ukraine'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('CDMA Ukraine' , '25523' , 'Ukraine'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Golden Telecom' , '25505' , 'Ukraine'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('IT' , '25504' , 'Ukraine'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Kyivstar' , '25503' , 'Ukraine'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('life:)' , '25506' , 'Ukraine'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTS' , '25501' , 'Ukraine'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('PEOPLEnet' , '25521' , 'Ukraine'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Utel' , '25507' , 'Ukraine'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('du' , '42403' , 'United Arab Emirates'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Etisalat' , '42402' , 'United Arab Emirates'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3 Hutchison' , '23420' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('BT' , '23400' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cable & Wireless / Sure Mobile (Isle of Man)' , '23455' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cloud9' , '23418' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Jersey Telenet' , '23403' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('JT-Wave' , '23450' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Manx Telecom' , '23458' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MCom' , '23401' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('O2' , '23402' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('O2' , '23410' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('O2' , '23411' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '23433' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Orange' , '23434' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Railtrack' , '23412' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Routo Telecom' , '23422' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sure Mobile' , '23409' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '23430' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telaware' , '23419' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Tesco Mobile' , '234100' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Unknown' , '23477' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Virgin' , '23431' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Virgin' , '23432' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vodafone' , '23415' , 'United Kingdom'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Advantage' , '310880' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Aeris' , '310850' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airadigm' , '310640' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airlink PCS' , '310780' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airpeak' , '310034' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Airtel' , '310510' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Alaska Digitel' , '310430' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Alltel' , '310500' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Alltel' , '310590' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AmeriLink PCS' , '310630' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AT&T' , '310038' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AT&T' , '310090' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AT&T' , '310150' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AT&T' , '310170' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AT&T' , '310410' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AT&T' , '310560' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AT&T' , '310680' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AT&T Mobility' , '310380' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AT&T Mobility' , '310980' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('AT&T Mobility' , '310990' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Caprock' , '310830' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Carolina Phone' , '310350' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cell One Amarillo' , '311130' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cellular One' , '310320' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cellular One' , '310440' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cellular One of East Texas' , '310390' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cellular Properties' , '311190' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Centennial' , '310030' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Chariton Valley' , '311010' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Chinook Wireless' , '310570' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Choice Phone' , '310480' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Choice Phone' , '311120' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cincinnati Bell' , '310420' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cingular Wireless' , '311180' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Coleman County Telecom' , '310620' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Commnet Wireless' , '311040' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Concho' , '310040' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Conestoga' , '310690' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Consolidated Telcom' , '310060' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Convey' , '310740' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Corr' , '310080' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Cricket Communications' , '310016' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digital Cellular' , '310940' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Dutch Harbor' , '310190' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Easterbrooke' , '311070' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Endless Mountains Wireless' , '311160' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Epic Touch' , '310610' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Farmers Cellular' , '311060' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Farmers Cellular' , '311210' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Farmers Wireless' , '310311' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('First Cellular' , '310910' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Get Mobile Inc' , '310300' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Globalstar' , '310970' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('High Plains Wireless' , '311100' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('High Plains Wireless' , '311110' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Highland Cellular' , '310070' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('i CAN_GSM' , '310400' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('i wireless' , '310770' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Indigo Wireless' , '311030' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Jasper' , '310650' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Long Lines Wireless' , '311090' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MCI' , '310010' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mid-Tex Cellular' , '310000' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Mid-Tex Cellular' , '311000' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Missouri RSA 5 Partnership' , '311020' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MobileTel' , '310013' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Nextel' , '316010' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('North Sight Communications Inc.' , '310017' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Northstar' , '310670' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Oklahoma Western' , '310540' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('PACE' , '310870' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Panhandle' , '310760' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('PetroCom' , '311170' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Pine Cellular' , '311080' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('PinPoint' , '310790' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Plateau Wireless' , '310100' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Plateau Wireless' , '310960' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('PTI Pacifica' , '310110' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SeaMobile' , '310730' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SIMMETRY' , '310046' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Simmetry' , '310460' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Southern Communications Services' , '316011' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sprint' , '310120' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Sprocket' , '311140' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SunCom' , '310490' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310026' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310160' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310200' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310210' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310220' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310230' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310240' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310250' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310260' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310270' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310280' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310290' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310310' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310330' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310580' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310660' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('T-Mobile' , '310800' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Taylor' , '310900' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Testing' , '310014' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Union Telephone Company' , '310020' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('VeriSign' , '310520' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Verizon' , '310004' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Verizon' , '310012' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Viaero' , '310450' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('West Central' , '310180' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('West Virginia Wireless' , '310530' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Westlink' , '310340' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Wikes Cellular' , '311050' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Wilkes Cellular' , '311150' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Wireless Alliance' , '310890' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('XIT Wireless' , '310950' , 'United States'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ancel' , '74800' , 'Uruguay'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ancel' , '74801' , 'Uruguay'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Claro' , '74810' , 'Uruguay'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Movistar' , '74807' , 'Uruguay'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Beeline' , '43404' , 'Uzbekistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Buztel' , '43401' , 'Uzbekistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTS' , '43407' , 'Uzbekistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Perfectum Mobile' , '43406' , 'Uzbekistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Ucell' , '43405' , 'Uzbekistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Uzmacom' , '43402' , 'Uzbekistan'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SMILE' , '54101' , 'Vanuatu'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digitel' , '73401' , 'Venezuela'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digitel' , '73402' , 'Venezuela'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digitel' , '73403' , 'Venezuela'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Movilnet' , '73406' , 'Venezuela'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('movistar' , '73404' , 'Venezuela'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('3G EVNTelecom' , '45208' , 'Vietnam'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Beeline VN' , '45207' , 'Vietnam'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('E-Mobile' , '45206' , 'Vietnam'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('HT Mobile' , '45205' , 'Vietnam'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MobiFone' , '45201' , 'Vietnam'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('S-Fone' , '45203' , 'Vietnam'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Viettel Mobile' , '45204' , 'Vietnam'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Vinaphone' , '45202' , 'Vietnam'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('C&W' , '376350' , 'Wyspy Turks i Caicos'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Digicel' , '33805' , 'Wyspy Turks i Caicos'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Islandcom' , '376352' , 'Wyspy Turks i Caicos'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('HiTS-UNITEL' , '42104' , 'Yemen'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN' , '42102' , 'Yemen'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('SabaFon' , '42101' , 'Yemen'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Yemen Mobile' , '42103' , 'Yemen'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('MTN' , '64502' , 'Zambia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Zain' , '64501' , 'Zambia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('ZAMTEL' , '64503' , 'Zambia'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Econet' , '64804' , 'Zimbabwe'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Net*One' , '64801' , 'Zimbabwe'); 
INSERT INTO `Table_Mobile_Network`(`_NETWORK_NAME`, `_CODE`, `_COUNTRY_NAME`) VALUES ('Telecel' , '64803' , 'Zimbabwe'); 

INSERT INTO `Table_System` (`_ACTIV`, `_VERSION`, `_APPLICATION_NAME`, `_SERVER_CURRENT_PATH`, `_SERVER_NEW_PATH`, `_POWER_BY`,`_INCRIMENT_PRICE_AFTER` ,`_INCRIMENT_PRICE`, `_LOG_SYSTEM`, `_CAN_GET_DATA_FROM_BROWSER`, `_IS_UPDATE`, `_IS_ONLINE_SERVER`, `_SYSTEM_USER_ID`, `_ENCRIPTION_BUFFER`, `_POINT_PRICE`, `_LIKE_TO_POINT`, `_NORMAL_SCORE`, `_VIP_SCORE`, `_MINIMAM_SEND_TO_STOCK`, `_MAXIMAM_SEND_TO_STOCK`, `_SHOW_UNLIKE`, `_SHOW_LIKE`, `_SHOW_TOP_IN_GLOBEL`, `_SHOW_TOP_IN_ZONE`, `_SHOW_STOCK_IN_USERS_LIST`, `_SHOW_POINTS_IN_USER_LIST`, `_LIMITED_FOR_NETWORK`, `_ICON_FOR_VIP`, `_ICON_FOR_FAMUS`, `_ICON_FOR_LEVEL_1`, `_ICON_FOR_LEVEL_2`, `_ICON_FOR_LEVEL_3`, `_ICON_FOR_LEVEL_4`, `_ICON_FOR_LEVEL_5`, `_ICON_FOR_LEVEL_6`) VALUES
(1, '1.0.0', 'SuperWoW', '/SuperWoW/Interface.php', 'null', 'Seif Abaza',10,1, 1, 1, 0, 0, 0, 0, 0.14, 50, 0, 50, 1, 1000000, 1, 1, 0, 1, 0, 0, '127.0.0.', '/data/image/icons/VIP/vip2.png', '/data/image/icons/FAMUSE/famuse.png', '/data/image/icons/LEVEL/1.png', '/data/image/icons/LEVEL/2.png', '/data/image/icons/LEVEL/3.png', '/data/image/icons/LEVEL/4.png', '/data/image/icons/LEVEL/5.png', '/data/image/icons/LEVEL/6.png');

INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('abkhazia', 'abkhazia-flag.png', 'ab', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('afghanistan', 'afghanistan-flag.png', 'af', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('albania', 'albania-flag.png', 'al', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('algeria', 'algeria-flag.png', 'dz', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('american samoa', 'american-samoa-flag.png', 'as', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('andorra', 'andorra-flag.png', 'ad', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('angola', 'angola-flag.png', 'ao', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('anguilla', 'anguilla-flag.png', 'ai', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('antarctica', 'antarctica-flag.png', 'aq', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('antigua and barbuda', 'antigua-and-barbuda-flag.png', 'ag', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('argentina', 'argentina-flag.png', 'ar', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('armenia', 'armenia-flag.png', 'am', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('aruba', 'aruba-flag.png', 'aw', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('australia', 'australia-flag.png', 'au', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('austria', 'austria-flag.png', 'at', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('azerbaijan', 'azerbaijan-flag.png', 'az', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('bahamas', 'bahamas-flag.png', 'bs', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('bahrain', 'bahrain-flag.png', 'bh', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('bangladesh', 'bangladesh-flag.png', 'bd', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('barbados', 'barbados-flag.png', 'bb', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('belarus', 'belarus-flag.png', 'by', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('belgium', 'belgium-flag.png', 'be', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('belize', 'belize-flag.png', 'bz', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('benin', 'benin-flag.png', 'bj', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('bermuda', 'bermuda-flag.png', 'bm', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('bhutan', 'bhutan-flag.png', 'bt', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('bolivia', 'bolivia-flag.png', 'bo', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('bosnia-and-herzegovina', 'bolivia-flag.png', 'ba', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('botswana', 'botswana-flag.png', 'bw', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('bouvet island', 'bouvet-island-flag.png', 'bv', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('brazil', 'brazil-flag.png', 'br', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('british antarctic territory', 'british-antarctic-territory-flag.png', 'bq', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('british-indian-ocean-territory', 'british-antarctic-territory-flag.png', 'io', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('british virgin islands', 'british-virgin-islands-flag.png', 'vg', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('brunei', 'brunei-flag.png', 'bn', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('bulgaria', 'bulgaria-flag.png', 'bg', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('burkina faso', 'burkina-faso-flag.png', 'bf', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('burundi', 'burundi-flag.png', 'bi', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('cambodia', 'cambodia-flag.png', 'kh', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('cameroon', 'cameroon-flag.png', 'cm', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('canada', 'canada-flag.png', 'ca', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('canton-and-enderbury-islands', 'canada-flag.png', 'ct', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('cape verde', 'cape-verde-flag.png', 'cv', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('cayman islands', 'cayman-islands-flag.png', 'ky', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('central-african-republic', 'cayman-islands-flag.png', 'cf', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('chad', 'chad-flag.png', 'td', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('chile', 'chile-flag.png', 'cl', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('china', 'china-flag.png', 'cn', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('christmas island', 'christmas-island-flag.png', 'cx', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('cocos-[keeling]-islands', 'christmas-island-flag.png', 'cc', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('colombia', 'colombia-flag.png', 'co', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('comoros', 'comoros-flag.png', 'km', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('congo---brazzaville', 'comoros-flag.png', 'cg', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('congo---kinshasa', 'comoros-flag.png', 'cd', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('cook islands', 'cook-islands-flag.png', 'ck', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('costa rica', 'costa-rica-flag.png', 'cr', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('croatia', 'croatian-flag.png', 'hr', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('cuba', 'cuba-flag.png', 'cu', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('cyprus', 'cyprus-flag.png', 'cy', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('czech republic', 'czech-republic-flag.png', 'cz', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('côte-d’ivoire', 'czech-republic-flag.png', 'ci', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('denmark', 'denmark-flag.png', 'dk', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('djibouti', 'djibouti-flag.png', 'dj', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('dominica', 'dominica-flag.png', 'dm', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('dominican republic', 'dominican-republic-flag.png', 'do', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('dronning-maud-land', 'dominican-republic-flag.png', 'nq', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('east-germany', 'dominican-republic-flag.png', 'dd', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('ecuador', 'ecuador-flag.png', 'ec', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('egypt', 'egypt-flag.png', 'eg', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('el salvador', 'el-salvador-flag.png', 'sv', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('equatorial guinea', 'equatorial-guinea-flag.png', 'gq', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('eritrea', 'eritrea-flag.png', 'er', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('estonia', 'estonia-flag.png', 'ee', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('ethiopia', 'ethiopia-flag.png', 'et', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('falkland islands', 'falkland-islands-flag.png', 'fk', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('faroe islands', 'faroe-islands-flag.png', 'fo', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('fiji', 'fiji-flag.png', 'fj', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('finland', 'finland-flag.png', 'fi', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('france', 'france-flag.png', 'fr', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('french-guiana', 'france-flag.png', 'gf', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('french polynesia', 'french-polynesia-flag.png', 'pf', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('french southern territories', 'french-southern-territories-flag.png', 'tf', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('french-southern-and-antarctic-territories', 'french-southern-territories-flag.png', 'fq', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('gabon', 'gabon-flag.png', 'ga', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('gambia', 'gambia-flag.png', 'gm', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('georgia', 'georgia-flag.png', 'ge', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('germany', 'germany-flag.png', 'de', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('ghana', 'ghana-flag.png', 'gh', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('gibraltar', 'gibraltar-flag.png', 'gi', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('greece', 'greece-flag.png', 'gr', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('greenland', 'greenland-flag.png', 'gl', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('grenada', 'grenada-flag.png', 'gd', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('guadeloupe', 'guadeloupe-flag.png', 'gp', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('guam', 'guam-flag.png', 'gu', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('guatemala', 'guatemala-flag.png', 'gt', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('guernsey', 'guernsey-flag.png', 'gg', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('guinea', 'equatorial-guinea-flag.png', 'gn', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('guinea bissau', 'guinea-bissau-flag.png', 'gw', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('guyana', 'guyana-flag.png', 'gy', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('haiti', 'haiti-flag.png', 'ht', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('heard-island-and-mcdonald-islands', 'haiti-flag.png', 'hm', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('honduras', 'honduras-flag.png', 'hn', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('hong-kong-sar-china', 'honduras-flag.png', 'hk', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('hungary', 'hungary-flag.png', 'hu', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('iceland', 'iceland-flag.png', 'is', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('india', 'india-flag.png', 'in', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('indonesia', 'indonesia-flag.png', 'id', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('iran', 'iran-flag.png', 'ir', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('iraq', 'iraq-flag.png', 'iq', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('ireland', 'ireland-flag.png', 'ie', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('isle of man', 'isle-of-man-flag.png', 'im', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('israel', 'israel-flag.png', 'il', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('italy', 'italy-flag.png', 'it', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('jamaica', 'jamaica-flag.png', 'jm', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('japan', 'japan-flag.png', 'jp', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('jersey', 'jersey-flag.png', 'je', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('johnston-island', 'jersey-flag.png', 'jt', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('jordan', 'jordan-flag.png', 'jo', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('kazakhstan', 'kazakhstan-flag.png', 'kz', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('kenya', 'kenya-flag.png', 'ke', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('kiribati', 'kiribati-flag.png', 'ki', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('kuwait', 'kuwait-flag.png', 'kw', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('kyrgyzstan', 'kyrgyzstan-flag.png', 'kg', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('laos', 'laos-flag.png', 'la', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('latvia', 'latvia-flag.png', 'lv', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('lebanon', 'lebanon-flag.png', 'lb', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('lesotho', 'lesotho-flag.png', 'ls', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('liberia', 'liberia-flag.png', 'lr', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('libya', 'libya-flag.png', 'ly', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('liechtenstein', 'liechtenstein-flag.png', 'li', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('lithuania', 'lithuania-flag.png', 'lt', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('luxembourg', 'luxembourg-flag.png', 'lu', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('macau-sar-china', 'luxembourg-flag.png', 'mo', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('macedonia', 'macedonia-flag.png', 'mk', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('madagascar', 'madagascar-flag.png', 'mg', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('malawi', 'malawi-flag.png', 'mw', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('malaysia', 'malaysia-flag.png', 'my', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('maldives', 'maldives-flag.png', 'mv', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('mali', 'mali-flag.png', 'ml', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('malta', 'malta-flag.png', 'mt', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('marshall islands', 'marshall-islands-flag.png', 'mh', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('martinique', 'martinique-flag.png', 'mq', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('mauritania', 'mauritania-flag.png', 'mr', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('mauritius', 'mauritius-flag.png', 'mu', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('mayotte', 'mayotte-flag.png', 'yt', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('metropolitan-france', 'mayotte-flag.png', 'fx', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('mexico', 'mexico-flag.png', 'mx', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('micronesia', 'micronesia-flag.png', 'fm', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('midway-islands', 'micronesia-flag.png', 'mi', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('moldova', 'moldova-flag.png', 'md', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('monaco', 'monaco-flag.png', 'mc', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('mongolia', 'mongolia-flag.png', 'mn', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('montenegro', 'montenegro-flag.png', 'me', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('montserrat', 'montserrat-flag.png', 'ms', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('morocco', 'morocco-flag.png', 'ma', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('mozambique', 'mozambique-flag.png', 'mz', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('myanmar-[burma]', 'mozambique-flag.png', 'mm', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('namibia', 'namibia-flag.png', 'na', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('nauru', 'nauru-flag.png', 'nr', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('nepal', 'nepal-flag.png', 'np', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('netherlands', 'netherlands-antilles-flag.png', 'nl', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('netherlands antilles', 'netherlands-antilles-flag.png', 'an', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('neutral-zone', 'netherlands-antilles-flag.png', 'nt', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('new caledonia', 'new-caledonia-flag.png', 'nc', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('new zealand', 'new-zealand-flag.png', 'nz', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('nicaragua', 'nicaragua-flag.png', 'ni', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('niger', 'niger-flag.png', 'ne', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('nigeria', 'nigeria-flag.png', 'ng', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('niue', 'niue-flag.png', 'nu', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('norfolk island', 'norfolk-island-flag.png', 'nf', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('north korea', 'north-korea-flag.png', 'kp', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('north-vietnam', 'north-korea-flag.png', 'vd', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('northern mariana islands', 'northern-mariana-islands-flag.png', 'mp', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('norway', 'norway-flag.png', 'no', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('oman', 'oman-flag.png', 'om', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('pacific-islands-trust-territory', 'oman-flag.png', 'pc', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('pakistan', 'pakistan-flag.png', 'pk', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('palau', 'palau-flag.png', 'pw', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('palestinian-territories', 'palau-flag.png', 'ps', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('panama', 'panama-flag.png', 'pa', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('panama-canal-zone', 'panama-flag.png', 'pz', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('papua new guinea', 'papua-new-guinea-flag.png', 'pg', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('paraguay', 'paraguay-flag.png', 'py', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('people"s-democratic-republic-of-yemen', 'paraguay-flag.png', 'yd', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('peru', 'peru-flag.png', 'pe', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('philippines', 'philippines-flag.png', 'ph', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('pitcairn-islands', 'philippines-flag.png', 'pn', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('poland', 'poland-flag.png', 'pl', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('portugal', 'portugal-flag.png', 'pt', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('puerto rico', 'puerto-rico-flag.png', 'pr', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('qatar', 'qatar-flag.png', 'qa', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('romania', 'romania-flag.png', 'ro', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('russia', 'russia-flag.png', 'ru', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('rwanda', 'rwanda-flag.png', 'rw', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('réunion', 'rwanda-flag.png', 're', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('saint-barthélemy', 'rwanda-flag.png', 'bl', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('saint helena', 'saint-helena-and-dependencies-flag.png', 'sh', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('saint kitts and nevis', 'saint-kitts-and-nevis-flag.png', 'kn', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('saint lucia', 'saint-lucia-flag.png', 'lc', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('saint martin', 'saint-martin-flag.png', 'mf', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('saint pierre and miquelon', 'saint-pierre-and-miquelon-flag.png', 'pm', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('saint-vincent-and-the-grenadines', 'saint-pierre-and-miquelon-flag.png', 'vc', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('samoa', 'american-samoa-flag.png', 'ws', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('san marino', 'san-marino-flag.png', 'sm', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('saudi arabia', 'saudi-arabia-flag.png', 'sa', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('senegal', 'senegal-flag.png', 'sn', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('serbia', 'serbia-flag.png', 'rs', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('serbia-and-montenegro', 'serbia-flag.png', 'cs', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('seychelles', 'seychelles-flag.png', 'sc', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('sierra leone', 'sierra-leone-flag.png', 'sl', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('singapore', 'singapore-flag.png', 'sg', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('slovakia', 'slovakia-flag.png', 'sk', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('slovenia', 'slovenia-flag.png', 'si', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('solomon islands', 'solomon-islands-flag.png', 'sb', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('somalia', 'somalia-flag.png', 'so', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('south africa', 'south-africa-flag.png', 'za', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('south-georgia-and-the-south-sandwich-islands', 'south-africa-flag.png', 'gs', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('south-korea', 'south-africa-flag.png', 'kr', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('spain', 'spain-flag.png', 'es', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('sri lanka', 'sri-lanka-flag.png', 'lk', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('sudan', 'south-sudan-flag.png', 'sd', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('suriname', 'suriname-flag.png', 'sr', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('svalbard-and-jan-mayen', 'suriname-flag.png', 'sj', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('swaziland', 'swaziland-flag.png', 'sz', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('sweden', 'sweden-flag.png', 'se', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('switzerland', 'switzerland-flag.png', 'ch', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('syria', 'syria-flag.png', 'sy', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('são-tomé-and-príncipe', 'syria-flag.png', 'st', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('taiwan', 'taiwan-flag.png', 'tw', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('tajikistan', 'tajikistan-flag.png', 'tj', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('tanzania', 'tanzania-flag.png', 'tz', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('thailand', 'thailand-flag.png', 'th', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('timor leste', 'timor-leste-flag.png', 'tl', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('togo', 'togo-flag.png', 'tg', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('tokelau', 'tokelau-flag.png', 'tk', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('tonga', 'tonga-flag.png', 'to', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('trinidad and tobago', 'trinidad-and-tobago-flag.png', 'tt', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('tunisia', 'tunisia-flag.png', 'tn', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('turkey', 'turkey-flag.png', 'tr', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('turkmenistan', 'turkmenistan-flag.png', 'tm', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('turks and caicos islands', 'turks-and-caicos-islands-flag.png', 'tc', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('tuvalu', 'tuvalu-flag.png', 'tv', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('u.s.-minor-outlying-islands', 'tuvalu-flag.png', 'um', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('u.s.-miscellaneous-pacific-islands', 'tuvalu-flag.png', 'pu', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('u.s.-virgin-islands', 'tuvalu-flag.png', 'vi', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('uganda', 'uganda-flag.png', 'ug', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('ukraine', 'ukraine-flag.png', 'ua', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('union-of-soviet-socialist-republics', 'ukraine-flag.png', 'su', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('united arab emirates', 'united-arab-emirates-flag.png', 'ae', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('united kingdom', 'united-kingdom-flag.png', 'gb', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('united states', 'united-states-flag.png', 'us', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('unknown-or-invalid-region', 'united-states-flag.png', 'zz', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('uruguay', 'uruguay-flag.png', 'uy', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('uzbekistan', 'uzbekistan-flag.png', 'uz', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('vanuatu', 'vanuatu-flag.png', 'vu', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('vatican city', 'vatican-city-flag.png', 'va', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('venezuela', 'venezuela-flag.png', 've', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('vietnam', 'vietnam-flag.png', 'vn', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('wake-island', 'vietnam-flag.png', 'wk', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('wallis and futuna', 'wallis-and-futuna-flag.png', 'wf', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('western sahara', 'western-sahara-flag.png', 'eh', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('yemen', 'yemen-flag.png', 'ye', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('zambia', 'zambia-flag.png', 'zm', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('zimbabwe', 'zimbabwe-flag.png', 'zw', '0', 'WP', '0');
INSERT INTO `Table_Country` (`_NAME`, `_PATH_FLAG`, `_CODE`, `_MEMBERS`, `_CORRENSE`, `_PRICE`) VALUES ('aland islands', 'aland-islands-flag.png', 'ax', '0', 'WP', '0');




INSERT INTO `Table_Bad_Word` (`ID`, `_WORD`, `_REPLACEMENT`, `_HOW_TIME`) VALUES
(1, '4r5e', '', 0),
(2, '5h1t', '', 0),
(3, '5hit', '', 0),
(4, 'a_s_s', '', 0),
(5, 'a2m', '', 0),
(6, 'a55', '', 0),
(7, 'adult', '', 0),
(8, 'amateur', '', 0),
(9, 'anal', '', 0),
(10, 'anal impaler', '', 0),
(11, 'anal leakage', '', 0),
(12, 'anilingus', '', 0),
(13, 'anus', '', 0),
(14, 'ar5e', '', 0),
(15, 'arrse', '', 0),
(16, 'arse', '', 0),
(17, 'arsehole', '', 0),
(18, 'ass', '', 0),
(19, 'ass fuck', '', 0),
(20, 'asses', '', 0),
(21, 'assfucker', '', 0),
(22, 'ass-fucker', '', 0),
(23, 'assfukka', '', 0),
(24, 'asshole', '', 0),
(25, 'assholes', '', 0),
(26, 'assmucus', '', 0),
(27, 'assmunch', '', 0),
(28, 'asswhole', '', 0),
(29, 'autoerotic', '', 0),
(30, 'b!tch', '', 0),
(31, 'b00bs', '', 0),
(32, 'b17ch', '', 0),
(33, 'b1tch', '', 0),
(34, 'ballbag', '', 0),
(35, 'ballsack', '', 0),
(36, 'bangbros', '', 0),
(37, 'bareback', '', 0),
(38, 'bastard', '', 0),
(39, 'beastial', '', 0),
(40, 'beastiality', '', 0),
(41, 'beef curtain', '', 0),
(42, 'bellend', '', 0),
(43, 'bestial', '', 0),
(44, 'bestiality', '', 0),
(45, 'bi+ch', '', 0),
(46, 'biatch', '', 0),
(47, 'bimbos', '', 0),
(48, 'birdlock', '', 0),
(49, 'bitch', '', 0),
(50, 'bitch tit', '', 0),
(51, 'bitcher', '', 0),
(52, 'bitchers', '', 0),
(53, 'bitches', '', 0),
(54, 'bitchin', '', 0),
(55, 'bitching', '', 0),
(56, 'bloody', '', 0),
(57, 'blow job', '', 0),
(58, 'blow me', '', 0),
(59, 'blow mud', '', 0),
(60, 'blowjob', '', 0),
(61, 'blowjobs', '', 0),
(62, 'blue waffle', '', 0),
(63, 'blumpkin', '', 0),
(64, 'boiolas', '', 0),
(65, 'bollock', '', 0),
(66, 'bollok', '', 0),
(67, 'boner', '', 0),
(68, 'boob', '', 0),
(69, 'boobs', '', 0),
(70, 'booobs', '', 0),
(71, 'boooobs', '', 0),
(72, 'booooobs', '', 0),
(73, 'booooooobs', '', 0),
(74, 'breasts', '', 0),
(75, 'buceta', '', 0),
(76, 'bugger', '', 0),
(77, 'bum', '', 0),
(78, 'bunny fucker', '', 0),
(79, 'busty', '', 0),
(80, 'butt', '', 0),
(81, 'butt fuck', '', 0),
(82, 'butthole', '', 0),
(83, 'buttmuch', '', 0),
(84, 'buttplug', '', 0),
(85, 'c0ck', '', 0),
(86, 'c0cksucker', '', 0),
(87, 'carpet muncher', '', 0),
(88, 'carpetmuncher', '', 0),
(89, 'cawk', '', 0),
(90, 'chink', '', 0),
(91, 'choade', '', 0),
(92, 'chota bags', '', 0),
(93, 'cipa', '', 0),
(94, 'cl1t', '', 0),
(95, 'clit', '', 0),
(96, 'clit licker', '', 0),
(97, 'clitoris', '', 0),
(98, 'clits', '', 0),
(99, 'clitty litter', '', 0),
(100, 'clusterfuck', '', 0),
(101, 'cnut', '', 0),
(102, 'cock', '', 0),
(103, 'cock pocket', '', 0),
(104, 'cock snot', '', 0),
(105, 'cockface', '', 0),
(106, 'cockhead', '', 0),
(107, 'cockmunch', '', 0),
(108, 'cockmuncher', '', 0),
(109, 'cocks', '', 0),
(110, 'cocksuck', '', 0),
(111, 'cocksucked', '', 0),
(112, 'cocksucker', '', 0),
(113, 'cock-sucker', '', 0),
(114, 'cocksucking', '', 0),
(115, 'cocksucks', '', 0),
(116, 'cocksuka', '', 0),
(117, 'cocksukka', '', 0),
(118, 'cok', '', 0),
(119, 'cokmuncher', '', 0),
(120, 'coksucka', '', 0),
(121, 'coon', '', 0),
(122, 'corp whore', '', 0),
(123, 'cox', '', 0),
(124, 'cum', '', 0),
(125, 'cum chugger', '', 0),
(126, 'cum dumpster', '', 0),
(127, 'cum freak', '', 0),
(128, 'cum guzzler', '', 0),
(129, 'cumdump', '', 0),
(130, 'cummer', '', 0),
(131, 'cumming', '', 0),
(132, 'cums', '', 0),
(133, 'cumshot', '', 0),
(134, 'cunilingus', '', 0),
(135, 'cunillingus', '', 0),
(136, 'cunnilingus', '', 0),
(137, 'cunt', '', 0),
(138, 'cunt hair', '', 0),
(139, 'cuntbag', '', 0),
(140, 'cuntlick', '', 0),
(141, 'cuntlicker', '', 0),
(142, 'cuntlicking', '', 0),
(143, 'cunts', '', 0),
(144, 'cuntsicle', '', 0),
(145, 'cunt-struck', '', 0),
(146, 'cut rope', '', 0),
(147, 'cyalis', '', 0),
(148, 'cyberfuc', '', 0),
(149, 'cyberfuck', '', 0),
(150, 'cyberfucked', '', 0),
(151, 'cyberfucker', '', 0),
(152, 'cyberfuckers', '', 0),
(153, 'cyberfucking', '', 0),
(154, 'd1ck', '', 0),
(155, 'damn', '', 0),
(156, 'dick', '', 0),
(157, 'dick hole', '', 0),
(158, 'dick shy', '', 0),
(159, 'dickhead', '', 0),
(160, 'dildo', '', 0),
(161, 'dildos', '', 0),
(162, 'dink', '', 0),
(163, 'dinks', '', 0),
(164, 'dirsa', '', 0),
(165, 'dlck', '', 0),
(166, 'dog-fucker', '', 0),
(167, 'doggie style', '', 0),
(168, 'doggiestyle', '', 0),
(169, 'doggin', '', 0),
(170, 'dogging', '', 0),
(171, 'donkeyribber', '', 0),
(172, 'doosh', '', 0),
(173, 'duche', '', 0),
(174, 'dyke', '', 0),
(175, 'eat a dick', '', 0),
(176, 'eat hair pie', '', 0),
(177, 'ejaculate', '', 0),
(178, 'ejaculated', '', 0),
(179, 'ejaculates', '', 0),
(180, 'ejaculating', '', 0),
(181, 'ejaculatings', '', 0),
(182, 'ejaculation', '', 0),
(183, 'ejakulate', '', 0),
(184, 'erotic', '', 0),
(185, 'f u c k', '', 0),
(186, 'f u c k e r', '', 0),
(187, 'f_u_c_k', '', 0),
(188, 'f4nny', '', 0),
(189, 'facial', '', 0),
(190, 'fag', '', 0),
(191, 'fagging', '', 0),
(192, 'faggitt', '', 0),
(193, 'faggot', '', 0),
(194, 'faggs', '', 0),
(195, 'fagot', '', 0),
(196, 'fagots', '', 0),
(197, 'fags', '', 0),
(198, 'fanny', '', 0),
(199, 'fannyflaps', '', 0),
(200, 'fannyfucker', '', 0),
(201, 'fanyy', '', 0),
(202, 'fatass', '', 0),
(203, 'fcuk', '', 0),
(204, 'fcuker', '', 0),
(205, 'fcuking', '', 0),
(206, 'feck', '', 0),
(207, 'fecker', '', 0),
(208, 'felching', '', 0),
(209, 'fellate', '', 0),
(210, 'fellatio', '', 0),
(211, 'fingerfuck', '', 0),
(212, 'fingerfucked', '', 0),
(213, 'fingerfucker', '', 0),
(214, 'fingerfuckers', '', 0),
(215, 'fingerfucking', '', 0),
(216, 'fingerfucks', '', 0),
(217, 'fist fuck', '', 0),
(218, 'fistfuck', '', 0),
(219, 'fistfucked', '', 0),
(220, 'fistfucker', '', 0),
(221, 'fistfuckers', '', 0),
(222, 'fistfucking', '', 0),
(223, 'fistfuckings', '', 0),
(224, 'fistfucks', '', 0),
(225, 'flange', '', 0),
(226, 'flog the log', '', 0),
(227, 'fook', '', 0),
(228, 'fooker', '', 0),
(229, 'fuck hole', '', 0),
(230, 'fuck puppet', '', 0),
(231, 'fuck trophy', '', 0),
(232, 'fuck yo mama', '', 0),
(233, 'fuck', '', 0),
(234, 'fucka', '', 0),
(235, 'fuck-ass', '', 0),
(236, 'fuck-bitch', '', 0),
(237, 'fucked', '', 0),
(238, 'fucker', '', 0),
(239, 'fuckers', '', 0),
(240, 'fuckhead', '', 0),
(241, 'fuckheads', '', 0),
(242, 'fuckin', '', 0),
(243, 'fucking', '', 0),
(244, 'fuckings', '', 0),
(245, 'fuckingshitmotherfucker', '', 0),
(246, 'fuckme', '', 0),
(247, 'fuckmeat', '', 0),
(248, 'fucks', '', 0),
(249, 'fucktoy', '', 0),
(250, 'fuckwhit', '', 0),
(251, 'fuckwit', '', 0),
(252, 'fudge packer', '', 0),
(253, 'fudgepacker', '', 0),
(254, 'fuk', '', 0),
(255, 'fuker', '', 0),
(256, 'fukker', '', 0),
(257, 'fukkin', '', 0),
(258, 'fuks', '', 0),
(259, 'fukwhit', '', 0),
(260, 'fukwit', '', 0),
(261, 'fux', '', 0),
(262, 'fux0r', '', 0),
(263, 'gangbang', '', 0),
(264, 'gang-bang', '', 0),
(265, 'gangbanged', '', 0),
(266, 'gangbangs', '', 0),
(267, 'gassy ass', '', 0),
(268, 'gaylord', '', 0),
(269, 'gaysex', '', 0),
(270, 'goatse', '', 0),
(271, 'ham flap', '', 0),
(272, 'hardcoresex', '', 0),
(273, 'hell', '', 0),
(274, 'heshe', '', 0),
(275, 'hoar', '', 0),
(276, 'hoare', '', 0),
(277, 'hoer', '', 0),
(278, 'homo', '', 0),
(279, 'homoerotic', '', 0),
(280, 'hore', '', 0),
(281, 'horniest', '', 0),
(282, 'horny', '', 0),
(283, 'hotsex', '', 0),
(284, 'how to kill', '', 0),
(285, 'how to murdep', '', 0),
(286, 'jackoff', '', 0),
(287, 'jack-off', '', 0),
(288, 'jap', '', 0),
(289, 'jerk', '', 0),
(290, 'jerk-off', '', 0),
(291, 'jism', '', 0),
(292, 'jiz', '', 0),
(293, 'jizm', '', 0),
(294, 'jizz', '', 0),
(295, 'kawk', '', 0),
(296, 'kinky Jesus', '', 0),
(297, 'knob', '', 0),
(298, 'knob end', '', 0),
(299, 'knobead', '', 0),
(300, 'knobed', '', 0),
(301, 'knobend', '', 0),
(302, 'knobhead', '', 0),
(303, 'knobjocky', '', 0),
(304, 'knobjokey', '', 0),
(305, 'kock', '', 0),
(306, 'kondum', '', 0),
(307, 'kondums', '', 0),
(308, 'kum', '', 0),
(309, 'kummer', '', 0),
(310, 'kumming', '', 0),
(311, 'kums', '', 0),
(312, 'kunilingus', '', 0),
(313, 'kwif', '', 0),
(314, 'l3i+ch', '', 0),
(315, 'l3itch', '', 0),
(316, 'labia', '', 0),
(317, 'LEN', '', 0),
(318, 'lmao', '', 0),
(319, 'lmfao', '', 0),
(320, 'lust', '', 0),
(321, 'lusting', '', 0),
(322, 'm0f0', '', 0),
(323, 'm0fo', '', 0),
(324, 'm45terbate', '', 0),
(325, 'ma5terb8', '', 0),
(326, 'ma5terbate', '', 0),
(327, 'mafugly', '', 0),
(328, 'masochist', '', 0),
(329, 'masterb8', '', 0),
(330, 'masterbat*', '', 0),
(331, 'masterbat3', '', 0),
(332, 'masterbate', '', 0),
(333, 'master-bate', '', 0),
(334, 'masterbation', '', 0),
(335, 'masterbations', '', 0),
(336, 'masturbate', '', 0),
(337, 'mof0', '', 0),
(338, 'mofo', '', 0),
(339, 'mo-fo', '', 0),
(340, 'mothafuck', '', 0),
(341, 'mothafucka', '', 0),
(342, 'mothafuckas', '', 0),
(343, 'mothafuckaz', '', 0),
(344, 'mothafucked', '', 0),
(345, 'mothafucker', '', 0),
(346, 'mothafuckers', '', 0),
(347, 'mothafuckin', '', 0),
(348, 'mothafucking', '', 0),
(349, 'mothafuckings', '', 0),
(350, 'mothafucks', '', 0),
(351, 'mother fucker', '', 0),
(352, 'motherfuck', '', 0),
(353, 'motherfucked', '', 0),
(354, 'motherfucker', '', 0),
(355, 'motherfuckers', '', 0),
(356, 'motherfuckin', '', 0),
(357, 'motherfucking', '', 0),
(358, 'motherfuckings', '', 0),
(359, 'motherfuckka', '', 0),
(360, 'motherfucks', '', 0),
(361, 'muff', '', 0),
(362, 'muff puff', '', 0),
(363, 'mutha', '', 0),
(364, 'muthafecker', '', 0),
(365, 'muthafuckker', '', 0),
(366, 'muther', '', 0),
(367, 'mutherfucker', '', 0),
(368, 'n1gga', '', 0),
(369, 'n1gger', '', 0),
(370, 'nazi', '', 0),
(371, 'need the dick', '', 0),
(372, 'nigg3r', '', 0),
(373, 'nigg4h', '', 0),
(374, 'nigga', '', 0),
(375, 'niggah', '', 0),
(376, 'niggas', '', 0),
(377, 'niggaz', '', 0),
(378, 'nigger', '', 0),
(379, 'niggers', '', 0),
(380, 'nob', '', 0),
(381, 'nob jokey', '', 0),
(382, 'nobhead', '', 0),
(383, 'nobjocky', '', 0),
(384, 'nobjokey', '', 0),
(385, 'numbnuts', '', 0),
(386, 'nut butter', '', 0),
(387, 'nutsack', '', 0),
(388, 'orgasim', '', 0),
(389, 'orgasims', '', 0),
(390, 'orgasm', '', 0),
(391, 'orgasms', '', 0),
(392, 'p0rn', '', 0),
(393, 'pawn', '', 0),
(394, 'pecker', '', 0),
(395, 'penis', '', 0),
(396, 'penisfucker', '', 0),
(397, 'phonesex', '', 0),
(398, 'phuck', '', 0),
(399, 'phuk', '', 0),
(400, 'phuked', '', 0),
(401, 'phuking', '', 0),
(402, 'phukked', '', 0),
(403, 'phukking', '', 0),
(404, 'phuks', '', 0),
(405, 'phuq', '', 0),
(406, 'pigfucker', '', 0),
(407, 'pimpis', '', 0),
(408, 'piss', '', 0),
(409, 'pissed', '', 0),
(410, 'pisser', '', 0),
(411, 'pissers', '', 0),
(412, 'pisses', '', 0),
(413, 'pissflaps', '', 0),
(414, 'pissin', '', 0),
(415, 'pissing', '', 0),
(416, 'pissoff', '', 0),
(417, 'poop', '', 0),
(418, 'porn', '', 0),
(419, 'porno', '', 0),
(420, 'pornography', '', 0),
(421, 'pornos', '', 0),
(422, 'prick', '', 0),
(423, 'pricks', '', 0),
(424, 'pron', '', 0),
(425, 'pube', '', 0),
(426, 'pusse', '', 0),
(427, 'pussi', '', 0),
(428, 'pussies', '', 0),
(429, 'pussy', '', 0),
(430, 'pussy fart', '', 0),
(431, 'pussy palace', '', 0),
(432, 'pussys', '', 0),
(433, 'queer', '', 0),
(434, 'rectum', '', 0),
(435, 'retard', '', 0),
(436, 'rimjaw', '', 0),
(437, 'rimming', '', 0),
(438, 's hit', '', 0),
(439, 's.o.b.', '', 0),
(440, 's_h_i_t', '', 0),
(441, 'sadism', '', 0),
(442, 'sadist', '', 0),
(443, 'schlong', '', 0),
(444, 'screwing', '', 0),
(445, 'scroat', '', 0),
(446, 'scrote', '', 0),
(447, 'scrotum', '', 0),
(448, 'semen', '', 0),
(449, 'sex', '', 0),
(450, 'sh!+', '', 0),
(451, 'sh!t', '', 0),
(452, 'sh1t', '', 0),
(453, 'shag', '', 0),
(454, 'shagger', '', 0),
(455, 'shaggin', '', 0),
(456, 'shagging', '', 0),
(457, 'shemale', '', 0),
(458, 'shi+', '', 0),
(459, 'shit', '', 0),
(460, 'shit fucker', '', 0),
(461, 'shitdick', '', 0),
(462, 'shite', '', 0),
(463, 'shited', '', 0),
(464, 'shitey', '', 0),
(465, 'shitfuck', '', 0),
(466, 'shitfull', '', 0),
(467, 'shithead', '', 0),
(468, 'shiting', '', 0),
(469, 'shitings', '', 0),
(470, 'shits', '', 0),
(471, 'shitted', '', 0),
(472, 'shitter', '', 0),
(473, 'shitters', '', 0),
(474, 'shitting', '', 0),
(475, 'shittings', '', 0),
(476, 'shitty', '', 0),
(477, 'skank', '', 0),
(478, 'slut', '', 0),
(479, 'slut bucket', '', 0),
(480, 'sluts', '', 0),
(481, 'smegma', '', 0),
(482, 'smut', '', 0),
(483, 'snatch', '', 0),
(484, 'son-of-a-bitch', '', 0),
(485, 'spac', '', 0),
(486, 'spunk', '', 0),
(487, 't1tt1e5', '', 0),
(488, 't1tties', '', 0),
(489, 'teets', '', 0),
(490, 'teez', '', 0),
(491, 'testical', '', 0),
(492, 'testicle', '', 0),
(493, 'tit', '', 0),
(494, 'tit wank', '', 0),
(495, 'titfuck', '', 0),
(496, 'tits', '', 0),
(497, 'titt', '', 0),
(498, 'tittie5', '', 0),
(499, 'tittiefucker', '', 0),
(500, 'titties', '', 0),
(501, 'tittyfuck', '', 0),
(502, 'tittywank', '', 0),
(503, 'titwank', '', 0),
(504, 'tosser', '', 0),
(505, 'turd', '', 0),
(506, 'tw4t', '', 0),
(507, 'twat', '', 0),
(508, 'twathead', '', 0),
(509, 'twatty', '', 0),
(510, 'twunt', '', 0),
(511, 'twunter', '', 0),
(512, 'v14gra', '', 0),
(513, 'v1gra', '', 0),
(514, 'vagina', '', 0),
(515, 'viagra', '', 0),
(516, 'vulva', '', 0),
(517, 'w00se', '', 0),
(518, 'wang', '', 0),
(519, 'wank', '', 0),
(520, 'wanker', '', 0),
(521, 'wanky', '', 0),
(522, 'whoar', '', 0),
(523, 'whore', '', 0),
(524, 'willies', '', 0),
(525, 'willy', '', 0),
(526, 'wtf', '', 0),
(527, 'xrated', '', 0),
(528, 'xxx', '', 0),
(529, 'balls', '', 0),
(530, 'crap', '', 0),
(531, 'Goddamn', '', 0),
(532, 'God damn', '', 0),
(533, 'omg', '', 0),
(534, 'ahole', '', 0),
(535, 'ash0le', '', 0),
(536, 'ash0les', '', 0),
(537, 'asholes', '', 0),
(538, 'Ass Monkey', '', 0),
(539, 'Assface', '', 0),
(540, 'assh0le', '', 0),
(541, 'assh0lez', '', 0),
(542, 'assholz', '', 0),
(543, 'asswipe', '', 0),
(544, 'azzhole', '', 0),
(545, 'bassterds', '', 0),
(546, 'bastards', '', 0),
(547, 'bastardz', '', 0),
(548, 'basterds', '', 0),
(549, 'basterdz', '', 0),
(550, 'Biatch', '', 0),
(551, 'Blow Job', '', 0),
(552, 'boffing', '', 0),
(553, 'buttwipe', '', 0),
(554, 'c0cks', '', 0),
(555, 'c0k', '', 0),
(556, 'Carpet Muncher', '', 0),
(557, 'cawks', '', 0),
(558, 'Clit', '', 0),
(559, 'cnts', '', 0),
(560, 'cntz', '', 0),
(561, 'cock-head', '', 0),
(562, 'CockSucker', '', 0),
(563, 'cuntz', '', 0),
(564, 'dild0', '', 0),
(565, 'dild0s', '', 0),
(566, 'dilld0', '', 0),
(567, 'dilld0s', '', 0),
(568, 'dominatricks', '', 0),
(569, 'dominatrics', '', 0),
(570, 'dominatrix', '', 0),
(571, 'enema', '', 0),
(572, 'fag1t', '', 0),
(573, 'faget', '', 0),
(574, 'fagg1t', '', 0),
(575, 'faggit', '', 0),
(576, 'fagit', '', 0),
(577, 'fagz', '', 0),
(578, 'faig', '', 0),
(579, 'faigs', '', 0),
(580, 'fart', '', 0),
(581, 'flipping the bird', '', 0),
(582, 'Fudge Packer', '', 0),
(583, 'Fukah', '', 0),
(584, 'Fuken', '', 0),
(585, 'Fukin', '', 0),
(586, 'Fukk', '', 0),
(587, 'Fukkah', '', 0),
(588, 'Fukken', '', 0),
(589, 'Fukker', '', 0),
(590, 'Fukkin', '', 0),
(591, 'g00k', '', 0),
(592, 'gay', '', 0),
(593, 'gayboy', '', 0),
(594, 'gaygirl', '', 0),
(595, 'gays', '', 0),
(596, 'gayz', '', 0),
(597, 'God-damned', '', 0),
(598, 'h00r', '', 0),
(599, 'h0ar', '', 0),
(600, 'h0re', '', 0),
(601, 'hells', '', 0),
(602, 'hoor', '', 0),
(603, 'hoore', '', 0),
(604, 'japs', '', 0),
(605, 'jisim', '', 0),
(606, 'jiss', '', 0),
(607, 'knobs', '', 0),
(608, 'knobz', '', 0),
(609, 'kunt', '', 0),
(610, 'kunts', '', 0),
(611, 'kuntz', '', 0),
(612, 'Lesbian', '', 0),
(613, 'Lezzian', '', 0),
(614, 'Lipshits', '', 0),
(615, 'Lipshitz', '', 0),
(616, 'masokist', '', 0),
(617, 'massterbait', '', 0),
(618, 'masstrbait', '', 0),
(619, 'masstrbate', '', 0),
(620, 'masterbaiter', '', 0),
(621, 'masterbates', '', 0),
(622, 'Motha Fucker', '', 0),
(623, 'Motha Fuker', '', 0),
(624, 'Motha Fukkah', '', 0),
(625, 'Motha Fukker', '', 0),
(626, 'Mother Fucker', '', 0),
(627, 'Mother Fukah', '', 0),
(628, 'Mother Fuker', '', 0),
(629, 'Mother Fukkah', '', 0),
(630, 'Mother Fukker', '', 0),
(631, 'mother-fucker', '', 0),
(632, 'Mutha Fucker', '', 0),
(633, 'Mutha Fukah', '', 0),
(634, 'Mutha Fuker', '', 0),
(635, 'Mutha Fukkah', '', 0),
(636, 'Mutha Fukker', '', 0),
(637, 'n1gr', '', 0),
(638, 'nastt', '', 0),
(639, 'nigger;', '', 0),
(640, 'nigur;', '', 0),
(641, 'niiger;', '', 0),
(642, 'niigr;', '', 0),
(643, 'orafis', '', 0),
(644, 'orgasim;', '', 0),
(645, 'orgasum', '', 0),
(646, 'oriface', '', 0),
(647, 'orifice', '', 0),
(648, 'orifiss', '', 0),
(649, 'packi', '', 0),
(650, 'packie', '', 0),
(651, 'packy', '', 0),
(652, 'paki', '', 0),
(653, 'pakie', '', 0),
(654, 'paky', '', 0),
(655, 'peeenus', '', 0),
(656, 'peeenusss', '', 0),
(657, 'peenus', '', 0),
(658, 'peinus', '', 0),
(659, 'pen1s', '', 0),
(660, 'penas', '', 0),
(661, 'penis-breath', '', 0),
(662, 'penus', '', 0),
(663, 'penuus', '', 0),
(664, 'Phuc', '', 0),
(665, 'Phuck', '', 0),
(666, 'Phuk', '', 0),
(667, 'Phuker', '', 0),
(668, 'Phukker', '', 0),
(669, 'polac', '', 0),
(670, 'polack', '', 0),
(671, 'polak', '', 0),
(672, 'Poonani', '', 0),
(673, 'pr1c', '', 0),
(674, 'pr1ck', '', 0),
(675, 'pr1k', '', 0),
(676, 'pussee', '', 0),
(677, 'puuke', '', 0),
(678, 'puuker', '', 0),
(679, 'queers', '', 0),
(680, 'queerz', '', 0),
(681, 'qweers', '', 0),
(682, 'qweerz', '', 0),
(683, 'qweir', '', 0),
(684, 'recktum', '', 0),
(685, 'scank', '', 0),
(686, 'sexy', '', 0),
(687, 'Sh!t', '', 0),
(688, 'sh1ter', '', 0),
(689, 'sh1ts', '', 0),
(690, 'sh1tter', '', 0),
(691, 'sh1tz', '', 0),
(692, 'Shitty', '', 0),
(693, 'Shity', '', 0),
(694, 'shitz', '', 0),
(695, 'Shyt', '', 0),
(696, 'Shyte', '', 0),
(697, 'Shytty', '', 0),
(698, 'Shyty', '', 0),
(699, 'skanck', '', 0),
(700, 'skankee', '', 0),
(701, 'skankey', '', 0),
(702, 'skanks', '', 0),
(703, 'Skanky', '', 0),
(704, 'Slutty', '', 0),
(705, 'slutz', '', 0),
(706, 'va1jina', '', 0),
(707, 'vag1na', '', 0),
(708, 'vagiina', '', 0),
(709, 'vaj1na', '', 0),
(710, 'vajina', '', 0),
(711, 'vullva', '', 0),
(712, 'w0p', '', 0),
(713, 'wh00r', '', 0),
(714, 'wh0re', '', 0),
(715, 'b!+ch', '', 0),
(716, 'arschloch', '', 0),
(717, 'lesbian', '', 0),
(718, '*damn', '', 0),
(719, '*dyke', '', 0),
(720, '*fuck*', '', 0),
(721, '*shit*', '', 0),
(722, '@$$', '', 0),
(723, 'amcik', '', 0),
(724, 'andskota', '', 0),
(725, 'arse*', '', 0),
(726, 'assrammer', '', 0),
(727, 'ayir', '', 0),
(728, 'bi7ch', '', 0),
(729, 'bitch*', '', 0),
(730, 'bollock*', '', 0),
(731, 'butt-pirate', '', 0),
(732, 'cabron', '', 0),
(733, 'cazzo', '', 0),
(734, 'chraa', '', 0),
(735, 'chuj', '', 0),
(736, 'Cock*', '', 0),
(737, 'cunt*', '', 0),
(738, 'd4mn', '', 0),
(739, 'daygo', '', 0),
(740, 'dego', '', 0),
(741, 'dick*', '', 0),
(742, 'dike*', '', 0),
(743, 'dupa', '', 0),
(744, 'dziwka', '', 0),
(745, 'ejackulate', '', 0),
(746, 'Ekrem*', '', 0),
(747, 'Ekto', '', 0),
(748, 'enculer', '', 0),
(749, 'faen', '', 0),
(750, 'fag*', '', 0),
(751, 'fanculo', '', 0),
(752, 'feces', '', 0),
(753, 'feg', '', 0),
(754, 'Felcher', '', 0),
(755, 'ficken', '', 0),
(756, 'fitt*', '', 0),
(757, 'Flikker', '', 0),
(758, 'foreskin', '', 0),
(759, 'Fotze', '', 0),
(760, 'Fu(*', '', 0),
(761, 'fuk*', '', 0),
(762, 'futkretzn', '', 0),
(763, 'gook', '', 0),
(764, 'guiena', '', 0),
(765, 'h0r', '', 0),
(766, 'h4x0r', '', 0),
(767, 'helvete', '', 0),
(768, 'hoer*', '', 0),
(769, 'honkey', '', 0),
(770, 'Huevon', '', 0),
(771, 'hui', '', 0),
(772, 'injun', '', 0),
(773, 'kanker*', '', 0),
(774, 'kike', '', 0),
(775, 'klootzak', '', 0),
(776, 'kraut', '', 0),
(777, 'knulle', '', 0),
(778, 'kuk', '', 0),
(779, 'kuksuger', '', 0),
(780, 'Kurac', '', 0),
(781, 'kurwa', '', 0),
(782, 'kusi*', '', 0),
(783, 'kyrpa*', '', 0),
(784, 'lesbo', '', 0),
(785, 'mamhoon', '', 0),
(786, 'masturbat*', '', 0),
(787, 'merd*', '', 0),
(788, 'mibun', '', 0),
(789, 'monkleigh', '', 0),
(790, 'mouliewop', '', 0),
(791, 'muie', '', 0),
(792, 'mulkku', '', 0),
(793, 'muschi', '', 0),
(794, 'nazis', '', 0),
(795, 'nepesaurio', '', 0),
(796, 'nigger*', '', 0),
(797, 'orospu', '', 0),
(798, 'paska*', '', 0),
(799, 'perse', '', 0),
(800, 'picka', '', 0),
(801, 'pierdol*', '', 0),
(802, 'pillu*', '', 0),
(803, 'pimmel', '', 0),
(804, 'piss*', '', 0),
(805, 'pizda', '', 0),
(806, 'poontsee', '', 0),
(807, 'pr0n', '', 0),
(808, 'preteen', '', 0),
(809, 'pula', '', 0),
(810, 'pule', '', 0),
(811, 'puta', '', 0),
(812, 'puto', '', 0),
(813, 'qahbeh', '', 0),
(814, 'queef*', '', 0),
(815, 'rautenberg', '', 0),
(816, 'schaffer', '', 0),
(817, 'scheiss*', '', 0),
(818, 'schlampe', '', 0),
(819, 'schmuck', '', 0),
(820, 'screw', '', 0),
(821, 'sh!t*', '', 0),
(822, 'sharmuta', '', 0),
(823, 'sharmute', '', 0),
(824, 'shipal', '', 0),
(825, 'shiz', '', 0),
(826, 'skribz', '', 0),
(827, 'skurwysyn', '', 0),
(828, 'sphencter', '', 0),
(829, 'spic', '', 0),
(830, 'spierdalaj', '', 0),
(831, 'splooge', '', 0),
(832, 'suka', '', 0),
(833, 'b00b*', '', 0),
(834, 'testicle*', '', 0),
(835, 'titt*', '', 0),
(836, 'vittu', '', 0),
(837, 'wank*', '', 0),
(838, 'wetback*', '', 0),
(839, 'wichser', '', 0),
(840, 'wop*', '', 0),
(841, 'yed', '', 0),
(842, 'zabourah', '', 0),
(843, 'handjob', '', 0),
(844, 'rape', '', 0),
(845, 'analplug', '', 0),
(846, 'analsex', '', 0),
(847, 'assassin', '', 0),
(848, 'bimbo', '', 0),
(849, 'bloodyhell', '', 0),
(850, 'bollocks', '', 0),
(851, 'boobies', '', 0),
(852, 'bukkake', '', 0),
(853, 'bullshit', '', 0),
(854, 'condom', '', 0),
(855, 'damm', '', 0),
(856, 'dammit', '', 0),
(857, 'doggystyle', '', 0),
(858, 'f0ck', '', 0),
(859, 'fck', '', 0),
(860, 'fcker', '', 0),
(861, 'fckr', '', 0),
(862, 'fcku', '', 0),
(863, 'fuckface', '', 0),
(864, 'fuckr', '', 0),
(865, 'fuct', '', 0),
(866, 'genital', '', 0),
(867, 'genitalia', '', 0),
(868, 'genitals', '', 0),
(869, 'glory hole', '', 0),
(870, 'gloryhole', '', 0),
(871, 'gobshite', '', 0),
(872, 'godammet', '', 0),
(873, 'godammit', '', 0),
(874, 'goddammet', '', 0),
(875, 'goddammit', '', 0),
(876, 'goddamn', '', 0),
(877, 'gypo', '', 0),
(878, 'hitler', '', 0),
(879, 'hooker', '', 0),
(880, 'jesussucks', '', 0),
(881, 'jizzum', '', 0),
(882, 'kaffir', '', 0),
(883, 'kill', '', 0),
(884, 'killer', '', 0),
(885, 'killin', '', 0),
(886, 'killing', '', 0),
(887, 'milf', '', 0),
(888, 'molest', '', 0),
(889, 'moron', '', 0),
(890, 'mthrfckr', '', 0),
(891, 'murder', '', 0),
(892, 'murderer', '', 0),
(893, 'negro', '', 0),
(894, 'nonce', '', 0),
(895, 'paedo', '', 0),
(896, 'paedophile', '', 0),
(897, 'pedo', '', 0),
(898, 'pedofile', '', 0),
(899, 'pedophile', '', 0),
(900, 'pig', '', 0),
(901, 'pimp', '', 0),
(902, 'poof', '', 0),
(903, 'prostitute', '', 0),
(904, 'raped', '', 0),
(905, 'rapes', '', 0),
(906, 'rapist', '', 0),
(907, 'slag', '', 0),
(908, 'spastic', '', 0),
(909, 'spaz', '', 0),
(910, 'sperm', '', 0),
(911, 'stripper', '', 0),
(912, 'tart', '', 0),
(913, 'terrorist', '', 0),
(914, 'vaginal', '', 0),
(915, 'vibrator', '', 0),
(916, 'weed', '', 0),
(917, 'wetback', '', 0),
(918, 'whor', '', 0),
(919, 'wog', '', 0),
(920, 'abortion', '', 0),
(921, 'bewb', '', 0),
(922, 'blow', '', 0),
(923, 'choad', '', 0),
(924, 'cooter', '', 0),
(925, 'cornhole', '', 0),
(926, 'dong', '', 0),
(927, 'douche', '', 0),
(928, 'humping', '', 0),
(929, 'poon', '', 0),
(930, 'punani', '', 0),
(931, 'queef', '', 0),
(932, 'quim', '', 0),
(933, 'rectal', '', 0),
(934, 'rimjob', '', 0),
(935, 'spick', '', 0),
(936, 'spoo', '', 0),
(937, 'spooge', '', 0),
(938, 'taint', '', 0),
(939, 'titty', '', 0),
(940, 'vag', '', 0),
(941, 'bollera', '', 0),
(942, 'cabrón', '', 0),
(943, 'cabrona', '', 0),
(944, 'cabronazo', '', 0),
(945, 'capulla', '', 0),
(946, 'capullo', '', 0),
(947, 'chichi', '', 0),
(948, 'chocho', '', 0),
(949, 'cojon', '', 0),
(950, 'cojón', '', 0),
(951, 'cojones', '', 0),
(952, 'comepollas', '', 0),
(953, 'cono', '', 0),
(954, 'coño', '', 0),
(955, 'culo', '', 0),
(956, 'follar', '', 0),
(957, 'follen', '', 0),
(958, 'furcia', '', 0),
(959, 'gilipollas', '', 0),
(960, 'hijaputa', '', 0),
(961, 'hijoputa', '', 0),
(962, 'hostia', '', 0),
(963, 'joder', '', 0),
(964, 'jodete', '', 0),
(965, 'jódete', '', 0),
(966, 'joputa', '', 0),
(967, 'mamada', '', 0),
(968, 'mamon', '', 0),
(969, 'mamón', '', 0),
(970, 'mamona', '', 0),
(971, 'marica', '', 0),
(972, 'maricon', '', 0),
(973, 'maricón', '', 0),
(974, 'maricona', '', 0),
(975, 'mariconazo', '', 0),
(976, 'ojete', '', 0),
(977, 'ostia', '', 0),
(978, 'pajillero', '', 0),
(979, 'pendon', '', 0),
(980, 'pendón', '', 0),
(981, 'picha', '', 0),
(982, 'polla', '', 0),
(983, 'pollon', '', 0),
(984, 'pollón', '', 0),
(985, 'polvo', '', 0),
(986, 'potorro', '', 0),
(987, 'puton', '', 0),
(988, 'putón', '', 0),
(989, 'tortillera', '', 0),
(990, 'zorron', '', 0),
(991, 'zorrón', '', 0),
(992, 'jumalauta', '', 0),
(993, 'helvetit', '', 0),
(994, 'helvetiltä', '', 0),
(995, 'helvetillä', '', 0),
(996, 'helvetille', '', 0),
(997, 'helvetistä', '', 0),
(998, 'helvetin', '', 0),
(999, 'helvettiin', '', 0),
(1000, 'helvetissä', '', 0),
(1001, 'helvetti', '', 0),
(1002, 'helvettiä', '', 0),
(1003, 'helveteiltä', '', 0),
(1004, 'helveteillä', '', 0),
(1005, 'helveteille', '', 0),
(1006, 'helveteistä', '', 0),
(1007, 'helvettien', '', 0),
(1008, 'helvetteihin', '', 0),
(1009, 'helveteissä', '', 0),
(1010, 'helvettejä', '', 0),
(1011, 'hinttarit', '', 0),
(1012, 'hinttarilta', '', 0),
(1013, 'hinttarilla', '', 0),
(1014, 'hinttarille', '', 0),
(1015, 'hinttarista', '', 0),
(1016, 'hinttarin', '', 0),
(1017, 'hinttariin', '', 0),
(1018, 'hinttarissa', '', 0),
(1019, 'hinttari', '', 0),
(1020, 'hinttaria', '', 0),
(1021, 'hinttareilta', '', 0),
(1022, 'hinttareilla', '', 0),
(1023, 'hinttareille', '', 0),
(1024, 'hinttareista', '', 0),
(1025, 'hinttarien', '', 0),
(1026, 'hinttareiden', '', 0),
(1027, 'hinttareitten', '', 0),
(1028, 'hinttareihin', '', 0),
(1029, 'hinttareissa', '', 0),
(1030, 'hinttareita', '', 0),
(1031, 'hinttareja', '', 0),
(1032, 'hintit', '', 0),
(1033, 'hintiltä', '', 0),
(1034, 'hintillä', '', 0),
(1035, 'hintille', '', 0),
(1036, 'hintistä', '', 0),
(1037, 'hintin', '', 0),
(1038, 'hinttiin', '', 0),
(1039, 'hintissä', '', 0),
(1040, 'hintti', '', 0),
(1041, 'hinttiä', '', 0),
(1042, 'hinteiltä', '', 0),
(1043, 'hinteillä', '', 0),
(1044, 'hinteille', '', 0),
(1045, 'hinteistä', '', 0),
(1046, 'hinttien', '', 0),
(1047, 'hintteihin', '', 0),
(1048, 'hinteissä', '', 0),
(1049, 'hinttejä', '', 0),
(1050, 'huorat', '', 0),
(1051, 'huoralta', '', 0),
(1052, 'huoralla', '', 0),
(1053, 'huoralle', '', 0),
(1054, 'huorasta', '', 0),
(1055, 'huoran', '', 0),
(1056, 'huoraan', '', 0),
(1057, 'huorassa', '', 0),
(1058, 'huora', '', 0),
(1059, 'huoraa', '', 0),
(1060, 'huorilta', '', 0),
(1061, 'huorilla', '', 0),
(1062, 'huorille', '', 0),
(1063, 'huorista', '', 0),
(1064, 'huorien', '', 0),
(1065, 'huoriin', '', 0),
(1066, 'huorissa', '', 0),
(1067, 'huoria', '', 0),
(1068, 'kusipäät', '', 0),
(1069, 'kusipäältä', '', 0),
(1070, 'kusipäällä', '', 0),
(1071, 'kusipäälle', '', 0),
(1072, 'kusipäästä', '', 0),
(1073, 'kusipään', '', 0),
(1074, 'kusipäähän', '', 0),
(1075, 'kusipäässä', '', 0),
(1076, 'kusipää', '', 0),
(1077, 'kusipäätä', '', 0),
(1078, 'kusipäiltä', '', 0),
(1079, 'kusipäillä', '', 0),
(1080, 'kusipäille', '', 0),
(1081, 'kusipäistä', '', 0),
(1082, 'kusipäitten', '', 0),
(1083, 'kusipäihin', '', 0),
(1084, 'kusipäissä', '', 0),
(1085, 'kusipäitä', '', 0),
(1086, 'kyrvät', '', 0),
(1087, 'kyrvältä', '', 0),
(1088, 'kyrvällä', '', 0),
(1089, 'kyrvälle', '', 0),
(1090, 'kyrvästä', '', 0),
(1091, 'kyrvän', '', 0),
(1092, 'kyrpään', '', 0),
(1093, 'kyrvässä', '', 0),
(1094, 'kyrpä', '', 0),
(1095, 'kyrpää', '', 0),
(1096, 'kyrviltä', '', 0),
(1097, 'kyrvillä', '', 0),
(1098, 'kyrville', '', 0),
(1099, 'kyrvistä', '', 0),
(1100, 'kyrpien', '', 0),
(1101, 'kyrpiin', '', 0),
(1102, 'kyrvissä', '', 0),
(1103, 'kyrpiä', '', 0),
(1104, 'mulkut', '', 0),
(1105, 'mulkulta', '', 0),
(1106, 'mulkulla', '', 0),
(1107, 'mulkulle', '', 0),
(1108, 'mulkusta', '', 0),
(1109, 'mulkun', '', 0),
(1110, 'mulkkuun', '', 0),
(1111, 'mulkussa', '', 0),
(1112, 'mulkkua', '', 0),
(1113, 'mulkuilta', '', 0),
(1114, 'mulkuilla', '', 0),
(1115, 'mulkuille', '', 0),
(1116, 'mulkuista', '', 0),
(1117, 'mulkkujen', '', 0),
(1118, 'mulkkuihin', '', 0),
(1119, 'mulkuissa', '', 0),
(1120, 'mulkkuja', '', 0),
(1121, 'nartut', '', 0),
(1122, 'nartulta', '', 0),
(1123, 'nartulla', '', 0),
(1124, 'nartulle', '', 0),
(1125, 'nartusta', '', 0),
(1126, 'nartun', '', 0),
(1127, 'narttuun', '', 0),
(1128, 'nartussa', '', 0),
(1129, 'narttu', '', 0),
(1130, 'narttua', '', 0),
(1131, 'nartuilta', '', 0),
(1132, 'nartuilla', '', 0),
(1133, 'nartuille', '', 0),
(1134, 'nartuista', '', 0),
(1135, 'narttujen', '', 0),
(1136, 'narttuihin', '', 0),
(1137, 'nartuissa', '', 0),
(1138, 'narttuja', '', 0),
(1139, 'neekerit', '', 0),
(1140, 'neekeriltä', '', 0),
(1141, 'neekerillä', '', 0),
(1142, 'neekerille', '', 0),
(1143, 'neekeristä', '', 0),
(1144, 'neekerin', '', 0),
(1145, 'neekeriin', '', 0),
(1146, 'neekerissä', '', 0),
(1147, 'neekeri', '', 0),
(1148, 'neekeriä', '', 0),
(1149, 'neekereiltä', '', 0),
(1150, 'neekereillä', '', 0),
(1151, 'neekereille', '', 0),
(1152, 'neekereistä', '', 0),
(1153, 'neekerien', '', 0),
(1154, 'neekereitten', '', 0),
(1155, 'neekereiden', '', 0),
(1156, 'neekereihin', '', 0),
(1157, 'neekereissä', '', 0),
(1158, 'neekereitä', '', 0),
(1159, 'neekerejä', '', 0),
(1160, 'paskat', '', 0),
(1161, 'paskalta', '', 0),
(1162, 'paskalla', '', 0),
(1163, 'paskalle', '', 0),
(1164, 'paskasta', '', 0),
(1165, 'paskan', '', 0),
(1166, 'paskaan', '', 0),
(1167, 'paskassa', '', 0),
(1168, 'paska', '', 0),
(1169, 'paskaa', '', 0),
(1170, 'paskoilta', '', 0),
(1171, 'paskoilla', '', 0),
(1172, 'paskoille', '', 0),
(1173, 'paskoista', '', 0),
(1174, 'paskojen', '', 0),
(1175, 'paskoihin', '', 0),
(1176, 'paskoissa', '', 0),
(1177, 'paskoja', '', 0),
(1178, 'perhanat', '', 0),
(1179, 'perhanalta', '', 0),
(1180, 'perhanalla', '', 0),
(1181, 'perhanalle', '', 0),
(1182, 'perhanasta', '', 0),
(1183, 'perhanan', '', 0),
(1184, 'perhanaan', '', 0),
(1185, 'perhanassa', '', 0),
(1186, 'perhana', '', 0),
(1187, 'perhanaa', '', 0),
(1188, 'perhanoilta', '', 0),
(1189, 'perhanoilla', '', 0),
(1190, 'perhanoille', '', 0),
(1191, 'perhanoista', '', 0),
(1192, 'perhanoiden', '', 0),
(1193, 'perhanoitten', '', 0),
(1194, 'perhanoihin', '', 0),
(1195, 'perhanoissa', '', 0),
(1196, 'perhanoita', '', 0),
(1197, 'perkeleet', '', 0),
(1198, 'perkeleeltä', '', 0),
(1199, 'perkeleellä', '', 0),
(1200, 'perkeleelle', '', 0),
(1201, 'perkeleestä', '', 0),
(1202, 'perkeleen', '', 0),
(1203, 'perkeleeseen', '', 0),
(1204, 'perkeleessä', '', 0),
(1205, 'perkele', '', 0),
(1206, 'perkelettä', '', 0),
(1207, 'perkeleiltä', '', 0),
(1208, 'perkeleillä', '', 0),
(1209, 'perkeleille', '', 0),
(1210, 'perkeleistä', '', 0),
(1211, 'perkeleitten', '', 0),
(1212, 'perkeleiden', '', 0),
(1213, 'perkeleihin', '', 0),
(1214, 'perkeleisiin', '', 0),
(1215, 'perkeleissä', '', 0),
(1216, 'perkeleitä', '', 0),
(1217, 'perseet', '', 0),
(1218, 'perseeltä', '', 0),
(1219, 'perseellä', '', 0),
(1220, 'perseelle', '', 0),
(1221, 'perseestä', '', 0),
(1222, 'perseen', '', 0),
(1223, 'perseeseen', '', 0),
(1224, 'perseessä', '', 0),
(1225, 'persettä', '', 0),
(1226, 'perseiltä', '', 0),
(1227, 'perseillä', '', 0),
(1228, 'perseille', '', 0),
(1229, 'perseistä', '', 0),
(1230, 'perseitten', '', 0),
(1231, 'perseiden', '', 0),
(1232, 'perseihin', '', 0),
(1233, 'perseisiin', '', 0),
(1234, 'perseissä', '', 0),
(1235, 'perseitä', '', 0),
(1236, 'pillut', '', 0),
(1237, 'pillulta', '', 0),
(1238, 'pillulla', '', 0),
(1239, 'pillulle', '', 0),
(1240, 'pillusta', '', 0),
(1241, 'pillun', '', 0),
(1242, 'pilluun', '', 0),
(1243, 'pillussa', '', 0),
(1244, 'pillu', '', 0),
(1245, 'pillua', '', 0),
(1246, 'pilluilta', '', 0),
(1247, 'pilluilla', '', 0),
(1248, 'pilluille', '', 0),
(1249, 'pilluista', '', 0),
(1250, 'pillujen', '', 0),
(1251, 'pilluihin', '', 0),
(1252, 'pilluissa', '', 0),
(1253, 'pilluja', '', 0),
(1254, 'saamarit', '', 0),
(1255, 'saamarilta', '', 0),
(1256, 'saamarilla', '', 0),
(1257, 'saamarille', '', 0),
(1258, 'saamarista', '', 0),
(1259, 'saamarin', '', 0),
(1260, 'saamariin', '', 0),
(1261, 'saamarissa', '', 0),
(1262, 'saamari', '', 0),
(1263, 'saamaria', '', 0),
(1264, 'saamareilta', '', 0),
(1265, 'saamareilla', '', 0),
(1266, 'saamareille', '', 0),
(1267, 'saamareista', '', 0),
(1268, 'saamarien', '', 0),
(1269, 'saamareiden', '', 0),
(1270, 'saamareitten', '', 0),
(1271, 'saamareihin', '', 0),
(1272, 'saamareissa', '', 0),
(1273, 'saamareita', '', 0),
(1274, 'saamareja', '', 0),
(1275, 'saatanat', '', 0),
(1276, 'saatanalta', '', 0),
(1277, 'saatanalla', '', 0),
(1278, 'saatanalle', '', 0),
(1279, 'saatanasta', '', 0),
(1280, 'saatanan', '', 0),
(1281, 'saatanaan', '', 0),
(1282, 'saatanassa', '', 0),
(1283, 'saatana', '', 0),
(1284, 'saatanaa', '', 0),
(1285, 'saatanoilta', '', 0),
(1286, 'saatanoilla', '', 0),
(1287, 'saatanoille', '', 0),
(1288, 'saatanoista', '', 0),
(1289, 'saatanoiden', '', 0),
(1290, 'saatanoitten', '', 0),
(1291, 'saatanoihin', '', 0),
(1292, 'saatanoissa', '', 0),
(1293, 'saatanoita', '', 0),
(1294, 'vitut', '', 0),
(1295, 'vitulta', '', 0),
(1296, 'vitulla', '', 0),
(1297, 'vitulle', '', 0),
(1298, 'vitusta', '', 0),
(1299, 'vitun', '', 0),
(1300, 'vittuun', '', 0),
(1301, 'vitussa', '', 0),
(1302, 'vittua', '', 0),
(1303, 'vituilta', '', 0),
(1304, 'vituilla', '', 0),
(1305, 'vituille', '', 0),
(1306, 'vituista', '', 0),
(1307, 'vittujen', '', 0),
(1308, 'vittuihin', '', 0),
(1309, 'vituissa', '', 0),
(1310, 'vittuja', '', 0),
(1311, 'ämmät', '', 0),
(1312, 'ämmältä', '', 0),
(1313, 'ämmällä', '', 0),
(1314, 'ämmälle', '', 0),
(1315, 'ämmästä', '', 0),
(1316, 'ämmän', '', 0),
(1317, 'ämmään', '', 0),
(1318, 'ämmässä', '', 0),
(1319, 'ämmä', '', 0),
(1320, 'ämmää', '', 0),
(1321, 'ämmiltä', '', 0),
(1322, 'ämmillä', '', 0),
(1323, 'ämmille', '', 0),
(1324, 'ämmistä', '', 0),
(1325, 'ämmien', '', 0),
(1326, 'ämmiin', '', 0),
(1327, 'ämmissä', '', 0),
(1328, 'ämmiä', '', 0),
(1329, 'fittu', '', 0),
(1330, 'fitut', '', 0),
(1331, 'fitulta', '', 0),
(1332, 'fitulla', '', 0),
(1333, 'fitulle', '', 0),
(1334, 'fitusta', '', 0),
(1335, 'fitun', '', 0),
(1336, 'fittuun', '', 0),
(1337, 'fitussa', '', 0),
(1338, 'fittua', '', 0),
(1339, 'fituilta', '', 0),
(1340, 'fituilla', '', 0),
(1341, 'fituille', '', 0),
(1342, 'fituista', '', 0),
(1343, 'fittujen', '', 0),
(1344, 'fittuihin', '', 0),
(1345, 'fituissa', '', 0),
(1346, 'fittuja', '', 0),
(1347, 'fiddu', '', 0),
(1348, 'fiddut', '', 0),
(1349, 'fiddulta', '', 0),
(1350, 'fiddulla', '', 0),
(1351, 'fiddulle', '', 0),
(1352, 'fiddusta', '', 0),
(1353, 'fiddun', '', 0),
(1354, 'fidduun', '', 0),
(1355, 'fiddussa', '', 0),
(1356, 'fiddua', '', 0),
(1357, 'fidduilta', '', 0),
(1358, 'fidduilla', '', 0),
(1359, 'fidduille', '', 0),
(1360, 'fidduista', '', 0),
(1361, 'fiddujen', '', 0),
(1362, 'fidduihin', '', 0),
(1363, 'fidduissa', '', 0),
(1364, 'fidduja', '', 0),
(1365, 'horo', '', 0),
(1366, 'horot', '', 0),
(1367, 'horolta', '', 0),
(1368, 'horolla', '', 0),
(1369, 'horolle', '', 0),
(1370, 'horosta', '', 0),
(1371, 'horon', '', 0),
(1372, 'horoon', '', 0),
(1373, 'horossa', '', 0),
(1374, 'horoa', '', 0),
(1375, 'horoilta', '', 0),
(1376, 'horoilla', '', 0),
(1377, 'horoille', '', 0),
(1378, 'horoista', '', 0),
(1379, 'horojen', '', 0),
(1380, 'horoihin', '', 0),
(1381, 'horoissa', '', 0),
(1382, 'horoja', '', 0),
(1383, 'abruti', '', 0),
(1384, 'abrutie', '', 0),
(1385, 'baise', '', 0),
(1386, 'baisé', '', 0),
(1387, 'baiser', '', 0),
(1388, 'batard', '', 0),
(1389, 'bite', '', 0),
(1390, 'bougnoul', '', 0),
(1391, 'branleur', '', 0),
(1392, 'burne', '', 0),
(1393, 'chier', '', 0),
(1394, 'cocu', '', 0),
(1395, 'con', '', 0),
(1396, 'connard', '', 0),
(1397, 'connasse', '', 0),
(1398, 'conne', '', 0),
(1399, 'couille', '', 0),
(1400, 'couillon', '', 0),
(1401, 'couillonne', '', 0),
(1402, 'crevard', '', 0),
(1403, 'cul', '', 0),
(1404, 'encule', '', 0),
(1405, 'enculé', '', 0),
(1406, 'enculee', '', 0),
(1407, 'enculée', '', 0),
(1408, 'enfoire', '', 0),
(1409, 'enfoiré', '', 0),
(1410, 'fion', '', 0),
(1411, 'foutre', '', 0),
(1412, 'merde', '', 0),
(1413, 'negre', '', 0),
(1414, 'nègre', '', 0),
(1415, 'negresse', '', 0),
(1416, 'négresse', '', 0),
(1417, 'nique', '', 0),
(1418, 'niquer', '', 0),
(1419, 'partouze', '', 0),
(1420, 'pd', '', 0),
(1421, 'pede', '', 0),
(1422, 'pédé', '', 0),
(1423, 'petasse', '', 0),
(1424, 'pétasse', '', 0),
(1425, 'pine', '', 0),
(1426, 'pouffe', '', 0),
(1427, 'pouffiasse', '', 0),
(1428, 'putain', '', 0),
(1429, 'pute', '', 0),
(1430, 'salaud', '', 0),
(1431, 'salop', '', 0),
(1432, 'salopard', '', 0),
(1433, 'salope', '', 0),
(1434, 'sodomie', '', 0),
(1435, 'sucer', '', 0),
(1436, 'tapette', '', 0),
(1437, 'tare', '', 0),
(1438, 'taré', '', 0),
(1439, 'vagin', '', 0),
(1440, 'zob', '', 0),
(1441, 'allupato', '', 0),
(1442, 'ammucchiata', '', 0),
(1443, 'anale', '', 0),
(1444, 'arrapato', '', 0),
(1445, 'arrusa', '', 0),
(1446, 'arruso', '', 0),
(1447, 'assatanato', '', 0),
(1448, 'bagascia', '', 0),
(1449, 'bagassa', '', 0),
(1450, 'bagnarsi', '', 0),
(1451, 'baldracca', '', 0),
(1452, 'balle', '', 0),
(1453, 'battere', '', 0),
(1454, 'battona', '', 0),
(1455, 'belino', '', 0),
(1456, 'biga', '', 0),
(1457, 'bocchinara', '', 0),
(1458, 'bocchino', '', 0),
(1459, 'bofilo', '', 0),
(1460, 'boiata', '', 0),
(1461, 'bordello', '', 0),
(1462, 'brinca', '', 0),
(1463, 'bucaiolo', '', 0),
(1464, 'budiùlo', '', 0),
(1465, 'buona donna', '', 0),
(1466, 'busone', '', 0),
(1467, 'cacca', '', 0),
(1468, 'caccati in mano e prenditi a schiaffi', '', 0),
(1469, 'caciocappella', '', 0),
(1470, 'cadavere', '', 0),
(1471, 'cagare', '', 0),
(1472, 'cagata', '', 0),
(1473, 'cagna', '', 0),
(1474, 'cammello', '', 0),
(1475, 'cappella', '', 0),
(1476, 'carciofo', '', 0),
(1477, 'carità', '', 0),
(1478, 'casci', '', 0),
(1479, 'cazzata', '', 0),
(1480, 'cazzimma', '', 0),
(1481, 'checca', '', 0),
(1482, 'chiappa', '', 0),
(1483, 'chiavare', '', 0),
(1484, 'chiavata', '', 0),
(1485, 'ciospo', '', 0),
(1486, 'ciucciami il cazzo', '', 0),
(1487, 'coglione', '', 0),
(1488, 'coglioni', '', 0),
(1489, 'cornuto', '', 0),
(1490, 'cozza', '', 0),
(1491, 'culattina', '', 0),
(1492, 'culattone', '', 0),
(1493, 'di merda', '', 0),
(1494, 'ditalino', '', 0),
(1495, 'duro', '', 0),
(1496, 'fare unaŠ', '', 0),
(1497, 'fava', '', 0),
(1498, 'femminuccia', '', 0),
(1499, 'fica', '', 0),
(1500, 'figa', '', 0),
(1501, 'figlio di buona donna', '', 0),
(1502, 'figlio di puttana', '', 0),
(1503, 'figone', '', 0),
(1504, 'finocchio', '', 0),
(1505, 'fottere', '', 0),
(1506, 'fottersi', '', 0),
(1507, 'fracicone', '', 0),
(1508, 'fregna', '', 0),
(1509, 'frocio', '', 0),
(1510, 'froscio', '', 0),
(1511, 'fuori come un balcone', '', 0),
(1512, 'goldone', '', 0),
(1513, 'grilletto', '', 0),
(1514, 'guanto', '', 0),
(1515, 'guardone', '', 0),
(1516, 'incazzarsi', '', 0),
(1517, 'incoglionirsi', '', 0),
(1518, 'ingoio', '', 0),
(1519, 'larte bolognese', '', 0),
(1520, 'leccaculo', '', 0),
(1521, 'lecchino', '', 0),
(1522, 'lofare', '', 0),
(1523, 'loffa', '', 0),
(1524, 'loffare', '', 0),
(1525, 'lumaca', '', 0),
(1526, 'manico', '', 0),
(1527, 'mannaggia', '', 0),
(1528, 'merda', '', 0),
(1529, 'merdata', '', 0),
(1530, 'merdoso', '', 0),
(1531, 'mignotta', '', 0),
(1532, 'minchia', '', 0),
(1533, 'minchione', '', 0),
(1534, 'mona', '', 0),
(1535, 'monta', '', 0),
(1536, 'montare', '', 0),
(1537, 'mussa', '', 0),
(1538, 'nave scuola', '', 0),
(1539, 'nerchia', '', 0),
(1540, 'nudo', '', 0),
(1541, 'padulo', '', 0),
(1542, 'palle', '', 0),
(1543, 'palloso', '', 0),
(1544, 'patacca', '', 0),
(1545, 'patonza', '', 0),
(1546, 'pecorina', '', 0),
(1547, 'pesce', '', 0),
(1548, 'picio', '', 0),
(1549, 'pincare', '', 0),
(1550, 'pipa', '', 0),
(1551, 'pipì', '', 0),
(1552, 'pippone', '', 0),
(1553, 'pirla', '', 0),
(1554, 'pisciare', '', 0),
(1555, 'piscio', '', 0),
(1556, 'pisello', '', 0),
(1557, 'pistola', '', 0),
(1558, 'pistolotto', '', 0),
(1559, 'pomiciare', '', 0),
(1560, 'pompa', '', 0),
(1561, 'pompino', '', 0),
(1562, 'porca', '', 0),
(1563, 'porca madonna', '', 0),
(1564, 'porca miseria', '', 0),
(1565, 'porca puttana', '', 0),
(1566, 'porco due', '', 0),
(1567, 'porco zio', '', 0),
(1568, 'potta', '', 0),
(1569, 'puppami', '', 0),
(1570, 'puttana', '', 0),
(1571, 'quaglia', '', 0),
(1572, 'recchione', '', 0),
(1573, 'regina', '', 0),
(1574, 'rincoglionire', '', 0),
(1575, 'rizzarsi', '', 0),
(1576, 'rompiballe', '', 0),
(1577, 'ruffiano', '', 0),
(1578, 'sbattere', '', 0),
(1579, 'sbattersi', '', 0),
(1580, 'sborra', '', 0),
(1581, 'sborrata', '', 0),
(1582, 'sborrone', '', 0),
(1583, 'sbrodolata', '', 0),
(1584, 'scopare', '', 0),
(1585, 'scopata', '', 0),
(1586, 'scorreggiare', '', 0),
(1587, 'sega', '', 0),
(1588, 'slinguare', '', 0),
(1589, 'slinguata', '', 0),
(1590, 'smandrappata', '', 0),
(1591, 'soccia', '', 0),
(1592, 'socmel', '', 0),
(1593, 'sorca', '', 0),
(1594, 'spagnola', '', 0),
(1595, 'spompinare', '', 0),
(1596, 'sticchio', '', 0),
(1597, 'stronza', '', 0),
(1598, 'stronzata', '', 0),
(1599, 'stronzo', '', 0),
(1600, 'succhiami', '', 0),
(1601, 'sveltina', '', 0),
(1602, 'sverginare', '', 0),
(1603, 'tarzanello', '', 0),
(1604, 'terrone', '', 0),
(1605, 'testa di cazzo', '', 0),
(1606, 'tette', '', 0),
(1607, 'tirare', '', 0),
(1608, 'topa', '', 0),
(1609, 'troia', '', 0),
(1610, 'trombare', '', 0),
(1611, 'uccello', '', 0),
(1612, 'vacca', '', 0),
(1613, 'vaffanculo', '', 0),
(1614, 'vangare', '', 0),
(1615, 'venire', '', 0),
(1616, 'zinne', '', 0),
(1617, 'zio cantante', '', 0),
(1618, 'zoccola', '', 0),
(1619, 'affanculo', '', 0),
(1620, 'bocchinaro', '', 0),
(1621, 'cazzi', '', 0),
(1622, 'dio bestia', '', 0),
(1623, 'dio cane', '', 0),
(1624, 'dio porco', '', 0),
(1625, 'inculare', '', 0),
(1626, 'pompinara', '', 0),
(1627, 'porco dio', '', 0),
(1628, 'ricchione', '', 0),
(1629, 'rottinculo', '', 0),
(1630, 'segaiolo', '', 0),
(1631, 'troietta', '', 0),
(1632, 'troiona', '', 0),
(1633, 'troione', '', 0),
(1634, 'あいえき', '', 0),
(1635, 'せいえき', '', 0),
(1636, 'ファック', '', 0),
(1637, 'いぬごろし', '', 0),
(1638, 'いんぱい', '', 0),
(1639, 'いんもう', '', 0),
(1640, 'うんこ', '', 0),
(1641, 'うんち', '', 0),
(1642, 'おめこ', '', 0),
(1643, 'かたわ', '', 0),
(1644, 'きちがい', '', 0),
(1645, 'くろんぼ', '', 0),
(1646, 'けとう', '', 0),
(1647, 'ころす', '', 0),
(1648, 'ごうかん', '', 0),
(1649, 'さんごくじん', '', 0),
(1650, 'しなじん', '', 0),
(1651, 'しね', '', 0),
(1652, 'せっくす', '', 0),
(1653, 'ちゃんころ', '', 0),
(1654, 'ちんこ', '', 0),
(1655, 'ちんちん', '', 0),
(1656, 'ちんぽ', '', 0),
(1657, 'ちんば', '', 0),
(1658, 'つんぼ', '', 0),
(1659, 'どかた', '', 0),
(1660, 'とさつ', '', 0),
(1661, 'どもり', '', 0),
(1662, 'にぐろ', '', 0),
(1663, 'にんぴにん', '', 0),
(1664, 'びっこ', '', 0),
(1665, 'ひにん', '', 0),
(1666, 'ふぇら', '', 0),
(1667, 'ぶらく', '', 0),
(1668, 'ぺにす', '', 0),
(1669, 'まんこ', '', 0),
(1670, 'おまんこ', '', 0),
(1671, 'めくら', '', 0),
(1672, 'やらせろ', '', 0),
(1673, 'やりまん', '', 0),
(1674, 'りょうじょく', '', 0),
(1675, 'れいぷ', '', 0),
(1676, 'ろりこん', '', 0),
(1677, '강간', '', 0),
(1678, '개새끼', '', 0),
(1679, '개지랄', '', 0),
(1680, '걸레같은년', '', 0),
(1681, '걸레년', '', 0),
(1682, '귀두', '', 0),
(1683, '빨아', '', 0),
(1684, '핥아', '', 0),
(1685, '니미랄', '', 0),
(1686, '딸딸이', '', 0),
(1687, '미친년', '', 0),
(1688, '미친놈', '', 0),
(1689, '병신', '', 0),
(1690, '보지', '', 0),
(1691, '부랄', '', 0),
(1692, '불알', '', 0),
(1693, '빠구리', '', 0),
(1694, '빠굴이', '', 0),
(1695, '사까시', '', 0),
(1696, '꼡성감대', '', 0),
(1697, '성관계', '', 0),
(1698, '냕성폭행', '', 0),
(1699, '성행위', '', 0),
(1700, '섹스', '', 0),
(1701, '시팔년', '', 0),
(1702, '시팔놈', '', 0),
(1703, '쌍넘', '', 0),
(1704, '쌍년', '', 0),
(1705, '쌍놈', '', 0),
(1706, '쌍뇬', '', 0),
(1707, '씨발', '', 0),
(1708, '씨발넘', '', 0),
(1709, '씨발년', '', 0),
(1710, '씨발놈', '', 0),
(1711, '씨발뇬', '', 0),
(1712, '씹새끼', '', 0),
(1713, '염병', '', 0),
(1714, '오르', '', 0),
(1715, '왕자지', '', 0),
(1716, '유두', '', 0),
(1717, '자지', '', 0),
(1718, '잠지', '', 0),
(1719, '정액', '', 0),
(1720, '창녀', '', 0),
(1721, '콘돔', '', 0),
(1722, '클리토리스', '', 0),
(1723, '페니스', '', 0),
(1724, '후장', '', 0),
(1725, 'abortus', '', 0),
(1726, 'achterlijk', '', 0),
(1727, 'bosneger', '', 0),
(1728, 'debiel', '', 0),
(1729, 'etterbak', '', 0),
(1730, 'flikker', '', 0),
(1731, 'flikker op', '', 0),
(1732, 'fock', '', 0),
(1733, 'geil', '', 0),
(1734, 'godver', '', 0),
(1735, 'godverju', '', 0),
(1736, 'hoertje', '', 0),
(1737, 'homofiel', '', 0),
(1738, 'huppelkut', '', 0),
(1739, 'kak', '', 0),
(1740, 'kakker', '', 0),
(1741, 'kanker', '', 0),
(1742, 'kankeren', '', 0),
(1743, 'kankerjoch', '', 0),
(1744, 'kankerlyer', '', 0),
(1745, 'klerelijer', '', 0),
(1746, 'klojo', '', 0),
(1747, 'kut', '', 0),
(1748, 'lijer', '', 0),
(1749, 'lul', '', 0),
(1750, 'lulhannes', '', 0),
(1751, 'makak', '', 0),
(1752, 'makakken', '', 0),
(1753, 'mof', '', 0),
(1754, 'mongool', '', 0),
(1755, 'mongolen', '', 0),
(1756, 'neger', '', 0),
(1757, 'negerin', '', 0),
(1758, 'neuk', '', 0),
(1759, 'neuken', '', 0),
(1760, 'nikker', '', 0),
(1761, 'nsb', '', 0),
(1762, 'nsber', '', 0),
(1763, 'ouwehoeren', '', 0),
(1764, 'paardelul', '', 0),
(1765, 'pik', '', 0),
(1766, 'pleuris', '', 0),
(1767, 'poep', '', 0),
(1768, 'poepen', '', 0),
(1769, 'pokke', '', 0),
(1770, 'pokkelijer', '', 0),
(1771, 'pokkelyer', '', 0),
(1772, 'pokken', '', 0),
(1773, 'pokkenlyer', '', 0),
(1774, 'roetmop', '', 0),
(1775, 'rotzak', '', 0),
(1776, 'seks', '', 0),
(1777, 'slet', '', 0),
(1778, 'sloerie', '', 0),
(1779, 'snol', '', 0),
(1780, 'spleetoog', '', 0),
(1781, 'stoephoer', '', 0),
(1782, 'stront', '', 0),
(1783, 'sukkel', '', 0),
(1784, 'tering', '', 0),
(1785, 'teringlyer', '', 0),
(1786, 'tiet', '', 0),
(1787, 'tieten', '', 0),
(1788, 'tietjes', '', 0),
(1789, 'trut', '', 0),
(1790, 'tyfus', '', 0),
(1791, 'tyfuslijer', '', 0),
(1792, 'tyfuslyer', '', 0),
(1793, 'verdomme', '', 0),
(1794, 'vetzak', '', 0),
(1795, 'zakkewassr', '', 0),
(1796, 'zandneger', '', 0),
(1797, 'dritt', '', 0),
(1798, 'drittsekk', '', 0),
(1799, 'dust', '', 0),
(1800, 'fæn', '', 0),
(1801, 'fanden', '', 0),
(1802, 'helvette', '', 0),
(1803, 'hora', '', 0),
(1804, 'jævel', '', 0),
(1805, 'jævla', '', 0),
(1806, 'kjerring', '', 0),
(1807, 'ludder', '', 0),
(1808, 'pedofil', '', 0),
(1809, 'pokker', '', 0),
(1810, 'quisling', '', 0),
(1811, 'satan', '', 0),
(1812, 'sattan', '', 0),
(1813, 'søren', '', 0),
(1814, 'bordel', '', 0),
(1815, 'buzna', '', 0),
(1816, 'čumět', '', 0),
(1817, 'čurák', '', 0),
(1818, 'debil', '', 0),
(1819, 'do piče', '', 0),
(1820, 'do prdele', '', 0),
(1821, 'dršťka', '', 0),
(1822, 'držka', '', 0),
(1823, 'flundra', '', 0),
(1824, 'hajzl', '', 0),
(1825, 'hovno', '', 0),
(1826, 'chcanky', '', 0),
(1827, 'jebat', '', 0),
(1828, 'kokot', '', 0),
(1829, 'kokotina', '', 0),
(1830, 'koňomrd', '', 0),
(1831, 'kunda', '', 0),
(1832, 'kurva', '', 0),
(1833, 'mamrd', '', 0),
(1834, 'mrdat', '', 0),
(1835, 'mrdka', '', 0),
(1836, 'mrdník', '', 0),
(1837, 'oslošoust', '', 0),
(1838, 'piča', '', 0),
(1839, 'píčus', '', 0),
(1840, 'píchat', '', 0),
(1841, 'prcat', '', 0),
(1842, 'prdel', '', 0),
(1843, 'prdelka', '', 0),
(1844, 'sračka', '', 0),
(1845, 'srát', '', 0),
(1846, 'šoustat', '', 0),
(1847, 'šulin', '', 0),
(1848, 'vypíčenec', '', 0),
(1849, 'zkurvit', '', 0),
(1850, 'zkurvysyn', '', 0),
(1851, 'zmrd', '', 0),
(1852, 'žrát', '', 0),
(1853, 'bøsserøv', '', 0),
(1854, 'fisse', '', 0),
(1855, 'fissehår', '', 0),
(1856, 'hestepik', '', 0),
(1857, 'kussekryller', '', 0),
(1858, 'lort', '', 0),
(1859, 'luder', '', 0),
(1860, 'pikhår', '', 0),
(1861, 'pikslugeri', '', 0),
(1862, 'piksutteri', '', 0),
(1863, 'pis', '', 0),
(1864, 'røv', '', 0),
(1865, 'røvhul', '', 0),
(1866, 'røvskæg', '', 0),
(1867, 'røvspræke', '', 0),
(1868, 'analritter', '', 0),
(1869, 'arsch', '', 0),
(1870, 'arschficker', '', 0),
(1871, 'arschlecker', '', 0),
(1872, 'bratze', '', 0),
(1873, 'bumsen', '', 0),
(1874, 'bonze', '', 0),
(1875, 'dödel', '', 0),
(1876, 'fick', '', 0),
(1877, 'flittchen', '', 0),
(1878, 'fratze', '', 0),
(1879, 'hackfresse', '', 0),
(1880, 'hure', '', 0),
(1881, 'hurensohn', '', 0),
(1882, 'ische', '', 0),
(1883, 'kackbratze', '', 0),
(1884, 'kacke', '', 0),
(1885, 'kacken', '', 0),
(1886, 'kackwurst', '', 0),
(1887, 'kampflesbe', '', 0),
(1888, 'kanake', '', 0),
(1889, 'kimme', '', 0),
(1890, 'lümmel', '', 0),
(1891, 'MILF', '', 0),
(1892, 'möpse', '', 0),
(1893, 'morgenlatte', '', 0),
(1894, 'möse', '', 0),
(1895, 'mufti', '', 0),
(1896, 'nackt', '', 0),
(1897, 'nippel', '', 0),
(1898, 'nutte', '', 0),
(1899, 'onanieren', '', 0),
(1900, 'orgasmus', '', 0),
(1901, 'pimpern', '', 0),
(1902, 'pinkeln', '', 0),
(1903, 'pissen', '', 0),
(1904, 'popel', '', 0),
(1905, 'poppen', '', 0),
(1906, 'reudig', '', 0),
(1907, 'rosette', '', 0),
(1908, 'schabracke', '', 0),
(1909, 'scheiße', '', 0),
(1910, 'schnackeln', '', 0),
(1911, 'schwanzlutscher', '', 0),
(1912, 'schwuchtel', '', 0),
(1913, 'tittchen', '', 0),
(1914, 'titten', '', 0),
(1915, 'vögeln', '', 0),
(1916, 'vollpfosten', '', 0),
(1917, 'wichse', '', 0),
(1918, 'wichsen', '', 0),
(1919, '2g1c', '', 0),
(1920, '2 girls 1 cup', '', 0),
(1921, 'acrotomophilia', '', 0),
(1922, 'alabama hot pocket', '', 0),
(1923, 'alaskan pipeline', '', 0),
(1924, 'apeshit', '', 0),
(1925, 'auto erotic', '', 0),
(1926, 'babeland', '', 0),
(1927, 'baby batter', '', 0),
(1928, 'baby juice', '', 0),
(1929, 'ball gag', '', 0),
(1930, 'ball gravy', '', 0),
(1931, 'ball kicking', '', 0),
(1932, 'ball licking', '', 0),
(1933, 'ball sack', '', 0),
(1934, 'ball sucking', '', 0),
(1935, 'barely legal', '', 0),
(1936, 'barenaked', '', 0),
(1937, 'bastardo', '', 0),
(1938, 'bastinado', '', 0),
(1939, 'bbw', '', 0),
(1940, 'bdsm', '', 0),
(1941, 'beaner', '', 0),
(1942, 'beaners', '', 0),
(1943, 'beaver cleaver', '', 0),
(1944, 'beaver lips', '', 0),
(1945, 'big black', '', 0),
(1946, 'big breasts', '', 0),
(1947, 'big knockers', '', 0),
(1948, 'big tits', '', 0),
(1949, 'black cock', '', 0),
(1950, 'blonde action', '', 0),
(1951, 'blonde on blonde action', '', 0),
(1952, 'blow your load', '', 0),
(1953, 'bondage', '', 0),
(1954, 'booty call', '', 0),
(1955, 'brown showers', '', 0),
(1956, 'brunette action', '', 0),
(1957, 'bulldyke', '', 0),
(1958, 'bullet vibe', '', 0),
(1959, 'bung hole', '', 0),
(1960, 'bunghole', '', 0),
(1961, 'buttcheeks', '', 0),
(1962, 'camel toe', '', 0),
(1963, 'camgirl', '', 0),
(1964, 'camslut', '', 0),
(1965, 'camwhore', '', 0),
(1966, 'chocolate rosebuds', '', 0),
(1967, 'circlejerk', '', 0),
(1968, 'cleveland steamer', '', 0),
(1969, 'clover clamps', '', 0),
(1970, 'coprolagnia', '', 0),
(1971, 'coprophilia', '', 0),
(1972, 'coons', '', 0),
(1973, 'creampie', '', 0),
(1974, 'darkie', '', 0),
(1975, 'date rape', '', 0),
(1976, 'daterape', '', 0),
(1977, 'deep throat', '', 0),
(1978, 'deepthroat', '', 0),
(1979, 'dendrophilia', '', 0),
(1980, 'dirty pillows', '', 0),
(1981, 'dirty sanchez', '', 0),
(1982, 'doggy style', '', 0),
(1983, 'dog style', '', 0),
(1984, 'dolcett', '', 0),
(1985, 'domination', '', 0),
(1986, 'dommes', '', 0),
(1987, 'donkey punch', '', 0),
(1988, 'double dong', '', 0),
(1989, 'double penetration', '', 0),
(1990, 'dp action', '', 0),
(1991, 'dry hump', '', 0),
(1992, 'dvda', '', 0),
(1993, 'eat my ass', '', 0),
(1994, 'ecchi', '', 0),
(1995, 'erotism', '', 0),
(1996, 'escort', '', 0),
(1997, 'ethical slut', '', 0),
(1998, 'eunuch', '', 0),
(1999, 'fecal', '', 0),
(2000, 'felch', '', 0),
(2001, 'feltch', '', 0),
(2002, 'female squirting', '', 0),
(2003, 'femdom', '', 0),
(2004, 'figging', '', 0),
(2005, 'fingerbang', '', 0),
(2006, 'fingering', '', 0),
(2007, 'fisting', '', 0),
(2008, 'foot fetish', '', 0),
(2009, 'footjob', '', 0),
(2010, 'frotting', '', 0),
(2011, 'fuck buttons', '', 0),
(2012, 'futanari', '', 0),
(2013, 'gang bang', '', 0),
(2014, 'gay sex', '', 0),
(2015, 'giant cock', '', 0),
(2016, 'girl on', '', 0),
(2017, 'girl on top', '', 0),
(2018, 'girls gone wild', '', 0),
(2019, 'goatcx', '', 0),
(2020, 'god damn', '', 0),
(2021, 'gokkun', '', 0),
(2022, 'golden shower', '', 0),
(2023, 'goodpoop', '', 0),
(2024, 'goo girl', '', 0),
(2025, 'goregasm', '', 0),
(2026, 'grope', '', 0),
(2027, 'group sex', '', 0),
(2028, 'g-spot', '', 0),
(2029, 'guro', '', 0),
(2030, 'hand job', '', 0),
(2031, 'hard core', '', 0),
(2032, 'hardcore', '', 0),
(2033, 'hentai', '', 0),
(2034, 'hot carl', '', 0),
(2035, 'hot chick', '', 0),
(2036, 'how to murder', '', 0),
(2037, 'huge fat', '', 0),
(2038, 'incest', '', 0),
(2039, 'intercourse', '', 0),
(2040, 'jack off', '', 0),
(2041, 'jail bait', '', 0),
(2042, 'jailbait', '', 0),
(2043, 'jelly donut', '', 0),
(2044, 'jerk off', '', 0),
(2045, 'jigaboo', '', 0),
(2046, 'jiggaboo', '', 0),
(2047, 'jiggerboo', '', 0),
(2048, 'juggs', '', 0),
(2049, 'kinbaku', '', 0),
(2050, 'kinkster', '', 0),
(2051, 'kinky', '', 0),
(2052, 'knobbing', '', 0),
(2053, 'leather restraint', '', 0),
(2054, 'leather straight jacket', '', 0),
(2055, 'lemon party', '', 0),
(2056, 'lolita', '', 0),
(2057, 'lovemaking', '', 0),
(2058, 'make me come', '', 0),
(2059, 'male squirting', '', 0),
(2060, 'menage a trois', '', 0),
(2061, 'missionary position', '', 0),
(2062, 'mound of venus', '', 0),
(2063, 'mr hands', '', 0),
(2064, 'muff diver', '', 0),
(2065, 'muffdiving', '', 0),
(2066, 'nambla', '', 0),
(2067, 'nawashi', '', 0),
(2068, 'neonazi', '', 0),
(2069, 'nig nog', '', 0),
(2070, 'nimphomania', '', 0),
(2071, 'nipple', '', 0),
(2072, 'nipples', '', 0),
(2073, 'nsfw images', '', 0),
(2074, 'nude', '', 0),
(2075, 'nudity', '', 0),
(2076, 'nympho', '', 0),
(2077, 'nymphomania', '', 0),
(2078, 'octopussy', '', 0),
(2079, 'omorashi', '', 0),
(2080, 'one cup two girls', '', 0),
(2081, 'one guy one jar', '', 0),
(2082, 'orgy', '', 0),
(2083, 'panties', '', 0),
(2084, 'panty', '', 0),
(2085, 'pedobear', '', 0),
(2086, 'pegging', '', 0),
(2087, 'phone sex', '', 0),
(2088, 'piece of shit', '', 0),
(2089, 'piss pig', '', 0),
(2090, 'pisspig', '', 0),
(2091, 'playboy', '', 0),
(2092, 'pleasure chest', '', 0),
(2093, 'pole smoker', '', 0),
(2094, 'ponyplay', '', 0),
(2095, 'poontang', '', 0),
(2096, 'punany', '', 0),
(2097, 'poop chute', '', 0),
(2098, 'poopchute', '', 0),
(2099, 'prince albert piercing', '', 0),
(2100, 'pthc', '', 0),
(2101, 'pubes', '', 0),
(2102, 'queaf', '', 0),
(2103, 'raghead', '', 0);
INSERT INTO `Table_Bad_Word` (`ID`, `_WORD`, `_REPLACEMENT`, `_HOW_TIME`) VALUES
(2104, 'raging boner', '', 0),
(2105, 'raping', '', 0),
(2106, 'reverse cowgirl', '', 0),
(2107, 'rosy palm', '', 0),
(2108, 'rosy palm and her 5 sisters', '', 0),
(2109, 'rusty trombone', '', 0),
(2110, 'santorum', '', 0),
(2111, 'scat', '', 0),
(2112, 'scissoring', '', 0),
(2113, 'sexo', '', 0),
(2114, 'shaved beaver', '', 0),
(2115, 'shaved pussy', '', 0),
(2116, 'shibari', '', 0),
(2117, 'shota', '', 0),
(2118, 'shrimping', '', 0),
(2119, 'skeet', '', 0),
(2120, 'slanteye', '', 0),
(2121, 's&m', '', 0),
(2122, 'snowballing', '', 0),
(2123, 'sodomize', '', 0),
(2124, 'sodomy', '', 0),
(2125, 'splooge moose', '', 0),
(2126, 'spread legs', '', 0),
(2127, 'strap on', '', 0),
(2128, 'strapon', '', 0),
(2129, 'strappado', '', 0),
(2130, 'strip club', '', 0),
(2131, 'style doggy', '', 0),
(2132, 'suck', '', 0),
(2133, 'sucks', '', 0),
(2134, 'suicide girls', '', 0),
(2135, 'sultry women', '', 0),
(2136, 'swastika', '', 0),
(2137, 'swinger', '', 0),
(2138, 'tainted love', '', 0),
(2139, 'taste my', '', 0),
(2140, 'tea bagging', '', 0),
(2141, 'threesome', '', 0),
(2142, 'throating', '', 0),
(2143, 'tied up', '', 0),
(2144, 'tight white', '', 0),
(2145, 'tongue in a', '', 0),
(2146, 'topless', '', 0),
(2147, 'towelhead', '', 0),
(2148, 'tranny', '', 0),
(2149, 'tribadism', '', 0),
(2150, 'tub girl', '', 0),
(2151, 'tubgirl', '', 0),
(2152, 'tushy', '', 0),
(2153, 'twink', '', 0),
(2154, 'twinkie', '', 0),
(2155, 'two girls one cup', '', 0),
(2156, 'undressing', '', 0),
(2157, 'upskirt', '', 0),
(2158, 'urethra play', '', 0),
(2159, 'urophilia', '', 0),
(2160, 'venus mound', '', 0),
(2161, 'violet wand', '', 0),
(2162, 'vorarephilia', '', 0),
(2163, 'voyeur', '', 0),
(2164, 'wet dream', '', 0),
(2165, 'white power', '', 0),
(2166, 'wrapping men', '', 0),
(2167, 'wrinkled starfish', '', 0),
(2168, 'xx', '', 0),
(2169, 'yaoi', '', 0),
(2170, 'yellow showers', '', 0),
(2171, 'yiffy', '', 0),
(2172, 'zoophilia', '', 0),
(2173, 'bugren', '', 0),
(2174, 'bugri', '', 0),
(2175, 'bugru', '', 0),
(2176, 'ĉiesulino', '', 0),
(2177, 'ĉiesulo', '', 0),
(2178, 'diofek', '', 0),
(2179, 'diofeka', '', 0),
(2180, 'fek', '', 0),
(2181, 'feken', '', 0),
(2182, 'fekfikanto', '', 0),
(2183, 'feklekulo', '', 0),
(2184, 'fekulo', '', 0),
(2185, 'fik', '', 0),
(2186, 'fikado', '', 0),
(2187, 'fikema', '', 0),
(2188, 'fikfek', '', 0),
(2189, 'fiki', '', 0),
(2190, 'fikiĝi', '', 0),
(2191, 'fikiĝu', '', 0),
(2192, 'fikilo', '', 0),
(2193, 'fikklaŭno', '', 0),
(2194, 'fikota', '', 0),
(2195, 'fiku', '', 0),
(2196, 'forfiki', '', 0),
(2197, 'forfikiĝu', '', 0),
(2198, 'forfiku', '', 0),
(2199, 'forfurzu', '', 0),
(2200, 'forpisi', '', 0),
(2201, 'forpisu', '', 0),
(2202, 'furzulo', '', 0),
(2203, 'kacen', '', 0),
(2204, 'kaco', '', 0),
(2205, 'kacsuĉulo', '', 0),
(2206, 'kojono', '', 0),
(2207, 'piĉen', '', 0),
(2208, 'piĉo', '', 0),
(2209, 'zamenfek', '', 0),
(2210, 'Asesinato', '', 0),
(2211, 'asno', '', 0),
(2212, 'Bollera', '', 0),
(2213, 'Cabron', '', 0),
(2214, 'Cabrón', '', 0),
(2215, 'Caca', '', 0),
(2216, 'Chupada', '', 0),
(2217, 'Chupapollas', '', 0),
(2218, 'Chupetón', '', 0),
(2219, 'concha', '', 0),
(2220, 'Concha de tu madre', '', 0),
(2221, 'Coño', '', 0),
(2222, 'Coprofagía', '', 0),
(2223, 'Culo', '', 0),
(2224, 'Drogas', '', 0),
(2225, 'Esperma', '', 0),
(2226, 'Fiesta de salchichas', '', 0),
(2227, 'Follador', '', 0),
(2228, 'Follar', '', 0),
(2229, 'Gilipichis', '', 0),
(2230, 'Gilipollas', '', 0),
(2231, 'Hacer una paja', '', 0),
(2232, 'Haciendo el amor', '', 0),
(2233, 'Heroína', '', 0),
(2234, 'Hija de puta', '', 0),
(2235, 'Hijaputa', '', 0),
(2236, 'Hijo de puta', '', 0),
(2237, 'Hijoputa', '', 0),
(2238, 'Idiota', '', 0),
(2239, 'Imbécil', '', 0),
(2240, 'infierno', '', 0),
(2241, 'Jilipollas', '', 0),
(2242, 'Kapullo', '', 0),
(2243, 'Lameculos', '', 0),
(2244, 'Maciza', '', 0),
(2245, 'Macizorra', '', 0),
(2246, 'maldito', '', 0),
(2247, 'Mamada', '', 0),
(2248, 'Marica', '', 0),
(2249, 'Maricón', '', 0),
(2250, 'Mariconazo', '', 0),
(2251, 'martillo', '', 0),
(2252, 'Mierda', '', 0),
(2253, 'Nazi', '', 0),
(2254, 'Orina', '', 0),
(2255, 'Pedo', '', 0),
(2256, 'Pervertido', '', 0),
(2257, 'Pezón', '', 0),
(2258, 'Pinche', '', 0),
(2259, 'Pis', '', 0),
(2260, 'Prostituta', '', 0),
(2261, 'Puta', '', 0),
(2262, 'Racista', '', 0),
(2263, 'Ramera', '', 0),
(2264, 'Sádico', '', 0),
(2265, 'Semen', '', 0),
(2266, 'Sexo', '', 0),
(2267, 'Sexo oral', '', 0),
(2268, 'Soplagaitas', '', 0),
(2269, 'Soplapollas', '', 0),
(2270, 'Tetas grandes', '', 0),
(2271, 'Tía buena', '', 0),
(2272, 'Travesti', '', 0),
(2273, 'Trio', '', 0),
(2274, 'Verga', '', 0),
(2275, 'vete a la mierda', '', 0),
(2276, 'Vulva', '', 0),
(2277, 'alfred nussi', '', 0),
(2278, 'bylsiä', '', 0),
(2279, 'haahka', '', 0),
(2280, 'haista paska', '', 0),
(2281, 'haista vittu', '', 0),
(2282, 'hatullinen', '', 0),
(2283, 'helvetisti', '', 0),
(2284, 'hevonkuusi', '', 0),
(2285, 'hevonpaska', '', 0),
(2286, 'hevonperse', '', 0),
(2287, 'hevonvittu', '', 0),
(2288, 'hevonvitunperse', '', 0),
(2289, 'hitosti', '', 0),
(2290, 'hitto', '', 0),
(2291, 'huorata', '', 0),
(2292, 'hässiä', '', 0),
(2293, 'juosten kustu', '', 0),
(2294, 'jutku', '', 0),
(2295, 'jutsku', '', 0),
(2296, 'jätkä', '', 0),
(2297, 'kananpaska', '', 0),
(2298, 'koiranpaska', '', 0),
(2299, 'kuin esterin perseestä', '', 0),
(2300, 'kulli', '', 0),
(2301, 'kullinluikaus', '', 0),
(2302, 'kuppainen', '', 0),
(2303, 'kusaista', '', 0),
(2304, 'kuseksia', '', 0),
(2305, 'kusettaa', '', 0),
(2306, 'kusi', '', 0),
(2307, 'kusta', '', 0),
(2308, 'kyrpiintynyt', '', 0),
(2309, 'kyrpiintyä', '', 0),
(2310, 'kyrpänaama', '', 0),
(2311, 'kyrvitys', '', 0),
(2312, 'lahtari', '', 0),
(2313, 'lutka', '', 0),
(2314, 'molo', '', 0),
(2315, 'molopää', '', 0),
(2316, 'mulkero', '', 0),
(2317, 'mulkvisti', '', 0),
(2318, 'muna', '', 0),
(2319, 'munapää', '', 0),
(2320, 'munaton', '', 0),
(2321, 'mutakuono', '', 0),
(2322, 'mutiainen', '', 0),
(2323, 'naida', '', 0),
(2324, 'nainti', '', 0),
(2325, 'nekru', '', 0),
(2326, 'nuolla persettä', '', 0),
(2327, 'nussia', '', 0),
(2328, 'nussija', '', 0),
(2329, 'nussinta', '', 0),
(2330, 'paljaalla', '', 0),
(2331, 'palli', '', 0),
(2332, 'pallit', '', 0),
(2333, 'paneskella', '', 0),
(2334, 'panettaa', '', 0),
(2335, 'panna', '', 0),
(2336, 'pano', '', 0),
(2337, 'pantava', '', 0),
(2338, 'paskainen', '', 0),
(2339, 'paskamainen', '', 0),
(2340, 'paskanmarjat', '', 0),
(2341, 'paskantaa', '', 0),
(2342, 'paskapuhe', '', 0),
(2343, 'paskapää', '', 0),
(2344, 'paskattaa', '', 0),
(2345, 'paskiainen', '', 0),
(2346, 'paskoa', '', 0),
(2347, 'pehko', '', 0),
(2348, 'pentele', '', 0),
(2349, 'perkeleesti', '', 0),
(2350, 'persaukinen', '', 0),
(2351, 'perseennuolija', '', 0),
(2352, 'perseet olalla', '', 0),
(2353, 'persereikä', '', 0),
(2354, 'perseääliö', '', 0),
(2355, 'persläpi', '', 0),
(2356, 'perspano', '', 0),
(2357, 'persvako', '', 0),
(2358, 'pilkunnussija', '', 0),
(2359, 'pipari', '', 0),
(2360, 'piru', '', 0),
(2361, 'pistää', '', 0),
(2362, 'pyllyvako', '', 0),
(2363, 'reikä', '', 0),
(2364, 'reva', '', 0),
(2365, 'ripsipiirakka', '', 0),
(2366, 'runkata', '', 0),
(2367, 'runkkari', '', 0),
(2368, 'runkkaus', '', 0),
(2369, 'runkku', '', 0),
(2370, 'ryssä', '', 0),
(2371, 'rättipää', '', 0),
(2372, 'saatanasti', '', 0),
(2373, 'suklaaosasto', '', 0),
(2374, 'tavara', '', 0),
(2375, 'toosa', '', 0),
(2376, 'tuhkaluukku', '', 0),
(2377, 'tumputtaa', '', 0),
(2378, 'turpasauna', '', 0),
(2379, 'tussu', '', 0),
(2380, 'tussukka', '', 0),
(2381, 'tussut', '', 0),
(2382, 'vakipano', '', 0),
(2383, 'vetää käteen', '', 0),
(2384, 'viiksi', '', 0),
(2385, 'vittuilla', '', 0),
(2386, 'vittuilu', '', 0),
(2387, 'vittumainen', '', 0),
(2388, 'vittuuntua', '', 0),
(2389, 'vittuuntunut', '', 0),
(2390, 'vitusti', '', 0),
(2391, 'vituttaa', '', 0),
(2392, 'vitutus', '', 0),
(2393, 'äpärä', '', 0),
(2394, 'allumé', '', 0),
(2395, 'allumée', '', 0),
(2396, 'bander', '', 0),
(2397, 'bigornette', '', 0),
(2398, 'bitte', '', 0),
(2399, 'bloblos', '', 0),
(2400, 'bosser', '', 0),
(2401, 'bourré', '', 0),
(2402, 'bourrée', '', 0),
(2403, 'branlage', '', 0),
(2404, 'branler', '', 0),
(2405, 'branlette', '', 0),
(2406, 'branleuse', '', 0),
(2407, 'brouter le cresson', '', 0),
(2408, 'caca', '', 0),
(2409, 'cailler', '', 0),
(2410, 'chatte', '', 0),
(2411, 'chiasse', '', 0),
(2412, 'chiottes', '', 0),
(2413, 'clito', '', 0),
(2414, 'couilles', '', 0),
(2415, 'cramouille', '', 0),
(2416, 'déconne', '', 0),
(2417, 'déconner', '', 0),
(2418, 'drague', '', 0),
(2419, 'emmerdant', '', 0),
(2420, 'emmerder', '', 0),
(2421, 'emmerdeur', '', 0),
(2422, 'emmerdeuse', '', 0),
(2423, 'enfoirée', '', 0),
(2424, 'étron', '', 0),
(2425, 'fille de pute', '', 0),
(2426, 'fils de pute', '', 0),
(2427, 'folle', '', 0),
(2428, 'gerber', '', 0),
(2429, 'gouine', '', 0),
(2430, 'grande folle', '', 0),
(2431, 'grogniasse', '', 0),
(2432, 'gueule', '', 0),
(2433, 'jouir', '', 0),
(2434, 'la putain de ta mère', '', 0),
(2435, 'MALPT', '', 0),
(2436, 'ménage a trois', '', 0),
(2437, 'merdeuse', '', 0),
(2438, 'merdeux', '', 0),
(2439, 'meuf', '', 0),
(2440, 'nique ta mère', '', 0),
(2441, 'noune', '', 0),
(2442, 'palucher', '', 0),
(2443, 'pédale', '', 0),
(2444, 'péter', '', 0),
(2445, 'pipe', '', 0),
(2446, 'pipi', '', 0),
(2447, 'pousse-crotte', '', 0),
(2448, 'queue', '', 0),
(2449, 'ramoner', '', 0),
(2450, 'serin', '', 0),
(2451, 'service trois pièces', '', 0),
(2452, 'suce', '', 0),
(2453, 'teuf', '', 0),
(2454, 'trick', '', 0),
(2455, 'tringler', '', 0),
(2456, 'trique', '', 0),
(2457, 'trou du cul', '', 0),
(2458, 'turlute', '', 0),
(2459, 'veuve', '', 0),
(2460, 'aand', '', 0),
(2461, 'aandu', '', 0),
(2462, 'balatkar', '', 0),
(2463, 'beti chod', '', 0),
(2464, 'bhadva', '', 0),
(2465, 'bhadve', '', 0),
(2466, 'bhandve', '', 0),
(2467, 'bhootni ke', '', 0),
(2468, 'bhosad', '', 0),
(2469, 'bhosadi ke', '', 0),
(2470, 'boobe', '', 0),
(2471, 'chakke', '', 0),
(2472, 'chinaal', '', 0),
(2473, 'chinki', '', 0),
(2474, 'chod', '', 0),
(2475, 'chodu', '', 0),
(2476, 'chodu bhagat', '', 0),
(2477, 'chooche', '', 0),
(2478, 'choochi', '', 0),
(2479, 'choot', '', 0),
(2480, 'choot ke baal', '', 0),
(2481, 'chootia', '', 0),
(2482, 'chootiya', '', 0),
(2483, 'chuche', '', 0),
(2484, 'chuchi', '', 0),
(2485, 'chudai khanaa', '', 0),
(2486, 'chudan chudai', '', 0),
(2487, 'chut', '', 0),
(2488, 'chut ke baal', '', 0),
(2489, 'chut ke dhakkan', '', 0),
(2490, 'chut maarli', '', 0),
(2491, 'chutad', '', 0),
(2492, 'chutadd', '', 0),
(2493, 'chutan', '', 0),
(2494, 'chutia', '', 0),
(2495, 'chutiya', '', 0),
(2496, 'gaand', '', 0),
(2497, 'gaandfat', '', 0),
(2498, 'gaandmasti', '', 0),
(2499, 'gaandufad', '', 0),
(2500, 'gandu', '', 0),
(2501, 'gashti', '', 0),
(2502, 'gasti', '', 0),
(2503, 'ghassa', '', 0),
(2504, 'ghasti', '', 0),
(2505, 'harami', '', 0),
(2506, 'haramzade', '', 0),
(2507, 'hawas', '', 0),
(2508, 'hawas ke pujari', '', 0),
(2509, 'hijda', '', 0),
(2510, 'hijra', '', 0),
(2511, 'jhant', '', 0),
(2512, 'jhant chaatu', '', 0),
(2513, 'jhant ke baal', '', 0),
(2514, 'jhantu', '', 0),
(2515, 'kamine', '', 0),
(2516, 'kaminey', '', 0),
(2517, 'kanjar', '', 0),
(2518, 'kutta', '', 0),
(2519, 'kutta kamina', '', 0),
(2520, 'kutte ki aulad', '', 0),
(2521, 'kutte ki jat', '', 0),
(2522, 'kuttiya', '', 0),
(2523, 'loda', '', 0),
(2524, 'lodu', '', 0),
(2525, 'lund', '', 0),
(2526, 'lund choos', '', 0),
(2527, 'lund khajoor', '', 0),
(2528, 'lundtopi', '', 0),
(2529, 'lundure', '', 0),
(2530, 'maa ki chut', '', 0),
(2531, 'maal', '', 0),
(2532, 'madar chod', '', 0),
(2533, 'mooh mein le', '', 0),
(2534, 'mutth', '', 0),
(2535, 'najayaz', '', 0),
(2536, 'najayaz aulaad', '', 0),
(2537, 'najayaz paidaish', '', 0),
(2538, 'pataka', '', 0),
(2539, 'patakha', '', 0),
(2540, 'raand', '', 0),
(2541, 'randi', '', 0),
(2542, 'saala', '', 0),
(2543, 'saala kutta', '', 0),
(2544, 'saali kutti', '', 0),
(2545, 'saali randi', '', 0),
(2546, 'suar', '', 0),
(2547, 'suar ki aulad', '', 0),
(2548, 'tatte', '', 0),
(2549, 'tatti', '', 0),
(2550, 'teri maa ka bhosada', '', 0),
(2551, 'teri maa ka boba chusu', '', 0),
(2552, 'teri maa ki chut', '', 0),
(2553, 'tharak', '', 0),
(2554, 'tharki', '', 0),
(2555, 'balfasz', '', 0),
(2556, 'balfaszok', '', 0),
(2557, 'balfaszokat', '', 0),
(2558, 'balfaszt', '', 0),
(2559, 'barmok', '', 0),
(2560, 'barmokat', '', 0),
(2561, 'barmot', '', 0),
(2562, 'barom', '', 0),
(2563, 'baszik', '', 0),
(2564, 'bazmeg', '', 0),
(2565, 'buksza', '', 0),
(2566, 'bukszák', '', 0),
(2567, 'bukszákat', '', 0),
(2568, 'bukszát', '', 0),
(2569, 'búr', '', 0),
(2570, 'búrok', '', 0),
(2571, 'csöcs', '', 0),
(2572, 'csöcsök', '', 0),
(2573, 'csöcsöket', '', 0),
(2574, 'csöcsöt', '', 0),
(2575, 'fasz', '', 0),
(2576, 'faszfej', '', 0),
(2577, 'faszfejek', '', 0),
(2578, 'faszfejeket', '', 0),
(2579, 'faszfejet', '', 0),
(2580, 'faszok', '', 0),
(2581, 'faszokat', '', 0),
(2582, 'faszt', '', 0),
(2583, 'fing', '', 0),
(2584, 'fingok', '', 0),
(2585, 'fingokat', '', 0),
(2586, 'fingot', '', 0),
(2587, 'franc', '', 0),
(2588, 'francok', '', 0),
(2589, 'francokat', '', 0),
(2590, 'francot', '', 0),
(2591, 'geci', '', 0),
(2592, 'gecibb', '', 0),
(2593, 'gecik', '', 0),
(2594, 'geciket', '', 0),
(2595, 'gecit', '', 0),
(2596, 'kibaszott', '', 0),
(2597, 'kibaszottabb', '', 0),
(2598, 'kúr', '', 0),
(2599, 'kurafi', '', 0),
(2600, 'kurafik', '', 0),
(2601, 'kurafikat', '', 0),
(2602, 'kurafit', '', 0),
(2603, 'kurvák', '', 0),
(2604, 'kurvákat', '', 0),
(2605, 'kurvát', '', 0),
(2606, 'leggecibb', '', 0),
(2607, 'legkibaszottabb', '', 0),
(2608, 'legszarabb', '', 0),
(2609, 'marha', '', 0),
(2610, 'marhák', '', 0),
(2611, 'marhákat', '', 0),
(2612, 'marhát', '', 0),
(2613, 'megdöglik', '', 0),
(2614, 'pele', '', 0),
(2615, 'pelék', '', 0),
(2616, 'picsa', '', 0),
(2617, 'picsákat', '', 0),
(2618, 'picsát', '', 0),
(2619, 'pina', '', 0),
(2620, 'pinák', '', 0),
(2621, 'pinákat', '', 0),
(2622, 'pinát', '', 0),
(2623, 'pofa', '', 0),
(2624, 'pofákat', '', 0),
(2625, 'pofát', '', 0),
(2626, 'pöcs', '', 0),
(2627, 'pöcsök', '', 0),
(2628, 'pöcsöket', '', 0),
(2629, 'pöcsöt', '', 0),
(2630, 'punci', '', 0),
(2631, 'puncik', '', 0),
(2632, 'segg', '', 0),
(2633, 'seggek', '', 0),
(2634, 'seggeket', '', 0),
(2635, 'segget', '', 0),
(2636, 'seggfej', '', 0),
(2637, 'seggfejek', '', 0),
(2638, 'seggfejeket', '', 0),
(2639, 'seggfejet', '', 0),
(2640, 'szajha', '', 0),
(2641, 'szajhák', '', 0),
(2642, 'szajhákat', '', 0),
(2643, 'szajhát', '', 0),
(2644, 'szar', '', 0),
(2645, 'szarabb', '', 0),
(2646, 'szarik', '', 0),
(2647, 'szarok', '', 0),
(2648, 'szarokat', '', 0),
(2649, 'szart', '', 0),
(2650, 'larte bolognese', '', 0),
(2651, 'アジアのかわいい女の子', '', 0),
(2652, 'アスホール', '', 0),
(2653, 'アナリングス', '', 0),
(2654, 'アナル', '', 0),
(2655, 'いたずら', '', 0),
(2656, 'イラマチオ', '', 0),
(2657, 'ウェブカメラ', '', 0),
(2658, 'エクスタシー', '', 0),
(2659, 'エスコート', '', 0),
(2660, 'エッチ', '', 0),
(2661, 'エロティズム', '', 0),
(2662, 'エロティック', '', 0),
(2663, 'オーガズム', '', 0),
(2664, 'オカマ', '', 0),
(2665, 'おしっこ', '', 0),
(2666, 'おしり', '', 0),
(2667, 'オシリ', '', 0),
(2668, 'おしりのあな', '', 0),
(2669, 'おっぱい', '', 0),
(2670, 'オッパイ', '', 0),
(2671, 'オナニー', '', 0),
(2672, 'オマンコ', '', 0),
(2673, 'おもらし', '', 0),
(2674, 'お尻', '', 0),
(2675, 'カーマスートラ', '', 0),
(2676, 'カント', '', 0),
(2677, 'クリトリス', '', 0),
(2678, 'グループ・セックス', '', 0),
(2679, 'グロ', '', 0),
(2680, 'クンニリングス', '', 0),
(2681, 'ゲイ・セックス', '', 0),
(2682, 'ゲイの男性', '', 0),
(2683, 'ゲイボーイ', '', 0),
(2684, 'ゴールデンシャワー', '', 0),
(2685, 'コカイン', '', 0),
(2686, 'ゴックン', '', 0),
(2687, 'サディズム', '', 0),
(2688, 'しばり', '', 0),
(2689, 'スウィンガー', '', 0),
(2690, 'スカートの中', '', 0),
(2691, 'スカトロ', '', 0),
(2692, 'ストラップオン', '', 0),
(2693, 'ストリップ劇場', '', 0),
(2694, 'スラット', '', 0),
(2695, 'スリット', '', 0),
(2696, 'セクシーな', '', 0),
(2697, 'セクシーな 10 代', '', 0),
(2698, 'セックス', '', 0),
(2699, 'ソドミー', '', 0),
(2700, 'ディープ・スロート', '', 0),
(2701, 'ディック', '', 0),
(2702, 'ディルド', '', 0),
(2703, 'デートレイプ', '', 0),
(2704, 'デブ', '', 0),
(2705, 'テレフォンセックス', '', 0),
(2706, 'ドッグスタイル', '', 0),
(2707, 'トップレス', '', 0),
(2708, 'なめ', '', 0),
(2709, 'ニガー', '', 0),
(2710, 'ヌード', '', 0),
(2711, 'ネオ・ナチ', '', 0),
(2712, 'ハードコア', '', 0),
(2713, 'パイパン', '', 0),
(2714, 'バイブレーター', '', 0),
(2715, 'バック・スタイル', '', 0),
(2716, 'パンティー', '', 0),
(2717, 'ビッチ', '', 0),
(2718, 'ファンタジー', '', 0),
(2719, 'フィスト', '', 0),
(2720, 'フェティッシュ', '', 0),
(2721, 'フェラチオ', '', 0),
(2722, 'ふたなり', '', 0),
(2723, 'ぶっかけ', '', 0),
(2724, 'フック', '', 0),
(2725, 'プリンス アルバート ピアス', '', 0),
(2726, 'プレイボーイ', '', 0),
(2727, 'ベアバック', '', 0),
(2728, 'ペニス', '', 0),
(2729, 'ペニスバンド', '', 0),
(2730, 'ボーイズラブ', '', 0),
(2731, 'ボールギャグ', '', 0),
(2732, 'ボールを蹴る', '', 0),
(2733, 'ぽっちゃり', '', 0),
(2734, 'ホモ', '', 0),
(2735, 'ポルノ', '', 0),
(2736, 'ポルノグラフィー', '', 0),
(2737, 'ボンテージ', '', 0),
(2738, 'マザー・ファッカー', '', 0),
(2739, 'マスターベーション', '', 0),
(2740, 'やおい', '', 0),
(2741, 'ユダヤ人', '', 0),
(2742, 'ラティーナ', '', 0),
(2743, 'ラバー', '', 0),
(2744, 'ランジェリー', '', 0),
(2745, 'レイプ', '', 0),
(2746, 'レズビアン', '', 0),
(2747, 'ローター', '', 0),
(2748, 'ロリータ', '', 0),
(2749, '淫乱', '', 0),
(2750, '陰毛', '', 0),
(2751, '革抑制', '', 0),
(2752, '騎上位', '', 0),
(2753, '巨根', '', 0),
(2754, '巨乳', '', 0),
(2755, '強姦犯', '', 0),
(2756, '玉なめ', '', 0),
(2757, '玉舐め', '', 0),
(2758, '緊縛', '', 0),
(2759, '近親相姦', '', 0),
(2760, '嫌い', '', 0),
(2761, '後背位', '', 0),
(2762, '合意の性交', '', 0),
(2763, '拷問', '', 0),
(2764, '黒人', '', 0),
(2765, '殺し方', '', 0),
(2766, '殺人事件', '', 0),
(2767, '殺人方法', '', 0),
(2768, '支配', '', 0),
(2769, '児童性虐待', '', 0),
(2770, '自己愛性', '', 0),
(2771, '射精', '', 0),
(2772, '手コキ', '', 0),
(2773, '獣姦', '', 0),
(2774, '女の子', '', 0),
(2775, '女王様', '', 0),
(2776, '女子高生', '', 0),
(2777, '女装', '', 0),
(2778, '新しいポルノ', '', 0),
(2779, '人妻', '', 0),
(2780, '人種', '', 0),
(2781, '性交', '', 0),
(2782, '正常位', '', 0),
(2783, '生殖器', '', 0),
(2784, '精液', '', 0),
(2785, '挿入', '', 0),
(2786, '足フェチ', '', 0),
(2787, '足を広げる', '', 0),
(2788, '大陰唇', '', 0),
(2789, '脱衣', '', 0),
(2790, '茶色のシャワー', '', 0),
(2791, '中出し', '', 0),
(2792, '潮吹き女', '', 0),
(2793, '潮吹き男性', '', 0),
(2794, '直腸', '', 0),
(2795, '剃毛', '', 0),
(2796, '貞操帯', '', 0),
(2797, '奴隷', '', 0),
(2798, '二穴', '', 0),
(2799, '乳首', '', 0),
(2800, '尿道プレイ', '', 0),
(2801, '覗き', '', 0),
(2802, '売春婦', '', 0),
(2803, '縛り', '', 0),
(2804, '噴出', '', 0),
(2805, '糞', '', 0),
(2806, '糞尿愛好症', '', 0),
(2807, '糞便', '', 0),
(2808, '平手打ち', '', 0),
(2809, '変態', '', 0),
(2810, '勃起する', '', 0),
(2811, '夢精', '', 0),
(2812, '毛深い', '', 0),
(2813, '誘惑', '', 0),
(2814, '幼児', '', 0),
(2815, '幼児性愛者', '', 0),
(2816, '裸', '', 0),
(2817, '裸の女性', '', 0),
(2818, '乱交', '', 0),
(2819, '両性', '', 0),
(2820, '両性具有', '', 0),
(2821, '両刀', '', 0),
(2822, '輪姦', '', 0),
(2823, '卍', '', 0),
(2824, '宦官', '', 0),
(2825, '肛門', '', 0),
(2826, '膣', '', 0),
(2827, '개자식', '', 0),
(2828, '개좆', '', 0),
(2829, '개차반', '', 0),
(2830, '거유', '', 0),
(2831, '계집년', '', 0),
(2832, '고자', '', 0),
(2833, '근친', '', 0),
(2834, '노모', '', 0),
(2835, '니기미', '', 0),
(2836, '뒤질래', '', 0),
(2837, '때씹', '', 0),
(2838, '또라이', '', 0),
(2839, '뙤놈', '', 0),
(2840, '로리타', '', 0),
(2841, '망가', '', 0),
(2842, '몰카', '', 0),
(2843, '미친', '', 0),
(2844, '미친새끼', '', 0),
(2845, '바바리맨', '', 0),
(2846, '변태', '', 0),
(2847, '스와핑', '', 0),
(2848, '씨팔', '', 0),
(2849, '씹', '', 0),
(2850, '씹물', '', 0),
(2851, '씹빨', '', 0),
(2852, '씹알', '', 0),
(2853, '씹창', '', 0),
(2854, '씹팔', '', 0),
(2855, '암캐', '', 0),
(2856, '애자', '', 0),
(2857, '야동', '', 0),
(2858, '야사', '', 0),
(2859, '야애니', '', 0),
(2860, '엄창', '', 0),
(2861, '에로', '', 0),
(2862, '옘병', '', 0),
(2863, '유모', '', 0),
(2864, '육갑', '', 0),
(2865, '은꼴', '', 0),
(2866, '자위', '', 0),
(2867, '잡년', '', 0),
(2868, '종간나', '', 0),
(2869, '좆', '', 0),
(2870, '좆만', '', 0),
(2871, '죽일년', '', 0),
(2872, '쥐좆', '', 0),
(2873, '직촬', '', 0),
(2874, '짱깨', '', 0),
(2875, '쪽바리', '', 0),
(2876, '포르노', '', 0),
(2877, '하드코어', '', 0),
(2878, '호로', '', 0),
(2879, '화냥년', '', 0),
(2880, '후레아들', '', 0),
(2881, '희쭈그리', '', 0),
(2882, 'aardappels afgieteng', '', 0),
(2883, 'achter het raam zitten', '', 0),
(2884, 'afberen', '', 0),
(2885, 'aflebberen', '', 0),
(2886, 'afrossen', '', 0),
(2887, 'afrukken', '', 0),
(2888, 'aftrekken', '', 0),
(2889, 'afwerkplaats', '', 0),
(2890, 'afzeiken', '', 0),
(2891, 'afzuigen', '', 0),
(2892, 'anderhalve man en een paardekop', '', 0),
(2893, 'anita', '', 0),
(2894, 'asbak', '', 0),
(2895, 'aso', '', 0),
(2896, 'bagger schijten', '', 0),
(2897, 'balen', '', 0),
(2898, 'bedonderen', '', 0),
(2899, 'befborstelg', '', 0),
(2900, 'beffen', '', 0),
(2901, 'bekken', '', 0),
(2902, 'belazeren', '', 0),
(2903, 'besodemieterd zijn', '', 0),
(2904, 'besodemieteren', '', 0),
(2905, 'beurt', '', 0),
(2906, 'boemelen', '', 0),
(2907, 'boerelul', '', 0),
(2908, 'boerenpummelg', '', 0),
(2909, 'bokkelul', '', 0),
(2910, 'botergeil', '', 0),
(2911, 'broekhoesten', '', 0),
(2912, 'brugpieperg', '', 0),
(2913, 'buffelen', '', 0),
(2914, 'buiten de pot piesen', '', 0),
(2915, 'das kloten van de bok', '', 0),
(2916, 'de ballen', '', 0),
(2917, 'de hoer spelen', '', 0),
(2918, 'de hond uitlaten', '', 0),
(2919, 'de koffer induiken', '', 0),
(2920, 'delg', '', 0),
(2921, 'de pijp aan maarten geven', '', 0),
(2922, 'de pijp uitgaan', '', 0),
(2923, 'dombo', '', 0),
(2924, 'draaikontg', '', 0),
(2925, 'driehoog achter wonen', '', 0),
(2926, 'drolg', '', 0),
(2927, 'drooggeiler', '', 0),
(2928, 'droogkloot', '', 0),
(2929, 'een beurt geven', '', 0),
(2930, 'een nummertje maken', '', 0),
(2931, 'een wip maken', '', 0),
(2932, 'eikel', '', 0),
(2933, 'engerd', '', 0),
(2934, 'flamoes', '', 0),
(2935, 'flikken', '', 0),
(2936, 'gadverdamme', '', 0),
(2937, 'galbak', '', 0),
(2938, 'gat', '', 0),
(2939, 'gedoogzone', '', 0),
(2940, 'geilneef', '', 0),
(2941, 'gesodemieter', '', 0),
(2942, 'godverdomme', '', 0),
(2943, 'graftak', '', 0),
(2944, 'gras maaien', '', 0),
(2945, 'gratenkutg', '', 0),
(2946, 'greppeldel', '', 0),
(2947, 'griet', '', 0),
(2948, 'hoempert', '', 0),
(2949, 'hoerenbuurt', '', 0),
(2950, 'hoerenloper', '', 0),
(2951, 'hoerig', '', 0),
(2952, 'hol', '', 0),
(2953, 'hufter', '', 0),
(2954, 'huisdealer', '', 0),
(2955, 'johny', '', 0),
(2956, 'kanen', '', 0),
(2957, 'kettingzeugg', '', 0),
(2958, 'klaarkomen', '', 0),
(2959, 'klerebeer', '', 0),
(2960, 'klooien', '', 0),
(2961, 'klootjesvolk', '', 0),
(2962, 'klootoog', '', 0),
(2963, 'kloten', '', 0),
(2964, 'knor', '', 0),
(2965, 'kontg', '', 0),
(2966, 'kontneuken', '', 0),
(2967, 'krentekakker', '', 0),
(2968, 'kuttelikkertje', '', 0),
(2969, 'kwakkieg', '', 0),
(2970, 'liefdesgrot', '', 0),
(2971, 'lul-de-behanger', '', 0),
(2972, 'lummel', '', 0),
(2973, 'mafketel', '', 0),
(2974, 'matennaaierg', '', 0),
(2975, 'matje', '', 0),
(2976, 'mutsg', '', 0),
(2977, 'naaien', '', 0),
(2978, 'naakt', '', 0),
(2979, 'neukstier', '', 0),
(2980, 'nicht', '', 0),
(2981, 'oetlul', '', 0),
(2982, 'opgeilen', '', 0),
(2983, 'opkankeren', '', 0),
(2984, 'oprotten', '', 0),
(2985, 'opsodemieteren', '', 0),
(2986, 'op z\n hondjes', '', 0),
(2987, 'op z\n sodemieter geven', '', 0),
(2988, 'opzouten', '', 0),
(2989, 'ouwehoer', '', 0),
(2990, 'ouwe rukker', '', 0),
(2991, 'paal', '', 0),
(2992, 'palen', '', 0),
(2993, 'penozeg', '', 0),
(2994, 'piesen', '', 0),
(2995, 'pijpbekkieg', '', 0),
(2996, 'pijpen', '', 0),
(2997, 'pleurislaaier', '', 0),
(2998, 'poot', '', 0),
(2999, 'portiekslet', '', 0),
(3000, 'pot', '', 0),
(3001, 'potverdorie', '', 0),
(3002, 'publiciteitsgeil', '', 0),
(3003, 'raaskallen', '', 0),
(3004, 'reet', '', 0),
(3005, 'reetridder', '', 0),
(3006, 'reet trappen, voor zijn', '', 0),
(3007, 'remsporeng', '', 0),
(3008, 'reutelen', '', 0),
(3009, 'rothoer', '', 0),
(3010, 'rukhond', '', 0),
(3011, 'rukken', '', 0),
(3012, 'schatje', '', 0),
(3013, 'schijt', '', 0),
(3014, 'schijten', '', 0),
(3015, 'schoft', '', 0),
(3016, 'schuinsmarcheerder', '', 0),
(3017, 'slempen', '', 0),
(3018, 'sletg', '', 0),
(3019, 'sletterig', '', 0),
(3020, 'slik mijn zaad', '', 0),
(3021, 'snolg', '', 0),
(3022, 'spuiten', '', 0),
(3023, 'standje', '', 0),
(3024, 'standje-69g', '', 0),
(3025, 'stootje', '', 0),
(3026, 'strontg', '', 0),
(3027, 'sufferdg', '', 0),
(3028, 'tapijtnek', '', 0),
(3029, 'teefg', '', 0),
(3030, 'temeier', '', 0),
(3031, 'teringlijer', '', 0),
(3032, 'toeter', '', 0),
(3033, 'tongzoeng', '', 0),
(3034, 'triootjeg', '', 0),
(3035, 'trottoir prostituée', '', 0),
(3036, 'trottoirteef', '', 0),
(3037, 'utrecht', '', 0),
(3038, 'vergallen', '', 0),
(3039, 'verkloten', '', 0),
(3040, 'verneuken', '', 0),
(3041, 'viespeuk', '', 0),
(3042, 'vingeren', '', 0),
(3043, 'vleesroos', '', 0),
(3044, 'voor jan lul', '', 0),
(3045, 'voor jan-met-de-korte-achternaam', '', 0),
(3046, 'watje', '', 0),
(3047, 'welzijnsmafia', '', 0),
(3048, 'wijf', '', 0),
(3049, 'wippen', '', 0),
(3050, 'wuftje', '', 0),
(3051, 'zaadje', '', 0),
(3052, 'zakkenwasser', '', 0),
(3053, 'zeiken', '', 0),
(3054, 'zeiker', '', 0),
(3055, 'zuigen', '', 0),
(3056, 'zuiplap', '', 0),
(3057, 'faen i helvete', '', 0),
(3058, 'fitte', '', 0),
(3059, 'kukene', '', 0),
(3060, 'kuker', '', 0),
(3061, 'pikk', '', 0),
(3062, 'sotrør', '', 0),
(3063, 'ståpikk', '', 0),
(3064, 'ståpikkene', '', 0),
(3065, 'ståpikker', '', 0),
(3066, 'burdel', '', 0),
(3067, 'burdelmama', '', 0),
(3068, 'chujnia', '', 0),
(3069, 'ciota', '', 0),
(3070, 'cyc', '', 0),
(3071, 'dmuchać', '', 0),
(3072, 'do kurwy nędzy', '', 0),
(3073, 'dupek', '', 0),
(3074, 'duperele', '', 0),
(3075, 'fiut', '', 0),
(3076, 'gówno', '', 0),
(3077, 'gówno prawda', '', 0),
(3078, 'huj', '', 0),
(3079, 'jajco', '', 0),
(3080, 'jajeczko', '', 0),
(3081, 'jajko', '', 0),
(3082, 'jajo', '', 0),
(3083, 'ja pierdolę', '', 0),
(3084, 'jebać', '', 0),
(3085, 'jebany', '', 0),
(3086, 'kurwy', '', 0),
(3087, 'kutafon', '', 0),
(3088, 'kutas', '', 0),
(3089, 'lizać pałę', '', 0),
(3090, 'obciągać chuja', '', 0),
(3091, 'obciągać fiuta', '', 0),
(3092, 'obciągać loda', '', 0),
(3093, 'pieprzyć', '', 0),
(3094, 'pierdolec', '', 0),
(3095, 'pierdolić', '', 0),
(3096, 'pierdolnięty', '', 0),
(3097, 'pierdoła', '', 0),
(3098, 'pierdzieć', '', 0),
(3099, 'pojeb', '', 0),
(3100, 'popierdolony', '', 0),
(3101, 'robic loda', '', 0),
(3102, 'robić loda', '', 0),
(3103, 'ruchać', '', 0),
(3104, 'rzygać', '', 0),
(3105, 'sraczka', '', 0),
(3106, 'srać', '', 0),
(3107, 'syf', '', 0),
(3108, 'wkurwiać', '', 0),
(3109, 'zajebisty', '', 0),
(3110, 'aborto', '', 0),
(3111, 'amador', '', 0),
(3112, 'ânus', '', 0),
(3113, 'aranha', '', 0),
(3114, 'ariano', '', 0),
(3115, 'balalao', '', 0),
(3116, 'bicha', '', 0),
(3117, 'biscate', '', 0),
(3118, 'bissexual', '', 0),
(3119, 'boceta', '', 0),
(3120, 'bosta', '', 0),
(3121, 'braulio de borracha', '', 0),
(3122, 'bumbum', '', 0),
(3123, 'burro', '', 0),
(3124, 'cabrao', '', 0),
(3125, 'cacete', '', 0),
(3126, 'cagar', '', 0),
(3127, 'camisinha', '', 0),
(3128, 'caralho', '', 0),
(3129, 'cerveja', '', 0),
(3130, 'chochota', '', 0),
(3131, 'chupar', '', 0),
(3132, 'cocaína', '', 0),
(3133, 'colhoes', '', 0),
(3134, 'comer', '', 0),
(3135, 'cona', '', 0),
(3136, 'consolo', '', 0),
(3137, 'corno', '', 0),
(3138, 'cu', '', 0),
(3139, 'dar o rabo', '', 0),
(3140, 'dum raio', '', 0),
(3141, 'esporra', '', 0),
(3142, 'filho da puta', '', 0),
(3143, 'foda', '', 0),
(3144, 'foda-se', '', 0),
(3145, 'foder', '', 0),
(3146, 'frango assado', '', 0),
(3147, 'gozar', '', 0),
(3148, 'grelho', '', 0),
(3149, 'heroína', '', 0),
(3150, 'heterosexual', '', 0),
(3151, 'homem gay', '', 0),
(3152, 'homoerótico', '', 0),
(3153, 'homosexual', '', 0),
(3154, 'inferno', '', 0),
(3155, 'lésbica', '', 0),
(3156, 'mama', '', 0),
(3157, 'paneleiro', '', 0),
(3158, 'passar um cheque', '', 0),
(3159, 'pau', '', 0),
(3160, 'peidar', '', 0),
(3161, 'pênis', '', 0),
(3162, 'pinto', '', 0),
(3163, 'porra', '', 0),
(3164, 'puta que pariu', '', 0),
(3165, 'puta que te pariu', '', 0),
(3166, 'queca', '', 0),
(3167, 'sacanagem', '', 0),
(3168, 'saco', '', 0),
(3169, 'torneira', '', 0),
(3170, 'transar', '', 0),
(3171, 'vai-te foder', '', 0),
(3172, 'vai tomar no cu', '', 0),
(3173, 'veado', '', 0),
(3174, 'vibrador', '', 0),
(3175, 'xana', '', 0),
(3176, 'xochota', '', 0),
(3177, 'bychara', '', 0),
(3178, 'byk', '', 0),
(3179, 'chernozhopyi', '', 0),
(3180, 'dolboyeb', '', 0),
(3181, 'ebalnik', '', 0),
(3182, 'ebalo', '', 0),
(3183, 'ebalom schelkat', '', 0),
(3184, 'gol', '', 0),
(3185, 'mudack', '', 0),
(3186, 'opizdenet', '', 0),
(3187, 'ostoeblo', '', 0),
(3188, 'ostokhuitel\no', '', 0),
(3189, 'otebis', '', 0),
(3190, 'otmudohat', '', 0),
(3191, 'otpizdit', '', 0),
(3192, 'otsosi', '', 0),
(3193, 'padlo', '', 0),
(3194, 'pedik', '', 0),
(3195, 'perdet', '', 0),
(3196, 'petuh', '', 0),
(3197, 'pidar gnoinyj', '', 0),
(3198, 'pizdato', '', 0),
(3199, 'pizdatyi', '', 0),
(3200, 'pizdet', '', 0),
(3201, 'pizdetc', '', 0),
(3202, 'pizdoi nakrytsja', '', 0),
(3203, 'pizduk', '', 0),
(3204, 'piz`dyulina', '', 0),
(3205, 'podi kuevo', '', 0),
(3206, 'poeben', '', 0),
(3207, 'poimat na konchik', '', 0),
(3208, 'poiti posrat', '', 0),
(3209, 'po khuy', '', 0),
(3210, 'poluchit pizdy', '', 0),
(3211, 'pososi moyu konfetku', '', 0),
(3212, 'prissat', '', 0),
(3213, 'proebat', '', 0),
(3214, 'promudobladsksya pizdoproebina', '', 0),
(3215, 'propezdoloch', '', 0),
(3216, 'prosrat', '', 0),
(3217, 'raspeezdeyi', '', 0),
(3218, 'raspizdatyi', '', 0),
(3219, 'razyebuy', '', 0),
(3220, 'razyoba', '', 0),
(3221, 'sebatsya', '', 0),
(3222, 'shalava', '', 0),
(3223, 'styervo', '', 0),
(3224, 'sukin syn', '', 0),
(3225, 'svodit posrat', '', 0),
(3226, 'svoloch', '', 0),
(3227, 'trakhatsya', '', 0),
(3228, 'trimandoblydskiy pizdoproyob', '', 0),
(3229, 'ublyudok', '', 0),
(3230, 'uboy', '', 0),
(3231, 'uebitsche', '', 0),
(3232, 'vafla', '', 0),
(3233, 'vafli lovit', '', 0),
(3234, 'v pizdu', '', 0),
(3235, 'vyperdysh', '', 0),
(3236, 'vzdrochennyi', '', 0),
(3237, 'yeb vas', '', 0),
(3238, 'zaebat', '', 0),
(3239, 'zaebis', '', 0),
(3240, 'zalupa', '', 0),
(3241, 'zalupat', '', 0),
(3242, 'zasranetc', '', 0),
(3243, 'zassat', '', 0),
(3244, 'zloebuchy', '', 0),
(3245, 'бардак', '', 0),
(3246, 'бздёнок', '', 0),
(3247, 'блядки', '', 0),
(3248, 'блядовать', '', 0),
(3249, 'блядство', '', 0),
(3250, 'блядь', '', 0),
(3251, 'бугор', '', 0),
(3252, 'во пизду', '', 0),
(3253, 'встать раком', '', 0),
(3254, 'выёбываться', '', 0),
(3255, 'гандон', '', 0),
(3256, 'говно', '', 0),
(3257, 'говнюк', '', 0),
(3258, 'голый', '', 0),
(3259, 'дать пизды', '', 0),
(3260, 'дерьмо', '', 0),
(3261, 'дрочить', '', 0),
(3262, 'другой дразнится', '', 0),
(3263, 'ёбарь', '', 0),
(3264, 'ебать', '', 0),
(3265, 'ебать-копать', '', 0),
(3266, 'ебло', '', 0),
(3267, 'ебнуть', '', 0),
(3268, 'ёб твою мать', '', 0),
(3269, 'жопа', '', 0),
(3270, 'жополиз', '', 0),
(3271, 'играть на кожаной флейте', '', 0),
(3272, 'измудохать', '', 0),
(3273, 'каждый дрочит как он хочет', '', 0),
(3274, 'какая разница', '', 0),
(3275, 'как два пальца обоссать', '', 0),
(3276, 'курите мою трубку', '', 0),
(3277, 'лысого в кулаке гонять', '', 0),
(3278, 'малофя', '', 0),
(3279, 'манда', '', 0),
(3280, 'мандавошка', '', 0),
(3281, 'мент', '', 0),
(3282, 'муда', '', 0),
(3283, 'мудило', '', 0),
(3284, 'мудозмон', '', 0),
(3285, 'наебать', '', 0),
(3286, 'Пиздец', '', 0),
(3287, 'наебениться', '', 0),
(3288, 'Долбоёб', '', 0),
(3289, 'наебнуться', '', 0),
(3290, 'на фиг', '', 0),
(3291, 'на хуй', '', 0),
(3292, 'на хую вертеть', '', 0),
(3293, 'Очко', '', 0),
(3294, 'Минет', '', 0),
(3295, 'на хуя', '', 0),
(3296, 'Сука', '', 0),
(3297, 'Хуйня', '', 0),
(3298, 'Анал', '', 0),
(3299, 'Лох', '', 0),
(3300, 'Свиноёб', '', 0),
(3301, 'нахуячиться', '', 0),
(3302, 'невебенный', '', 0),
(3303, 'не ебет', '', 0),
(3304, 'ни за хуй собачу', '', 0),
(3305, 'ни хуя', '', 0),
(3306, 'обнаженный', '', 0),
(3307, 'обоссаться можно', '', 0),
(3308, 'один ебётся', '', 0),
(3309, 'опесдол', '', 0),
(3310, 'офигеть', '', 0),
(3311, 'охуеть', '', 0),
(3312, 'охуйтельно', '', 0),
(3313, 'половое сношение', '', 0),
(3314, 'секс', '', 0),
(3315, 'сиски', '', 0),
(3316, 'спиздить', '', 0),
(3317, 'срать', '', 0),
(3318, 'ссать', '', 0),
(3319, 'траxать', '', 0),
(3320, 'ты мне ваньку не валяй', '', 0),
(3321, 'фига', '', 0),
(3322, 'хапать', '', 0),
(3323, 'хер с ней', '', 0),
(3324, 'хер с ним', '', 0),
(3325, 'хохол', '', 0),
(3326, 'хрен', '', 0),
(3327, 'хуёво', '', 0),
(3328, 'хуёвый', '', 0),
(3329, 'хуем груши околачивать', '', 0),
(3330, 'хуеплет', '', 0),
(3331, 'хуило', '', 0),
(3332, 'хуиней страдать', '', 0),
(3333, 'хуиня', '', 0),
(3334, 'хуй', '', 0),
(3335, 'хуйнуть', '', 0),
(3336, 'хуй пинать', '', 0),
(3337, 'Пизда', '', 0),
(3338, 'Пидарас', '', 0),
(3339, 'arsle', '', 0),
(3340, 'brutta', '', 0),
(3341, 'discofitta', '', 0),
(3342, 'dra åt helvete', '', 0),
(3343, 'fan', '', 0),
(3344, 'fitta', '', 0),
(3345, 'fittig', '', 0),
(3346, 'för helvete', '', 0),
(3347, 'hård', '', 0),
(3348, 'jävlar', '', 0),
(3349, 'knulla', '', 0),
(3350, 'kuksås', '', 0),
(3351, 'kötthuvud', '', 0),
(3352, 'köttnacke', '', 0),
(3353, 'moona', '', 0),
(3354, 'moonade', '', 0),
(3355, 'moonar', '', 0),
(3356, 'moonat', '', 0),
(3357, 'mutta', '', 0),
(3358, 'olla', '', 0),
(3359, 'pippa', '', 0),
(3360, 'pitt', '', 0),
(3361, 'prutt', '', 0),
(3362, 'pök', '', 0),
(3363, 'runka', '', 0),
(3364, 'röv', '', 0),
(3365, 'rövhål', '', 0),
(3366, 'rövknulla', '', 0),
(3367, 'skita', '', 0),
(3368, 'skit ner dig', '', 0),
(3369, 'skäggbiff', '', 0),
(3370, 'snedfitta', '', 0),
(3371, 'snefitta', '', 0),
(3372, 'stake', '', 0),
(3373, 'subba', '', 0),
(3374, 'sås', '', 0),
(3375, 'sätta på', '', 0),
(3376, 'tusan', '', 0),
(3377, 'กระดอ', '', 0),
(3378, 'กระเด้า', '', 0),
(3379, 'กระหรี่', '', 0),
(3380, 'กะปิ', '', 0),
(3381, 'กู', '', 0),
(3382, 'ขี้', '', 0),
(3383, 'ควย', '', 0),
(3384, 'จิ๋ม', '', 0),
(3385, 'จู๋', '', 0),
(3386, 'เจ๊ก', '', 0),
(3387, 'เจี๊ยว', '', 0),
(3388, 'ดอกทอง', '', 0),
(3389, 'ตอแหล', '', 0),
(3390, 'ตูด', '', 0),
(3391, 'น้ําแตก', '', 0),
(3392, 'มึง', '', 0),
(3393, 'แม่ง', '', 0),
(3394, 'เย็ด', '', 0),
(3395, 'รูตูด', '', 0),
(3396, 'ล้างตู้เย็น', '', 0),
(3397, 'ส้นตีน', '', 0),
(3398, 'สัด', '', 0),
(3399, 'เสือก', '', 0),
(3400, 'หญิงชาติชั่ว', '', 0),
(3401, 'หลั่ง', '', 0),
(3402, 'ห่า', '', 0),
(3403, 'หํา', '', 0),
(3404, 'หี', '', 0),
(3405, 'เหี้ย', '', 0),
(3406, 'อมนกเขา', '', 0),
(3407, 'ไอ้ควาย', '', 0),
(3408, 'amcığa', '', 0),
(3409, 'amcığı', '', 0),
(3410, 'amcığın', '', 0),
(3411, 'amcık', '', 0),
(3412, 'amcıklar', '', 0),
(3413, 'amcıklara', '', 0),
(3414, 'amcıklarda', '', 0),
(3415, 'amcıklardan', '', 0),
(3416, 'amcıkları', '', 0),
(3417, 'amcıkların', '', 0),
(3418, 'amcıkta', '', 0),
(3419, 'amcıktan', '', 0),
(3420, 'amı', '', 0),
(3421, 'amlar', '', 0),
(3422, 'çingene', '', 0),
(3423, 'Çingenede', '', 0),
(3424, 'Çingeneden', '', 0),
(3425, 'Çingeneler', '', 0),
(3426, 'Çingenelerde', '', 0),
(3427, 'Çingenelerden', '', 0),
(3428, 'Çingenelere', '', 0),
(3429, 'Çingeneleri', '', 0),
(3430, 'Çingenelerin', '', 0),
(3431, 'Çingenenin', '', 0),
(3432, 'Çingeneye', '', 0),
(3433, 'Çingeneyi', '', 0),
(3434, 'göt', '', 0),
(3435, 'göte', '', 0),
(3436, 'götler', '', 0),
(3437, 'götlerde', '', 0),
(3438, 'götlerden', '', 0),
(3439, 'götlere', '', 0),
(3440, 'götleri', '', 0),
(3441, 'götlerin', '', 0),
(3442, 'götte', '', 0),
(3443, 'götten', '', 0),
(3444, 'götü', '', 0),
(3445, 'götün', '', 0),
(3446, 'götveren', '', 0),
(3447, 'götverende', '', 0),
(3448, 'götverenden', '', 0),
(3449, 'götverene', '', 0),
(3450, 'götvereni', '', 0),
(3451, 'götverenin', '', 0),
(3452, 'götverenler', '', 0),
(3453, 'götverenlerde', '', 0),
(3454, 'götverenlerden', '', 0),
(3455, 'götverenlere', '', 0),
(3456, 'götverenleri', '', 0),
(3457, 'götverenlerin', '', 0),
(3458, 'kaltağa', '', 0),
(3459, 'kaltağı', '', 0),
(3460, 'kaltağın', '', 0),
(3461, 'kaltak', '', 0),
(3462, 'kaltaklar', '', 0),
(3463, 'kaltaklara', '', 0),
(3464, 'kaltaklarda', '', 0),
(3465, 'kaltaklardan', '', 0),
(3466, 'kaltakları', '', 0),
(3467, 'kaltakların', '', 0),
(3468, 'kaltakta', '', 0),
(3469, 'kaltaktan', '', 0),
(3470, 'orospuda', '', 0),
(3471, 'orospudan', '', 0),
(3472, 'orospular', '', 0),
(3473, 'orospulara', '', 0),
(3474, 'orospularda', '', 0),
(3475, 'orospulardan', '', 0),
(3476, 'orospuları', '', 0),
(3477, 'orospuların', '', 0),
(3478, 'orospunun', '', 0),
(3479, 'orospuya', '', 0),
(3480, 'orospuyu', '', 0),
(3481, 'otuz birci', '', 0),
(3482, 'otuz bircide', '', 0),
(3483, 'otuz birciden', '', 0),
(3484, 'otuz birciler', '', 0),
(3485, 'otuz bircilerde', '', 0),
(3486, 'otuz bircilerden', '', 0),
(3487, 'otuz bircilere', '', 0),
(3488, 'otuz bircileri', '', 0),
(3489, 'otuz bircilerin', '', 0),
(3490, 'otuz bircinin', '', 0),
(3491, 'otuz birciye', '', 0),
(3492, 'otuz birciyi', '', 0),
(3493, 'saksocu', '', 0),
(3494, 'saksocuda', '', 0),
(3495, 'saksocudan', '', 0),
(3496, 'saksocular', '', 0),
(3497, 'saksoculara', '', 0),
(3498, 'saksocularda', '', 0),
(3499, 'saksoculardan', '', 0),
(3500, 'saksocuları', '', 0),
(3501, 'saksocuların', '', 0),
(3502, 'saksocunun', '', 0),
(3503, 'saksocuya', '', 0),
(3504, 'saksocuyu', '', 0),
(3505, 'sıçmak', '', 0),
(3506, 'sik', '', 0),
(3507, 'sike', '', 0),
(3508, 'siker sikmez', '', 0),
(3509, 'siki', '', 0),
(3510, 'sikilir sikilmez', '', 0),
(3511, 'sikin', '', 0),
(3512, 'sikler', '', 0),
(3513, 'siklerde', '', 0),
(3514, 'siklerden', '', 0),
(3515, 'siklere', '', 0),
(3516, 'sikleri', '', 0),
(3517, 'siklerin', '', 0),
(3518, 'sikmek', '', 0),
(3519, 'sikmemek', '', 0),
(3520, 'sikte', '', 0),
(3521, 'sikten', '', 0),
(3522, 'siktir', '', 0),
(3523, 'siktirir siktirmez', '', 0),
(3524, 'taşağa', '', 0),
(3525, 'taşağı', '', 0),
(3526, 'taşağın', '', 0),
(3527, 'taşak', '', 0),
(3528, 'taşaklar', '', 0),
(3529, 'taşaklara', '', 0),
(3530, 'taşaklarda', '', 0),
(3531, 'taşaklardan', '', 0),
(3532, 'taşakları', '', 0),
(3533, 'taşakların', '', 0),
(3534, 'taşakta', '', 0),
(3535, 'taşaktan', '', 0),
(3536, 'yarağa', '', 0),
(3537, 'yarağı', '', 0),
(3538, 'yarağın', '', 0),
(3539, 'yarak', '', 0),
(3540, 'yaraklar', '', 0),
(3541, 'yaraklara', '', 0),
(3542, 'yaraklarda', '', 0),
(3543, 'yaraklardan', '', 0),
(3544, 'yarakları', '', 0),
(3545, 'yarakların', '', 0),
(3546, 'yarakta', '', 0),
(3547, 'yaraktan', '', 0),
(3548, '13点', '', 0),
(3549, '三级片', '', 0),
(3550, '下三烂', '', 0),
(3551, '下贱', '', 0),
(3552, '个老子的', '', 0),
(3553, '九游', '', 0),
(3554, '乳', '', 0),
(3555, '乳交', '', 0),
(3556, '乳头', '', 0),
(3557, '乳房', '', 0),
(3558, '乳波臀浪', '', 0),
(3559, '交配', '', 0),
(3560, '仆街', '', 0),
(3561, '他奶奶', '', 0),
(3562, '他奶奶的', '', 0),
(3563, '他奶娘的', '', 0),
(3564, '他妈', '', 0),
(3565, '他妈ㄉ王八蛋', '', 0),
(3566, '他妈地', '', 0),
(3567, '他妈的', '', 0),
(3568, '他娘', '', 0),
(3569, '他马的', '', 0),
(3570, '你个傻比', '', 0),
(3571, '你他马的', '', 0),
(3572, '你全家', '', 0),
(3573, '你奶奶的', '', 0),
(3574, '你她马的', '', 0),
(3575, '你妈', '', 0),
(3576, '你妈的', '', 0),
(3577, '你娘', '', 0),
(3578, '你娘卡好', '', 0),
(3579, '你娘咧', '', 0),
(3580, '你它妈的', '', 0),
(3581, '你它马的', '', 0),
(3582, '你是鸡', '', 0),
(3583, '你是鸭', '', 0),
(3584, '你马的', '', 0),
(3585, '做爱', '', 0),
(3586, '傻比', '', 0),
(3587, '傻逼', '', 0),
(3588, '册那', '', 0),
(3589, '军妓', '', 0),
(3590, '几八', '', 0),
(3591, '几叭', '', 0),
(3592, '几巴', '', 0),
(3593, '几芭', '', 0),
(3594, '刚度', '', 0),
(3595, '刚瘪三', '', 0),
(3596, '包皮', '', 0),
(3597, '十三点', '', 0),
(3598, '卖B', '', 0),
(3599, '卖比', '', 0),
(3600, '卖淫', '', 0),
(3601, '卵', '', 0),
(3602, '卵子', '', 0),
(3603, '双峰微颤', '', 0),
(3604, '口交', '', 0),
(3605, '口肯', '', 0),
(3606, '叫床', '', 0),
(3607, '吃屎', '', 0),
(3608, '后庭', '', 0),
(3609, '吹箫', '', 0),
(3610, '塞你公', '', 0),
(3611, '塞你娘', '', 0),
(3612, '塞你母', '', 0),
(3613, '塞你爸', '', 0),
(3614, '塞你老师', '', 0),
(3615, '塞你老母', '', 0),
(3616, '处女', '', 0),
(3617, '外阴', '', 0),
(3618, '大卵子', '', 0),
(3619, '大卵泡', '', 0),
(3620, '大鸡巴', '', 0),
(3621, '奶', '', 0),
(3622, '奶奶的熊', '', 0),
(3623, '奶子', '', 0),
(3624, '奸', '', 0),
(3625, '奸你', '', 0),
(3626, '她妈地', '', 0),
(3627, '她妈的', '', 0),
(3628, '她马的', '', 0),
(3629, '妈B', '', 0),
(3630, '妈个B', '', 0),
(3631, '妈个比', '', 0),
(3632, '妈个老比', '', 0),
(3633, '妈妈的', '', 0),
(3634, '妈比', '', 0),
(3635, '妈的', '', 0),
(3636, '妈的B', '', 0),
(3637, '妈逼', '', 0),
(3638, '妓', '', 0),
(3639, '妓女', '', 0),
(3640, '妓院', '', 0),
(3641, '妳她妈的', '', 0),
(3642, '妳妈的', '', 0),
(3643, '妳娘的', '', 0),
(3644, '妳老母的', '', 0),
(3645, '妳马的', '', 0),
(3646, '姘头', '', 0),
(3647, '姣西', '', 0),
(3648, '姦', '', 0),
(3649, '娘个比', '', 0),
(3650, '娘的', '', 0),
(3651, '婊子', '', 0),
(3652, '婊子养的', '', 0),
(3653, '嫖娼', '', 0),
(3654, '嫖客', '', 0),
(3655, '它妈地', '', 0),
(3656, '它妈的', '', 0),
(3657, '密洞', '', 0),
(3658, '射你', '', 0),
(3659, '小乳头', '', 0),
(3660, '小卵子', '', 0),
(3661, '小卵泡', '', 0),
(3662, '小瘪三', '', 0),
(3663, '小肉粒', '', 0),
(3664, '小骚比', '', 0),
(3665, '小骚货', '', 0),
(3666, '小鸡巴', '', 0),
(3667, '小鸡鸡', '', 0),
(3668, '屁眼', '', 0),
(3669, '屁股', '', 0),
(3670, '屄', '', 0),
(3671, '屌', '', 0),
(3672, '干x娘', '', 0),
(3673, '干七八', '', 0),
(3674, '干你', '', 0),
(3675, '干你妈', '', 0),
(3676, '干你娘', '', 0),
(3677, '干你老母', '', 0),
(3678, '干你良', '', 0),
(3679, '干妳妈', '', 0),
(3680, '干妳娘', '', 0),
(3681, '干妳老母', '', 0),
(3682, '干妳马', '', 0),
(3683, '干您娘', '', 0),
(3684, '干机掰', '', 0),
(3685, '干死CS', '', 0),
(3686, '干死GM', '', 0),
(3687, '干死你', '', 0),
(3688, '干死客服', '', 0),
(3689, '幹', '', 0),
(3690, '强奸', '', 0),
(3691, '强奸你', '', 0),
(3692, '性', '', 0),
(3693, '性器', '', 0),
(3694, '性无能', '', 0),
(3695, '性爱', '', 0),
(3696, '情色', '', 0),
(3697, '想上你', '', 0),
(3698, '懆您妈', '', 0),
(3699, '懆您娘', '', 0),
(3700, '懒8', '', 0),
(3701, '懒八', '', 0),
(3702, '懒叫', '', 0),
(3703, '懒教', '', 0),
(3704, '成人', '', 0),
(3705, '我操你祖宗十八代', '', 0),
(3706, '扒光', '', 0),
(3707, '打炮', '', 0),
(3708, '打飞机', '', 0),
(3709, '抽插', '', 0),
(3710, '招妓', '', 0),
(3711, '插你', '', 0),
(3712, '插死你', '', 0),
(3713, '撒尿', '', 0),
(3714, '操你', '', 0),
(3715, '操你全家', '', 0),
(3716, '操你奶奶', '', 0),
(3717, '操你妈', '', 0),
(3718, '操你娘', '', 0),
(3719, '操你祖宗', '', 0),
(3720, '操你老妈', '', 0),
(3721, '操你老母', '', 0),
(3722, '操妳', '', 0),
(3723, '操妳全家', '', 0),
(3724, '操妳妈', '', 0),
(3725, '操妳娘', '', 0),
(3726, '操妳祖宗', '', 0),
(3727, '操机掰', '', 0),
(3728, '操比', '', 0),
(3729, '操逼', '', 0),
(3730, '放荡', '', 0),
(3731, '日他娘', '', 0),
(3732, '日你', '', 0),
(3733, '日你妈', '', 0),
(3734, '日你老娘', '', 0),
(3735, '日你老母', '', 0),
(3736, '日批', '', 0),
(3737, '月经', '', 0),
(3738, '机八', '', 0),
(3739, '机巴', '', 0),
(3740, '机机歪歪', '', 0),
(3741, '杂种', '', 0),
(3742, '浪叫', '', 0),
(3743, '淫', '', 0),
(3744, '淫妇', '', 0),
(3745, '淫棍', '', 0),
(3746, '淫水', '', 0),
(3747, '淫秽', '', 0),
(3748, '淫荡', '', 0),
(3749, '淫西', '', 0),
(3750, '湿透的内裤', '', 0),
(3751, '激情', '', 0),
(3752, '灨你娘', '', 0),
(3753, '烂货', '', 0),
(3754, '烂逼', '', 0),
(3755, '爛', '', 0),
(3756, '狗屁', '', 0),
(3757, '狗日', '', 0),
(3758, '狗狼养的', '', 0),
(3759, '玉杵', '', 0),
(3760, '王八蛋', '', 0),
(3761, '瓜娃子', '', 0),
(3762, '瓜婆娘', '', 0),
(3763, '瓜批', '', 0),
(3764, '瘪三', '', 0),
(3765, '白烂', '', 0),
(3766, '白痴', '', 0),
(3767, '白癡', '', 0),
(3768, '祖宗', '', 0),
(3769, '私服', '', 0),
(3770, '笨蛋', '', 0),
(3771, '精子', '', 0),
(3772, '老二', '', 0),
(3773, '老味', '', 0),
(3774, '老母', '', 0),
(3775, '老瘪三', '', 0),
(3776, '老骚比', '', 0),
(3777, '老骚货', '', 0),
(3778, '肉壁', '', 0),
(3779, '肉棍子', '', 0),
(3780, '肉棒', '', 0),
(3781, '肉缝', '', 0),
(3782, '肏', '', 0),
(3783, '肛交', '', 0),
(3784, '肥西', '', 0),
(3785, '色情', '', 0),
(3786, '花柳', '', 0),
(3787, '荡妇', '', 0),
(3788, '賤', '', 0),
(3789, '贝肉', '', 0),
(3790, '贱B', '', 0),
(3791, '贱人', '', 0),
(3792, '贱货', '', 0),
(3793, '贼你妈', '', 0),
(3794, '赛你老母', '', 0),
(3795, '赛妳阿母', '', 0),
(3796, '赣您娘', '', 0),
(3797, '轮奸', '', 0),
(3798, '迷药', '', 0),
(3799, '逼', '', 0),
(3800, '逼样', '', 0),
(3801, '野鸡', '', 0),
(3802, '阳具', '', 0),
(3803, '阳萎', '', 0),
(3804, '阴唇', '', 0),
(3805, '阴户', '', 0),
(3806, '阴核', '', 0),
(3807, '阴毛', '', 0),
(3808, '阴茎', '', 0),
(3809, '阴道', '', 0),
(3810, '阴部', '', 0),
(3811, '雞巴', '', 0),
(3812, '靠北', '', 0),
(3813, '靠母', '', 0),
(3814, '靠爸', '', 0),
(3815, '靠背', '', 0),
(3816, '靠腰', '', 0),
(3817, '驶你公', '', 0),
(3818, '驶你娘', '', 0),
(3819, '驶你母', '', 0),
(3820, '驶你爸', '', 0),
(3821, '驶你老师', '', 0),
(3822, '驶你老母', '', 0),
(3823, '骚比', '', 0),
(3824, '骚货', '', 0),
(3825, '骚逼', '', 0),
(3826, '鬼公', '', 0),
(3827, '鸡8', '', 0),
(3828, '鸡八', '', 0),
(3829, '鸡叭', '', 0),
(3830, '鸡吧', '', 0),
(3831, '鸡奸', '', 0),
(3832, '鸡巴', '', 0),
(3833, '鸡芭', '', 0),
(3834, '鸡鸡', '', 0),
(3835, '龟儿子', '', 0),
(3836, '龟头', '', 0),
(3839, 'سكس', '', 0),
(3840, 'طيز', '', 0),
(3841, 'شرج', '', 0),
(3842, 'لعق', '', 0),
(3843, 'لحس', '', 0),
(3844, 'مص', '', 0),
(3845, 'تمص', '', 0),
(3846, 'بيضان', '', 0),
(3847, 'ثدي', '', 0),
(3848, 'بز', '', 0),
(3849, 'بزاز', '', 0),
(3850, 'حلمة', '', 0),
(3851, 'مفلقسة', '', 0),
(3852, 'بظر', '', 0),
(3853, 'كس', '', 0),
(3854, 'فرج', '', 0),
(3855, 'شهوة', '', 0),
(3856, 'شاذ', '', 0),
(3857, 'مبادل', '', 0),
(3858, 'عاهرة', '', 0),
(3859, 'جماع', '', 0),
(3860, 'قضيب', '', 0),
(3861, 'زب', '', 0),
(3862, 'لوطي', '', 0),
(3863, 'لواط', '', 0),
(3864, 'سحاق', '', 0),
(3865, 'سحاقية', '', 0),
(3866, 'اغتصاب', '', 0),
(3867, 'خنثي', '', 0),
(3868, 'احتلام', '', 0),
(3869, 'نيك', '', 0),
(3870, 'متناك', '', 0),
(3871, 'متناكة', '', 0),
(3872, 'شرموطة', '', 0),
(3873, 'عرص', '', 0),
(3874, 'خول', '', 0),
(3875, 'قحبة', '', 0),
(3876, 'لبوة', '', 0),
(3877, 'شرموط', '', 0),
(3878, 'أبن المتناكة', '', 0),
(3879, 'ابن المتناكة', '', 0),
(3880, 'ابن العاهره', '', 0),
(3881, 'أبن العاهره', '', 0),
(3882, 'ابن الشرموطة', '', 0),
(3883, 'أبن الشرموطة', '', 0),
(3884, 'أبن الزنية', '', 0),
(3885, 'ابن الزنية', '', 0),
(3886, 'هنكها', '', 0),
(3887, 'هتتناك', '', 0),
(3888, 'لبني', '', 0),
(3889, 'أجبهم عليك', '', 0),
(3890, 'أجبهم عليكي', '', 0);

